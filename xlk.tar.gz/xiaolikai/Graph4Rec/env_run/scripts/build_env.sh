#!/bin/bash
SOURCE_HOME=$(readlink -f $(dirname ${BASH_SOURCE[0]}) )/

source ${SOURCE_HOME}/util.sh
date && echo 'begin build env...'

dependency_path=${SOURCE_HOME}../dependency
[ ! -f ${dependency_path} ] && mkdir -p ${dependency_path}

function correct_hadoop_path() {
    # only support "afs:/your/hadoop/path" or "/your/hadoop/path"
    # do not support "afs://xxx.afs.baidu.com:9902/your/hadoop/path" format
    local_path=$1
    if [[ ${local_path} =~ "baidu.com:" ]]; then
        res=`echo ${local_path} | awk -F"/" '{for(i=4;i<=NF;i++){if(i==4){printf("/%s/", $i)}else if(i<NF){printf("%s/", $i)}else{printf("%s", $i)}}}' | awk -F"%" '{print $1}'`
        echo ${res}
    else
        echo ${local_path}
    fi
}

function download_bin() {
    pushd ${SOURCE_HOME}/../
    cat bin/bin.des | while read line
    do
        [ -z "$line" ] && continue

        if [[ $line == \#* ]];
        then
            echo "skip "$line
        else
            bin_name=`echo $line|cut -d'|' -f 1`
            url_name=`echo $line|cut -d'|' -f 2`
            echo $bin_name, $url_name
            rm -f ./$bin_name
            wget $url_name -O ./$bin_name &> /dev/null
            [ $? -ne 0 ] && fatal_error "wget $bin_name error..."
            chmod +x ./$bin_name
            mv ./$bin_name ./dependency
        fi
    done
    popd
}

function download_python() {
    pushd ${SOURCE_HOME}/../
    wget http://szwg-qianmo-com-199-240-44.szwg01.baidu.com:8578/cpython-3.7.0.tar.gz/cpython-3.7.0.tar.gz.1 -O cpython-3.7.0.tar.gz &> /dev/null
    tar -xvf cpython-3.7.0.tar.gz &> /dev/null
    rm cpython-3.7.0.tar.gz
    mv ./cpython-3.7.0 ./dependency
    popd
}

function download_hadoop() {
    pushd ${SOURCE_HOME}/../
    wget http://szwg-qianmo-com-199-240-44.szwg01.baidu.com:8578/hadoop-client-1.4.17.tar.gz/hadoop-client-1.4.17.tar.gz.1 -O hadoop-client-1.4.17.tar.gz &> /dev/null
    [ $? -ne 0 ] && fatal_error "wget hadoop-client-1.4.17.tar.gz error..."
    tar -zxvf hadoop-client-1.4.17.tar.gz &> /dev/null
    [ $? -ne 0 ] && fatal_error "unzip hadoop-client-1.4.17.tar.gz error..."
    rm -f hadoop-client-1.4.17.tar.gz
    if [ -f ./hadoop-client/hadoop/bin/hadoop ]; then
        sed -i 's/.*limit\s\+/exec /g' ./hadoop-client/hadoop/bin/hadoop
        sed -i '2i\unset LD_PRELOAD' ./hadoop-client/hadoop/bin/hadoop
        echo 'unset LD_PRELOAD in ./hadoop-client/hadoop/bin/hadoop'
    fi
    mv ./hadoop-client ./dependency
    popd
}

function install_paddle() {
    unset PYTHONHOME
    unset PYTHONPATH
    pushd ${SOURCE_HOME}/../dependency
    PYTHON_HOME=`readlink -f ./cpython-3.7.0`
    export PATH=${PYTHON_HOME}/bin:${PATH}
    export LD_LIBRARY_PATH=${PYTHON_HOME}/lib:${LD_LIBRARY_PATH}
    which python3.7
    python3.7 -m pip install ./paddlepaddle_gpu-0.0.0-cp37-cp37m-linux_x86_64.whl -U --force-reinstall
    python3.7 -m pip install protobuf==3.10.0
    python3.7 -m pip install pgl
    python3.7 -m pip install gpustat==1.0.0 -U
    python3.7 -m pip install requests==2.28.1 -U
    popd
}

function download_data_by_gzshell() {
    pushd ${SOURCE_HOME}/../src
    graph_data_hdfs_path=`parse_yaml2 ./config.yaml graph_data_hdfs_path`
    graph_data_hdfs_path=`correct_hadoop_path ${graph_data_hdfs_path}`
    graph_data_dir=`echo ${graph_data_hdfs_path} | awk -F'/' '{print $(NF);}'`
    if [ "X${graph_data_dir}" == "X" ]; then
        graph_data_dir=`echo ${graph_data_hdfs_path} | awk -F'/' '{print $(NF-1);}'`
    fi
    graph_data_local_path=`parse_yaml2 ./config.yaml graph_data_local_path`
    fs_name=`parse_yaml2 ./config.yaml graph_data_fs_name`
    fs_ugi=`parse_yaml2 ./config.yaml graph_data_fs_ugi`
    fs_user=`echo $fs_ugi | awk -F',' '{print $1}' | sed "s/ //g"`
    fs_passwd=`echo $fs_ugi | awk -F',' '{print $2}' | sed "s/ //g"`

    rm -rf ${graph_data_local_path}
    mkdir -p ${graph_data_local_path}
    ../dependency/gzshell --uri=${fs_name} --username=${fs_user} --password=${fs_passwd} --conf=../scripts/client.conf  --thread=200 -get ${graph_data_hdfs_path} ${graph_data_local_path}
    mv ${graph_data_local_path}/${graph_data_dir}/* ${graph_data_local_path}/
    rm -rf ${graph_data_local_path}/${graph_data_dir}
    popd
}


function download_data_by_hadoop() {
    pushd ${SOURCE_HOME}/../src
    graph_data_hdfs_path=`parse_yaml2 ./config.yaml graph_data_hdfs_path`
    graph_data_fs_name=`parse_yaml2 ./config.yaml graph_data_fs_name`
    graph_data_fs_ugi=`parse_yaml2 ./config.yaml graph_data_fs_ugi`
    graph_data_local_path=`parse_yaml2 ./config.yaml graph_data_local_path`
    rm -rf ${graph_data_local_path}
    mkdir -p ${graph_data_local_path}
    python ${SOURCE_HOME}/download_graph_data.py ${graph_data_hdfs_path} \
                                                 ${graph_data_fs_name} \
                                                 ${graph_data_fs_ugi} \
                                                 ${SOURCE_HOME}/../dependency/hadoop-client \
                                                 ${graph_data_local_path}
    popd
}

function fatal_error() {
   echo -e "FATAL: " "$1" >> /dev/stderr
   exit 1
}

unset http_proxy
unset https_proxy
download_bin
[ $? -ne 0 ] && fatal_error "bin/bin.des config error"
download_python
[ $? -ne 0 ] && fatal_error "download python env failed"
download_hadoop
[ $? -ne 0 ] && fatal_error "download hadoop client failed"
install_paddle
[ $? -ne 0 ] && fatal_error "install paddle failed"
fs_name=`parse_yaml2 ${SOURCE_HOME}/../src/config.yaml graph_data_fs_name`
if [[ ${fs_name} =~ "hdfs" ]]; then
    download_data_by_hadoop
else
    download_data_by_gzshell
fi
[ $? -ne 0 ] && fatal_error "download data failed"
date && echo 'end build env...'
