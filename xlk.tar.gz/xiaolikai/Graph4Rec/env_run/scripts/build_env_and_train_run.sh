#!/bin/bash
echo "========================== start_to_running_user_job ===================================="
SOURCE_HOME=$(readlink -f $(dirname ${BASH_SOURCE[0]}) )/


LOG_DIR="${SOURCE_HOME}/../../log"
[ ! -d ${LOG_DIR} ] && mkdir -p ${LOG_DIR} && hostname
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/lib64:/lib64
echo "LD_LIBRARY_PATH: ${LD_LIBRARY_PATH}"
ulimit -c unlimited

begin_time=`date '+%s'`

#build env
sh ${SOURCE_HOME}/build_env.sh 2>&1 > ${LOG_DIR}/build_env.log
[ $? -ne 0 ] && date && echo "build env failed!" && exit 1

sh ${SOURCE_HOME}/monitor_gpu.sh 30 2>&1 > ${LOG_DIR}/gpu_mem.log &

sh ${SOURCE_HOME}/monitor_ram.sh 30 2>&1 > ${LOG_DIR}/cpu_mem.log &

#while true
#do
#    echo "will sleep 600"
#    sleep 600
#done

which python3.7

#train
sh -x ${SOURCE_HOME}/train.sh

[ $? -ne 0 ] && date && echo "graph train failed!" && exit 1

end_time=`date '+%s'`
total_time=$((end_time - begin_time))
echo "job finished with ${total_time} seconds"

exit 0
