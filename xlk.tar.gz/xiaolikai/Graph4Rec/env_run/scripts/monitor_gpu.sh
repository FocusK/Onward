#!/bin/bash
SOURCE_HOME=$(readlink -f $(dirname ${BASH_SOURCE[0]}) )/
PYTHON_HOME=`readlink -f ${SOURCE_HOME}/../dependency/cpython-3.7.0`
export PATH=${PYTHON_HOME}/bin:${PATH}
export LD_LIBRARY_PATH=${PYTHON_HOME}/lib:${LD_LIBRARY_PATH}
which python3.7
unset PYTHONHOME
unset PYTHONPATH

if ! command -v gpustat > /dev/null 2>&1; then
    echo "Error: gpustat not install."
    exit 0
fi

interval=$1

while true; do
    gpu_mem=$(gpustat | grep -v baidu | awk -F' ' '{{print $9}}' | tr '\n' '\t')
    echo "${gpu_mem}$(date +"%y-%m-%d %H:%M:%S")"
    sleep ${interval}
done
