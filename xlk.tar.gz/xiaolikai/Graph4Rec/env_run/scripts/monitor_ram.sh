#!/bin/bash
# 监控机器上的内存使用情况
# usage: sh monitor_total_ram.sh ${时间间隔s}
# e.g: sh monitor_total_ram.sh 60

function div_ceil(){
    num3=`echo "scale=2; $1 / $2" | bc`
    floor=`echo "scale=0; $num3 * 100" | bc -l` # 向下取整
    floor=`echo ${floor} | awk '{print int($0)}'` # transform to int          
    echo ${floor}
    # add=`awk -v num1=$floor -v num2=$num3 'BEGIN{print(num1<num2)?"1":"0"}'`
    # echo `expr $floor  + $add`
}

if [ $# -lt 1 ]; then
    interval=60
else
    interval=$1 #设置采集间隔(单位: 秒)
fi

total_mem=`free -g | grep "Mem" | awk '{print $2}'`
echo "total memory: ${total_mem}"
echo used_mem$'\t'percent$'\t'date
while true
do
    used_mem=`free -g | grep "Mem" | awk '{print $3}'`
    percent=`div_ceil ${used_mem} ${total_mem}`
    echo ${used_mem}$'\t'${percent}%$'\t'$(date +"%y-%m-%d %H:%M:%S")
    sleep ${interval}
done


