#!/bin/bash
SOURCE_HOME=$(readlink -f $(dirname ${BASH_SOURCE[0]}) )/

# environment variables for fleet distribute training
source ${SOURCE_HOME}/util.sh
date && echo 'begin to train...'

export GLOG_v=0
ulimit -c unlimited

# environment variables for fleet distribute training
export FLAGS_LAUNCH_BARRIER=0
export PADDLE_TRAINERS=1
export PADDLE_TRAINERS_NUM=${PADDLE_TRAINERS}
export POD_IP=127.0.0.1
export PADDLE_PSERVERS_IP_PORT_LIST="127.0.0.1:29011"  #set free port if 29011 is occupied
export PADDLE_PSERVER_PORT_ARRAY=(29011)
export PADDLE_TRAINER_ID=0


pushd ${SOURCE_HOME}../src
PYTHON_HOME=`readlink -f ${SOURCE_HOME}/../dependency/cpython-3.7.0`
export PATH=${PYTHON_HOME}/bin:${PATH}
export LD_LIBRARY_PATH=${PYTHON_HOME}/lib:${LD_LIBRARY_PATH}

export LD_PRELOAD=`readlink -f ${SOURCE_HOME}/../dependency/libjemalloc.so`
export HADOOP_HOME="${SOURCE_HOME}/../dependency/hadoop-client/hadoop"
export PATH=${SOURCE_HOME}/../dependency/hadoop-client/hadoop/bin:$PATH
export GZSHELL="${SOURCE_HOME}/../dependency/gzshell"
export CLIENT_CONF="${SOURCE_HOME}/client.conf"

# paddle
export FLAGS_call_stack_level=2
selected_gpus=`grep gpus: config.yaml |sed s/#.*//g | grep gpus | awk -F':' '{print $2}' | sed "s/\[//g" | sed "s/\]//g" | sed "s/ //g"`
export FLAGS_selected_gpus=${selected_gpus}
export FLAGS_use_stream_safe_cuda_allocator=false
export FLAGS_enable_opt_get_features=true
export FLAGS_gpugraph_enable_hbm_table_collision_stat=true
export FLAGS_gpugraph_hbm_table_load_factor=0.75
export FLAGS_gpugraph_enable_segment_merge_grads=true
export FLAGS_gpugraph_merge_grads_segment_size=128
export FLAGS_gpugraph_dedup_pull_push_mode=1
export FLAGS_gpugraph_load_node_list_into_hbm=false

topo=`nvidia-smi topo -m | grep GPU0 | awk '{print $7}' | grep NV`
if [ "X${topo}" = "X" ]; then
    export FLAGS_gpugraph_enable_gpu_direct_access=false
    echo "FLAGS_gpugraph_enable_gpu_direct_access is false"
else
    export FLAGS_gpugraph_enable_gpu_direct_access=true
    echo "FLAGS_gpugraph_enable_gpu_direct_access is true"
fi

sage_mode=`grep sage_mode config.yaml | sed s/#.*//g | grep sage_mode | awk -F':' '{print $2}' | sed 's/ //g'`
if [ "${sage_mode}" = "True" ] || [ "${sage_mode}" = "true" ]; then
    export FLAGS_enable_exit_when_partial_worker=true
    echo "FLAGS_enable_exit_when_partial_worker is true"
else
    export FLAGS_enable_exit_when_partial_worker=false
    echo "FLAGS_enable_exit_when_partial_worker is false"
fi

hadoop_shard=`grep hadoop_shard config.yaml | sed s/#.*//g | grep hadoop_shard | awk -F':' '{print $2}' | sed 's/ //g'`
if [ "${hadoop_shard}" = "True" ] || [ "${hadoop_shard}" = "true" ]; then
    export FLAGS_graph_load_in_parallel=false
    echo "FLAGS_graph_load_in_parallel is true"
else
    export FLAGS_graph_load_in_parallel=false
    echo "FLAGS_graph_load_in_parallel is false"
fi

part_num=`grep num_part config.yaml | sed s/#.*//g | grep num_part | awk -F':' '{print $2}' | sed 's/ //g'`
if [ ${part_num} -eq 1000 ];then
    echo "will run full graph"
    export FLAGS_graph_get_neighbor_id=false
else
    echo "will sub part graph"
    export FLAGS_graph_get_neighbor_id=true
fi


set -x
which python3.7
unset PYTHONHOME
unset PYTHONPATH

export TRAINING_ROLE=TRAINER
for((i=0;i<$PADDLE_TRAINERS;i++))
do
    export PADDLE_PORT=8800
    python3.7 -u cluster_train_and_infer.py
done

if [ $? -ne 0 ]; then
    echo "Something failed in cluster_train_and_infer.py"
    exit 1
fi
popd
