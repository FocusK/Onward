function parse_yaml {
   local prefix=$2
   local s='[[:space:]]*' w='[a-zA-Z0-9_]*' fs=$(echo @|tr @ '\034')
   sed -ne "s|^\($s\):|\1|" \
        -e "s|^\($s\)\($w\)$s:$s[\"']\(.*\)[\"']$s\$|\1$fs\2$fs\3|p" \
        -e "s|^\($s\)\($w\)$s:$s\(.*\)$s\$|\1$fs\2$fs\3|p"  $1 |
   awk -F$fs '{
      indent = length($1)/2;
      vname[indent] = $2;
      for (i in vname) {if (i > indent) {delete vname[i]}}
      if (length($3) > 0) {
         vn=""; for (i=0; i<indent; i++) {vn=(vn)(vname[i])("_")}
         printf("%s%s%s=\"%s\"\n", "'$prefix'",vn, $2, $3);
      }
   }'
}

# 解释yaml配置选项并转化为环境变量
# eval $(parse_yaml "$(dirname "${BASH_SOURCE}")"/config.yaml)
#eval $(parse_yaml "$(dirname config.yaml)

# alias hfs="hadoop fs -D fs.default.name=$fs_name  -D hadoop.job.ugi=$fs_ugi -Ddfs.client.block.write.retries=15 -Ddfs.rpc.timeout=300000 -Ddfs.delete.trash=1"

function parse_yaml2 {
    local file=$1
    local key=$2
    grep $key $file | sed s/#.*//g | grep $key | awk -F':' -vOFS=':' '{$1=""; print $0;}' | awk '{print $2;}' | sed 's/ //g; s/"//g'
}

function before_hook_prepro() {
    #[ -d ./data/ ] && rm -r ./data/
    rm data
    mkdir ./data/
    rm workdir
    mkdir workdir
    sh inference.sh > inference.log 2>&1 &
    sh train_data_monitor.sh  > data_monitor.log 2>&1
}

function start_jupyter() {
    port=$1
    nc -z 0.0.0.0 $port
    if [ "$?" -ne "0" ]; then
        nohup python -m jupyter notebook --port=$port --ip 0.0.0.0 --no-browser > notebook.port 2>&1  &
    fi
}
