# Copyright (c) 2019 PaddlePaddle Authors. All Rights Reserved
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""cluster train
"""
import os
import sys
import time
import glob
import shutil
import argparse
import traceback
import pickle as pkl
import numpy as np
from datetime import datetime, timedelta
import threading
import helper

import paddle
import util_hadoop
paddle.enable_static()
import paddle.fluid as fluid
from paddle.fluid.incubate.fleet.utils.fleet_util import FleetUtil
fleet_util = FleetUtil()
import paddle.fluid.core as core
from pgl.utils.logger import log

import config_fleet
import util
import models as M
from util_config import prepare_config, make_dir

from paddle.distributed import fleet
from paddle.fluid.core import GraphGpuWrapper
import copy

def remove_op(program, name):
    """
    remove op
    """
    block = program.global_block()
    for ids, op in list(enumerate(block.ops)):
        if op.type == name:
            block._remove_op(ids)
            return


def remove_backword(program):
    """
    remove_backword
    """
    block = program.global_block()
    last_idx = -1
    for ids, op in list(enumerate(block.ops)):
        if  op._is_backward_op():
            last_idx = ids
            print(op.type + "  idx:" + str(ids))
            break
    last_idx -= 1 # remove fill_constant
    for ids, op in list(enumerate(block.ops)):
        if ids > last_idx:
            block._remove_op(last_idx + 1)

def get_strategy(args, model_dict):
    strategy = paddle.distributed.fleet.DistributedStrategy()
    strategy.a_sync = True   # 默认使用async模式

    configs = {"use_ps_gpu": 1}
    strategy.a_sync_configs = configs

    strategy.trainer_desc_configs = {
        "stat_var_names": [model_dict.stat_pos.name, model_dict.stat_neg.name]
    }

    # sparse参数相关配置
    strategy.fleet_desc_configs = config_fleet.generate_config(args)

    if args.fs_name or args.fs_ugi:
        user, passwd = args.fs_ugi.split(',', 1)
        strategy.fs_client_param = {
            "uri": args.fs_name,
            "user": user,
            "passwd": passwd,
            "hadoop_bin": "%s/bin/hadoop" % (os.getenv("HADOOP_HOME"))
        }
        log.info("set DistributedStrategy fs_client_param")
    else:
        log.info("not set DistributedStrategy fs_client_param")

    return strategy

def train(args, exe, model_dict, PSGPU):

    job_info = util.get_job_info() + "\n"
    hadoop_info = "fs_name=%s\n" % args.fs_name + "fs_ugi=%s\n" % args.fs_ugi
    if args.model_save_path:
        job_info = job_info + hadoop_info + args.model_save_path + "\n"
    else:
        job_info = job_info + hadoop_info + "\n"
    time_msg = "%s\n" % datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    train_msg = time_msg + job_info + "%s train_result: \n" % args.mpi_job_name

    for epoch in range(1, args.epochs + 1):
        dataset_list = []
        t = threading.Thread(target=util.preload_thread,
                args=(args, dataset_list, model_dict, PSGPU))
        t.setDaemon(True)
        t.start()

        epoch_loss = 0
        epoch_auc = 0
        for chunk_index in range(args.chunk_num):

            index = fleet.worker_index() * args.chunk_num + chunk_index
            global_chunk_num = fleet.worker_num() * args.chunk_num
            log.info("epoch: %s, global_chunk_index: %s, global_chunk_num: %s" \
                    % (epoch, chunk_index, global_chunk_num))

            util.ins_ready_sem.acquire()
            dataset = dataset_list[chunk_index]
            if dataset is None:
                util.could_load_sem.release()
                continue

            beginpass_begin = time.time()
            PSGPU.begin_pass()
            beginpass_end = time.time()
            log.info("STAGE [BEGIN PASS] finished, time cost: %f sec" \
                    % (beginpass_end - beginpass_begin))

            train_begin = time.time()
            exe.train_from_dataset(
                model_dict.train_program,
                dataset,
                debug=False)

            train_end = time.time()
            log.info("STAGE [SAMPLE AND TRAIN] for epoch [%d] finished, time cost: %f sec" \
                 % (epoch, train_end - train_begin))

            t_loss = util.get_global_value(model_dict.visualize_loss,
                                            model_dict.batch_count)
            epoch_loss += t_loss

            # calculate global auc
            # rank0_auc = metrics.auc(model_dict.stat_pos,
            #                        model_dict.stat_neg,
            #                        paddle.fluid.global_scope(),
            #                        fleet.util)

            # rank0_auc = fleet_util.get_global_auc(scope=paddle.fluid.global_scope(),
            #        stat_pos=model_dict.stat_pos.name,
            #         stat_neg=model_dict.stat_neg.name)
            rank0_auc = 0.6
            epoch_auc += rank0_auc

            util.clear_metrics(fleet_util, model_dict, paddle.fluid.global_scope())
            dataset.release_memory()
            endpass_begin = time.time()
            PSGPU.end_pass()
            endpass_end = time.time()
            log.info("STAGE [END PASS] finished, time cost: %f sec" \
                    % (endpass_end - endpass_begin))
            util.could_load_sem.release()
        t.join()

        epoch_loss = epoch_loss / args.chunk_num
        epoch_auc = epoch_auc / args.chunk_num
        fleet.barrier_worker()
        time_msg = "%s\n" % datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        train_msg += time_msg
        msg = "Train: Epoch %s | batch_loss %.6f\n" % \
                (epoch, epoch_loss)
        train_msg += msg
        log.info(msg)

        if fleet.worker_index() == 0:
            with open(os.path.join('./train_result.log'), 'a') as f:
                f.write(time_msg)
                f.write(msg)
            os.system("echo '%s' | sh to_robot.sh >/dev/null 2>&1 " % train_msg)

        fleet.barrier_worker()

        savemodel_begin = time.time()
        is_save = (epoch % args.save_model_interval == 0 or epoch == args.epochs)
        if args.model_save_path and is_save:
            log.info("save model for epoch {}".format(epoch))
            util.save_model(exe, args, args.local_model_path, args.model_save_path)
        fleet.barrier_worker()
        savemodel_end = time.time()
        log.info("STAGE [SAVE MODEL] for epoch [%d] finished, time cost: %f sec" \
            % (epoch, savemodel_end - savemodel_begin))

def infer(args, exe, infer_model_dict, PSGPU):
    infer_begin = time.time()
    exe.run(infer_model_dict.startup_program)
    dataset_list = []
    t = threading.Thread(target=util.preload_thread,
            args=(args, dataset_list, infer_model_dict, PSGPU, True))
    t.setDaemon(True)
    t.start()
    for chunk_index in range(args.chunk_num):
        index = fleet.worker_index() * args.chunk_num + chunk_index
        global_chunk_num = fleet.worker_num() * args.chunk_num
        log.info("global_chunk_index: %s, global_chunk_num: %s" \
                % (chunk_index, global_chunk_num))

        util.ins_ready_sem.acquire()
        dataset = dataset_list[chunk_index]
        if dataset is None:
            util.could_load_sem.release()
            continue

        PSGPU.begin_pass()
        fleet.barrier_worker()
        exe.train_from_dataset(
                infer_model_dict.train_program,
                dataset,
                debug=False)
        dataset.release_memory()
        log.info("infer done")
        PSGPU.end_pass()
        util.could_load_sem.release()
    t.join()

    util.upload_embedding(args, args.local_result_path)

    infer_end = time.time()
    log.info("STAGE [INFER MODEL] finished, time cost: % sec" % (infer_end - infer_begin))

def run_worker(args, exe, model_dict, infer_model_dict):
    """
    run worker
    """
    # with fluid.scope_guard(scope_join):
    need_inference = args.need_inference
    exe.run(model_dict.startup_program)
    fleet.init_worker()

    log.info("gpu ps slot names: %s" % repr(model_dict.gpu_slots_names))
    PSGPU = core.PSGPU()
    PSGPU.set_slot_vector(model_dict.gpu_slots_names)
    PSGPU.init_gpu_ps(args.gpus)
    PSGPU.set_slot_dim_vector(model_dict.real_emb_size_list)

    g = GraphGpuWrapper()
    g.set_device(args.gpus)

    etype2files = helper.parse_files(args.etype2files)
    etype_list = util.get_all_edge_type(etype2files, args.symmetry)

    ntype2files = helper.parse_files(args.ntype2files)
    ntype_list = list(ntype2files.keys())

    g.set_up_types(etype_list, ntype_list)
    log.info("total etype: %s" % repr(etype_list))
    log.info("total ntype: %s" % repr(ntype_list))

    for ntype in ntype_list:
        for slot_id in range(1, 9):
            g.add_table_feat_conf(ntype, str(slot_id), "feasign", 1)

    g.set_slot_feature_separator(":")
    g.set_feature_separator(",")
    g.init_service()

    cpuload_begin = time.time()
    reverse = 1 if args.symmetry else 0
    g.load_node_and_edge(args.etype2files, args.ntype2files,
        args.graph_data_local_path, args.num_part, reverse);
    cpuload_end = time.time()
    log.info("STAGE [CPU LOAD] finished, time cost: %f sec", cpuload_end - cpuload_begin)

    gpuload_begin = time.time()
    sys.stderr.write("begin upload\n")
    for i in range(len(etype_list)):
        g.upload_batch(0, i, len(args.gpus), etype_list[i])
        sys.stderr.write("end upload edge, type[" + etype_list[i] + "]\n")

    slot_num = len(args.slots)
    sys.stderr.write("begin upload node\n")
    if slot_num > 0:
        g.upload_batch(1, len(args.gpus), slot_num)
    sys.stderr.write("end upload node\n")
    sys.stderr.write("end upload\n")
    gpuload_end = time.time()
    log.info("STAGE [GPU LOAD] finished, time cost: %f sec", gpuload_end - gpuload_begin)

    if args.warm_start_from:
        log.info("warmup start from %s" % args.warm_start_from)
        load_model_begin = time.time()
        util.load_pretrained_model(args, args.warm_start_from)
        load_model_end = time.time()
        log.info("STAGE [LOAD MODEL] finished, time cost: %f sec" \
            % (load_model_end - load_model_begin))

    fleet.barrier_worker()
    if args.need_train:
        train(args, exe, model_dict, PSGPU)
    else:
        log.info("STAGE: need_train is %s, skip training process" % args.need_train)

    fleet.barrier_worker()
    if args.need_inference:
        infer(args, exe, infer_model_dict, PSGPU)
    else:
        log.info("STAGE: need_inference is %s, skip inference process" % args.need_inference)

    PSGPU.finalize()
    g.finalize()

def main(args):
    """main"""
    place = fluid.CUDAPlace(args.gpus[0])
    exe = fluid.Executor(place)
    fleet.init()
    need_inference = args.need_inference
    infer_model_dict = None
    startup_program = fluid.Program()
    train_program = fluid.Program()

    with fluid.program_guard(train_program, startup_program):
        with fluid.unique_name.guard():
            model_dict = getattr(M, args.model_type)(config=args)
    model_dict.startup_program = startup_program
    model_dict.train_program = train_program

    util.save_holder_names(model_dict, "./holder_name_list.txt")

    fake_lr = 0.005
    adam = fluid.optimizer.Adam(learning_rate=fake_lr)
    optimizer = fleet.distributed_optimizer(adam, strategy=get_strategy(args, model_dict))
    optimizer.minimize(model_dict.loss, model_dict.startup_program)

    train_opt = copy.deepcopy(paddle.fluid.default_main_program()._fleet_opt)
    print("train opt = ", train_opt)
    model_dict.startup_program = paddle.fluid.default_startup_program()
    model_dict.train_program = paddle.fluid.default_main_program().clone()
    model_dict.train_program._fleet_opt = train_opt
    model_dict.train_program._fleet_opt['worker_places'] = args.gpus

    with open("join_main_program.pbtxt", "w") as fout:
        fout.write(str(model_dict.train_program))
    with open("join_startup_program.pbtxt", "w") as fout:
        fout.write(str(model_dict.startup_program))

    if need_inference:
        infer_startup_program = fluid.Program()
        infer_train_program = fluid.Program()

        with fluid.program_guard(infer_train_program, infer_startup_program):
            with fluid.unique_name.guard():
                infer_model_dict = getattr(M, args.model_type)(config=args, is_predict=True)
        infer_model_dict.startup_program = infer_startup_program
        infer_model_dict.train_program = infer_train_program
        fake_lr_infer = 0.00
        adam_infer = fluid.optimizer.Adam(learning_rate=fake_lr_infer)
        optimizer1 = fleet.distributed_optimizer(adam_infer, strategy=get_strategy(args, infer_model_dict))
        optimizer1.minimize(infer_model_dict.loss, infer_model_dict.startup_program)
        infer_opt = copy.deepcopy(paddle.fluid.default_main_program()._fleet_opt)
        infer_model_dict.train_program = paddle.fluid.default_main_program().clone()
        infer_model_dict.train_program._fleet_opt = infer_opt
        opt_info = infer_model_dict.train_program._fleet_opt

        opt_info['worker_places']= args.gpus
        opt_info["dump_fields"] = [args.dump_node_name + ".tmp_0", args.dump_node_emb_name + ".tmp_0"]
        opt_info["dump_fields_path"] = args.local_result_path
        opt_info["is_dump_in_simple_mode"] = True
        #opt_info["dump_file_num"] = 64
        with open("infer_before_main_program.pbtxt", "w") as fout:
            fout.write(str(infer_model_dict.train_program))
        remove_op(infer_model_dict.train_program, "push_gpups_sparse")
        remove_backword(infer_model_dict.train_program)
        with open("infer_main_program.pbtxt", "w") as fout:
            fout.write(str(infer_model_dict.train_program))
        print("infer opt = ", opt_info)


    # init and run server or worker
    if fleet.is_server():
        log.info("before run server")
        fleet.init_server()
        fleet.run_server()

    elif fleet.is_worker():
        run_worker(args, exe, model_dict, infer_model_dict)
        #pass

    fleet.stop_worker()

if __name__ == "__main__":
    util.print_useful_info()
    config = prepare_config("config.yaml")
    if "/raid0" in config.graph_data_local_path:
        config.local_model_path = "/raid0/model"
        config.local_result_path = "/raid0/embedding"
    else:
        config.local_model_path = "./model"
        config.local_result_path = "./embedding"
    config.model_save_path = os.path.join(config.working_root, "model")
    config.infer_result_path = os.path.join(config.working_root, 'embedding')
    print(config)
    main(config)

