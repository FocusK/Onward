# Copyright (c) 2019 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""dataset loader"""
import os
import re
import sys
import glob
import time
import numpy as np

import util
import paddle.fluid as fluid
from paddle.fluid.incubate.fleet.parameter_server.pslib import fleet
from paddle.fluid.incubate.fleet.utils.fleet_util import FleetUtil
from pgl.utils.logger import log

def get_file_list(args, chunk_index, chunk_num):
    """ get data file list """
    work_dir = "./workdir/filelist" # a tmp directory that does not used in other places
    if not os.path.isdir(work_dir):
        os.makedirs(work_dir)

    file_list = []
    for thread_id in range(len(args.gpus)):
        filename = os.path.join(work_dir, "%s_%s_%s" % (chunk_num, chunk_index, thread_id))
        file_list.append(filename)
        with open(filename, "w") as writer:
            writer.write("%s_%s_%s\n" % (chunk_num, chunk_index, thread_id))

    return file_list


def base_generate_dataset(args, psgpu, model_dict, file_list, predict=False):
    """ base generate dataset """

    sage_mode = args.sage_mode if args.sage_mode else False
    # If sage_mode is True and args.samples is not None.
    str_samples = ""
    if sage_mode and args.samples and len(args.samples) > 0:
        for s in args.samples:
            str_samples += str(s)
            str_samples += ";"
        str_samples = str_samples[:-1]

    str_infer_samples = ""
    if sage_mode and args.infer_samples and len(args.infer_samples) > 0:
        for s in args.infer_samples:
            str_infer_samples += str(s)
            str_infer_samples += ";"
        str_infer_samples = str_infer_samples[:-1]

    graph_config = {"walk_len": args.walk_len,
                    "walk_degree": args.walk_times,
                    "once_sample_startid_len": args.batch_node_size,
                    "sample_times_one_chunk": args.sample_times_one_chunk,
                    "window": args.win_size,
                    "debug_mode": args.debug_mode,
                    "batch_size": args.batch_size,
                    "meta_path": args.meta_path,
                    "gpu_graph_training": not predict,
                    "sage_mode": sage_mode,
                    "samples": str_samples}
    first_node_type = util.get_first_node_type(args.meta_path)
    graph_config["first_node_type"] = first_node_type

    if predict:
        graph_config["batch_size"] = args.infer_batch_size
        graph_config["samples"] = str_infer_samples
    print("graph_config",graph_config)
    dataset = fluid.DatasetFactory().create_dataset("InMemoryDataset")
    dataset.set_feed_type("SlotRecordInMemoryDataFeed")
    dataset.set_use_var(model_dict.holder_list)
    dataset.set_graph_config(graph_config)

    dataset.set_batch_size(1)  # Fixed Don't Change. Batch Size is not config here.

    dataset.set_thread(len(args.gpus))
    dataset.set_hdfs_config(args.fs_name, args.fs_ugi)
    dataset._set_use_ps_gpu(psgpu)
    dataset.set_filelist(file_list)

    with open("datafeed.pbtxt", "w") as fout:
        fout.write(dataset.desc())
    return dataset


def generate_dataset(args, psgpu, model_dict, chunk_index, chunk_num, predict=False):
    """ generate dataset """
    file_list = get_file_list(args, chunk_index, chunk_num)
    log.info(file_list)
    dataset = base_generate_dataset(args, psgpu, model_dict, file_list, predict)
    return dataset
