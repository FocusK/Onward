#-*- coding: utf-8 -*-
# Copyright (c) 2019 PaddlePaddle Authors. All Rights Reserved
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
    gnn model.
"""
from __future__ import division
from __future__ import absolute_import
from __future__ import print_function
from __future__ import unicode_literals
import os
import sys
sys.path.append("../")
import math
import time
import numpy as np
import pickle as pkl

import paddle
import paddle.fluid.layers as L
import paddle.fluid as F
import pgl
from pgl.utils.logger import log

from models import layers 
import models.loss as Loss
from models.model_util import inner_add, calc_auc, paddle_print, dump_func

import util
import helper

def get_layer(layer_type, graph, feature, next_num_nodes, hidden_size, act, name, is_test=False):
    """get_layer"""
    return getattr(layers, layer_type)(graph, feature, next_num_nodes, hidden_size, act, name)

def gnn_layers(graph_holders, init_feature, hidden_size, layer_type, \
    act, num_layers, etype_len, alpha_residual, interact_mode="sum"):
    """ generate graphsage layers"""

    # Pad 0 feature to deal with empty edges, otherwise will raise errors.
    zeros_tensor1 = paddle.zeros([1, init_feature.shape[-1]])
    zeros_tensor2 = paddle.zeros([1, 1], dtype="int64")
    init_feature = paddle.concat([zeros_tensor1, init_feature])
    feature = init_feature
    
    for i in range(num_layers):
        if i == num_layers - 1:
            act = None
        graph_holder = graph_holders[num_layers - i - 1]
        num_nodes = graph_holder[0] + 1
        next_num_nodes = graph_holder[1] + 1
        edges_src = graph_holder[2] + 1
        edges_dst = graph_holder[3] + 1
        split_edges = paddle.cumsum(graph_holder[4])
        nxt_fs = []
        for j in range(etype_len):
            start = paddle.zeros([1], dtype="int64") if j == 0 else split_edges[j - 1]
            new_edges_src = paddle.concat(
                [zeros_tensor2, edges_src[start: split_edges[j]]])
            new_edges_dst = paddle.concat(
                [zeros_tensor2, edges_dst[start: split_edges[j]]])
            graph = pgl.Graph(num_nodes=num_nodes,
                              edges=paddle.concat([new_edges_src, new_edges_dst], axis=1))
            nxt_f = get_layer(
                layer_type,
                graph,
                feature,
                next_num_nodes,
                hidden_size,
                act,
                name="%s_%s_%s" % (layer_type, i, j))
            nxt_fs.append(nxt_f)

        feature = feature_interact_by_etype(
            nxt_fs, interact_mode, hidden_size, name="%s_interat" % layer_type)
        feature = init_feature[:next_num_nodes] * alpha_residual + feature * (1 - alpha_residual)
    return feature[1:]

def feature_interact_by_etype(feature_list, interact_mode, hidden_size, name):
    """ feature interact with etype """
    if len(feature_list) == 1:
        return feature_list[0]
    elif interact_mode == "gatne":
        # stack [num_nodes, num_etype, hidden_size]
        U = L.stack(feature_list, axis=1)
        #  [num_nodes * num_etype, hidden_size]
        tmp = L.fc(L.reshape(U, shape=[-1, hidden_size]),
                hidden_size,
                act="tanh",
                param_attr=F.ParamAttr(name=name + '_w1'),
                bias_attr=None)

        #  [num_nodes * num_etype, 1]
        tmp = L.fc(tmp, 1, act=None, param_attr=F.ParamAttr(name=name + '_w2'))
        #  [num_nodes, num_etype]
        tmp = L.reshape(tmp, shape=[-1, len(feature_list)])
        #  [num_nodes, 1, num_etype]
        a = L.unsqueeze(L.softmax(tmp, axis=-1), axes=1)
        out = L.squeeze(L.matmul(a, U), axes=[1])
        return out
    else:
        return L.sum(feature_list)


class GNNModel(object):
    """ GNNModel """
    def __init__(self, config, dump_file_obj=None, is_predict=False):
        """ init """
        self.config = config
        self.dump_file_obj = dump_file_obj
        self.is_predict = is_predict
        self.neg_num = self.config.neg_num
        self.emb_size = self.config.emb_size
        self.slots = self.config.slots 
        self.nodeid_slot = self.config.nodeid_slot
        self.gpu_slots = []
        self.gpu_slots_names = []

        self.slot_emb_size = self.config.slot_emb_size
        if self.slot_emb_size is None:
            self.slot_emb_size = self.emb_size

        if self.config.feature_mode == "sum" and self.slot_emb_size != self.emb_size:
            raise ValueError("slot_emb_size should be equal to emb_size when feature_mode is [sum]. " \
                    "But got slot_emb_size[%s] != emb_size[%s]" % (self.slot_emb_size, self.emb_size))

        # 添加结点特征数据 + 图数据 + 边类型数
        self.holder_list = []
        self.build_node_holder(self.nodeid_slot)
        self.build_slot_holder(self.slots)
        if self.config.sage_mode:
            self.build_graph_holder()
            self.etype_len = self.get_etype_len()

        self.loss = None

        predictions = self.forward()
        loss, v_loss = self.loss_func(predictions)
        self.loss = loss

        # for visualization
        paddle_print(v_loss)
        self.visualize_loss, self.batch_count = self.loss_visualize(v_loss)

        if self.is_predict:
            self.dump_embedding(predictions)

        # calculate AUC
        logits = predictions["logits"]
        pos = L.sigmoid(logits[:, 0:1])
        neg = L.sigmoid(logits[:, 1:2])
        batch_auc_out, state_tuple = calc_auc(pos, neg)
        batch_stat_pos, batch_stat_neg, stat_pos, stat_neg = state_tuple
        self.stat_pos = stat_pos
        self.stat_neg = stat_neg
        self.batch_stat_pos = batch_stat_pos
        self.batch_stat_neg = batch_stat_neg

    def get_etype_len(self):
        """ get length of etype list 边的类型数 """
        etype2files = helper.parse_files(self.config.etype2files)
        etype_list = util.get_all_edge_type(etype2files, self.config.symmetry)
        print("len of etypes: ", len(etype_list))
        return len(etype_list)

    def build_node_holder(self, nodeid_slot):
        """ build node holder """
        self.node_index = L.data(str(nodeid_slot), shape=[-1, 1], dtype="int64", lod_level=1)
        #L.Print(self.node_index)
        self.holder_list.append(self.node_index)
        self.gpu_slots.append(self.node_index)
        self.gpu_slots_names.append(nodeid_slot)

        self.click = L.data("click", shape=[-1], dtype="int64")
        #L.Print(self.click)
        self.holder_list.append(self.click)
        self.show = L.data("show", shape=[-1], dtype="int64")
        #L.Print(self.show)
        self.holder_list.append(self.show)

    def build_slot_holder(self, slots):
        """slot holder """
        self.slot_feature = {}
        self.slot_lod = {}
        for slot in slots:
            self.slot_feature[slot] = L.data(
                slot,
                shape=[None, 1],
                dtype="int64",
                lod_level=1,
                append_batch_size=False)
            self.holder_list.append(self.slot_feature[slot])
            self.gpu_slots.append(self.slot_feature[slot])
            self.gpu_slots_names.append(int(slot))

            self.slot_lod[slot] = L.data(
                "slot_%s_lod" % slot,
                shape=[None],
                dtype="int64",
                lod_level=0,
                append_batch_size=False)
            self.holder_list.append(self.slot_lod[slot])

    def build_graph_holder(self):
        """ graph holder """
        samples = self.config.samples
        self.graph_holders = {}
        for i, s in enumerate(samples):
            # For different sample size, we hold a graph block.
            self.graph_holders[i] = []
            num_nodes = L.data(
                name="%s_num_nodes" % i,
                shape=[-1],
                dtype="int")
            self.holder_list.append(num_nodes)
            self.graph_holders[i].append(num_nodes)

            next_num_nodes = L.data(
                name="%s_next_num_nodes" % i,
                shape=[-1],
                dtype="int")
            self.holder_list.append(next_num_nodes)
            self.graph_holders[i].append(next_num_nodes)

            edges_src = L.data(
                name="%s_edges_src" % i,
                shape=[-1, 1],
                dtype="int64")
            self.holder_list.append(edges_src)
            self.graph_holders[i].append(edges_src)

            edges_dst = L.data(
                name="%s_edges_dst" % i,
                shape=[-1, 1],
                dtype="int64")
            self.holder_list.append(edges_dst)
            self.graph_holders[i].append(edges_dst)

            edges_split = L.data(
                name="%s_edges_split" % i,
                shape=[-1],
                dtype="int")
            self.holder_list.append(edges_split)
            self.graph_holders[i].append(edges_split)

        self.final_index = L.data(
            name="final_index",
            shape=[-1],
            dtype="int")
        self.holder_list.append(self.final_index)

    def get_node_features(self):
        """ get node feat """
        nfeat_list = []
        self.real_emb_size_list = []
        for i_slot in self.gpu_slots:
            l = F.contrib.sparse_embedding(input=i_slot,
                                        size=[1024, self.emb_size + 3],
                                        param_attr=F.ParamAttr(name="embedding"))
            nfeat_list.append(l)
            self.real_emb_size_list.append(self.emb_size)

        show_clk = L.concat(
                [L.reshape(self.show, [-1, 1]), L.reshape(self.click, [-1, 1])], axis=-1)
        show_clk = L.cast(show_clk, dtype="float32")
        show_clk.stop_gradient = True
        self._use_cvm = False

        slot_nfeat_list = []
        slot_nfeat_noise_list = []
        # process id embedding
        id_embedding = L.continuous_value_model(nfeat_list[0], show_clk, self._use_cvm)
        id_embedding = id_embedding[:, 1:] # the first column is for lr, remove it
        slot_nfeat_list.append(id_embedding)
        #  noise = L.uniform_random([L.shape(id_embedding)[0], self.emb_size], dtype='float32', min=0, max=1.0)
        #  noise = L.sign(noise)
        #  r = 0.5
        #  slot_nfeat_noise_list.append(id_embedding + noise * r)

        slot_embeddings = []
        # process slot embedding
        for idx, slot in enumerate(self.slots):
            lod = self.slot_lod[slot]
            lod = L.cast(lod, dtype="int32")
            lod = L.reshape(lod, [1, -1])
            lod.stop_gradient = True
            slot_embedding = L.lod_reset(nfeat_list[idx + 1], lod)
            slot_embeddings.append(slot_embedding)
        if(len(self.slots)) > 0:
            slot_bows = F.contrib.layers.fused_seqpool_cvm(slot_embeddings, self.config.slot_pool_type,
                show_clk, use_cvm=self._use_cvm)
            for bow in slot_bows:
                slot_embedding = bow[:, 1:] # the first column is for lr, remove it
                #  slot_embedding_noise = L.softsign(slot_embedding + noise)
                slot_embedding = L.softsign(slot_embedding)
                slot_nfeat_list.append(slot_embedding)
                #  slot_nfeat_noise_list.append(slot_embedding_noise)

        nfeat = L.sum(slot_nfeat_list)
        #  nfeat_noise = L.sum(slot_nfeat_noise_list)
        nfeat_noise = None
        if self.config.softsign:
            log.info("using softsign in feature_mode (sum)")
            feature = L.softsign(nfeat)

        return (nfeat, nfeat_noise)

    def hcl(self, feature):
        """Hierarchical Contrastive Learning"""
        hcl_logits = []
        for idx, sample in enumerate(self.config.samples):
            graph_holder = self.graph_holders[idx]
            edges_src = graph_holder[2]
            edges_dst = graph_holder[3]
            neighbor_src_feat = paddle.gather(feature, edges_src)
            neighbor_src_feat = neighbor_src_feat.reshape([-1, 1, self.config.emb_size])
            neighbor_dst_feat = paddle.gather(feature, edges_dst)
            neighbor_dst_feat = neighbor_dst_feat.reshape([-1, 1, self.config.emb_size])
            neighbor_dsts_feat_all = [neighbor_dst_feat]

            for neg in range(self.neg_num):
                neighbor_dsts_feat_all.append(
                        F.contrib.layers.shuffle_batch(neighbor_dsts_feat_all[0]))
            neighbor_dsts_feat = L.concat(neighbor_dsts_feat_all, axis=1)

            # [batch_size, 1, neg_num+1]
            logits = L.matmul(neighbor_src_feat, neighbor_dsts_feat, transpose_y=True)  
            logits = L.squeeze(logits, axes=[1])
            hcl_logits.append(logits)

        return hcl_logits

    def forward(self):
        """ forward """
        hcl_logits_list = None
        feature, feature_noise = self.get_node_features()

        if self.config.sage_mode:
            if self.config.hcl:
                hcl_logits_list = self.hcl(feature)

            if self.config.sage_layer_type == "gatne":
                layer_type = "lightgcn"
            else:
                layer_type = self.config.sage_layer_type
            feature = gnn_layers(self.graph_holders,
                                 feature,
                                 self.emb_size,
                                 layer_type=layer_type,
                                 act=self.config.sage_act,
                                 num_layers=len(self.config.samples),
                                 etype_len=self.etype_len,
                                 alpha_residual=self.config.sage_alpha,
                                 interact_mode=self.config.sage_layer_type)
            feature = L.gather(feature, self.final_index, overwrite=False)
            #  feature_noise = L.gather(feature_noise, self.final_index, overwrite=False)

        feature = L.reshape(feature, shape=[-1, 2, self.emb_size])
        #  feature_noise = L.reshape(feature_noise, shape=[-1, 2, self.emb_size])
        #  L.Print(feature, message="feature combine")

        src_feat = feature[:, 0:1, :]
        #  L.Print(src_feat, message="src feat")
        dsts_feat_all = [feature[:, 1:, :]]
        for neg in range(self.neg_num):
            dsts_feat_all.append(F.contrib.layers.shuffle_batch(dsts_feat_all[0]))
        dsts_feat = L.concat(dsts_feat_all, axis=1)
        #  L.Print(dsts_feat, message="dst feat")

        logits = L.matmul(src_feat, dsts_feat, transpose_y=True)  # [batch_size, 1, neg_num+1]
        logits = L.squeeze(logits, axes=[1])
        #  logits = L.reshape(-1, 1, self.neg_num + 1)
        #  logits = L.unsqueeze(logits, axes=1)
        #  L.Print(logits, message="logits")

        #  src_feat_noise = feature_noise[:, 0:1, :]
        #  logits_noise = L.matmul(src_feat, src_feat_noise, transpose_y=True)  # [batch_size, 1, neg_num+1]

        predictions = {}
        predictions["logits"] = logits # [B, neg_num + 1]
        predictions["nfeat"] = feature # [B, 2, d]
        predictions["src_nfeat"] = src_feat # [B, 1, d]
        if hcl_logits_list is not None:
            predictions["hcl_logits"] = hcl_logits_list

        return predictions

    def dump_embedding(self, predictions):
        """dump_embedding"""
        src_feat = predictions["src_nfeat"]
        node_embed = L.squeeze(src_feat, axes=[1], name=self.config.dump_node_emb_name)
        node_index = self.node_index
        if self.config.sage_mode:
            node_index =  L.gather(node_index, self.final_index, overwrite=False)

        node_index = L.reshape(node_index, shape=[-1, 2])
        src_node_index = node_index[:, 0:1]
        src_node_index = L.reshape(src_node_index, 
                shape = src_node_index.shape, 
                name=self.config.dump_node_name) # for rename

    def loss_func(self, predictions, label=None):
        """loss_func"""
        if "loss" not in self.config.loss_type:
            loss_type = "%s_loss" % self.config.loss_type
        else:
            loss_type = self.config.loss_type

        loss_count = 1
        loss = getattr(Loss, loss_type)(self.config, predictions)
        
        if self.config.gcl_loss:
            gcl_loss = getattr(Loss, self.config.gcl_loss)(self.config, predictions)
            loss += gcl_loss
            loss_count += 1

        hcl_logits_list = predictions.get("hcl_logits")
        if hcl_logits_list is not None:
            hcl_loss = Loss.hcl_loss(self.config, hcl_logits_list)
            loss += hcl_loss
            loss_count += 1

        # for visualization
        v_loss = loss / self.config.batch_node_size / loss_count

        return loss, v_loss

    def loss_visualize(self, loss):
        """loss_visualize"""
        visualize_loss = L.create_global_var(
                persistable=True, dtype="float32", shape=[1], value=0)
        batch_count = L.create_global_var(
                persistable=True, dtype="float32", shape=[1], value=0)
        inner_add(loss, visualize_loss)
        inner_add(1., batch_count)

        return visualize_loss, batch_count
