#-*- coding: utf-8 -*-
# Copyright (c) 2019 PaddlePaddle Authors. All Rights Reserved
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
    doc
"""
from __future__ import division
from __future__ import absolute_import
from __future__ import print_function
from __future__ import unicode_literals

import os
import sys
sys.path.append("../")
import math
import time
import numpy as np
import pickle as pkl

import paddle.fluid as F
import paddle.fluid.layers as L
import pgl
from pgl.utils.logger import log

def inner_add(value, var):
    """ inner add """
    tmp = var + value
    L.assign(tmp, var)

def calc_auc(pos_logits, neg_logits):
    """calc_auc"""
    pos_logits = L.reshape(pos_logits[:, 0], [-1, 1])
    neg_logits = L.reshape(neg_logits[:, 0], [-1, 1])
    proba = L.concat([pos_logits, neg_logits], 0)
    proba = L.concat([proba * -1 + 1, proba], axis=1)

    pos_labels = L.ones_like(pos_logits)
    neg_labels = L.zeros_like(neg_logits)

    pos_labels = L.cast(pos_labels, dtype="int64")
    neg_labels = L.cast(neg_labels, dtype="int64")

    labels = L.concat([pos_labels, neg_labels], 0)
    labels.stop_gradient=True
    _, batch_auc_out, state_tuple = L.auc(input=proba, label=labels, num_thresholds=4096)
    return batch_auc_out, state_tuple

def dump_func(file_obj, node_index, node_embed):
    """paddle dump embedding

    输入:

        file_obj: 文件锁对象
        node_index: 节点ID
        node_embed: 节点embedding
        写出路径： output_path/part-%s worker-index
        写出格式: index \t label1 \t label1_score \t label2 \t label2_score

    """
    out = F.default_main_program().current_block().create_var(
                name="dump_out", dtype="float32", shape=[1])
    def _dump_func(vec_id, node_vec):
        """
            Dump Vectors for inference
        """
        if True:
            buffer
            file_obj.acquire()
            vec_lines = []
            for _node_id, _vec_feat in zip(np.array(vec_id), np.array(node_vec)):
                _node_id = str(_node_id.astype("int64").astype('uint64')[0])
                _vec_feat = " ".join(["%.5lf" % w for w in _vec_feat])

                vec_lines.append("%s\t%s\n" % (_node_id, _vec_feat))

            if len(vec_lines) > 0:
                file_obj.vec_path.write(''.join(vec_lines))
                vec_lines = []
            file_obj.release()
        return np.array([1], dtype="float32")

    o = L.py_func(_dump_func, [node_index, node_embed], out=out)
    return o

def paddle_print(*args):
    """print auc"""
    global print_count
    print_count = 0

    global start_time
    start_time = time.time()


    def _print(*inputs):
        """print auc by batch"""
        global print_count
        global start_time
        print_count += 1
        print_per_step = 1000
        if print_count % print_per_step == 0:
            speed = 1.0 * (time.time() - start_time) / print_per_step
            msg = "Speed %s sec/batch \t Batch:%s\t " % (speed, print_count)
            for x in inputs:
                msg += " %s \t" % (np.array(x)[0])
            log.info(msg)
            start_time = time.time()

    L.py_func(_print, args, out=None)


