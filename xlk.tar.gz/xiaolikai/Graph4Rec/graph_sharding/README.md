# Graph Sharding using hadoop streaming

## 简介

图引擎会加载所有的图数据，如果图数据规模很大，那么加载速度就非常慢。为了加快图数据加载速度，我们需要对图数据进行分片，分片之后图引擎就可以多线程并行加载，大大提高加载图数据的速度。

## 使用方法

### 配置说明

在运行之前，需要修改`./hadoop_run.sh`文件中的一些参数，具体如下：

* map_task: hadoop streaming 中mapper的个数

* reduce_task: hadoop streaming最终生成的文件数。这个需要跟`../../user_configs/`目录下的配置文件中的`shard_num`参数保持一致。

* symmetry: 是否是双向图。这个也需要跟`../../user_configs/`目录下的配置文件中的`symmetry`参数保持一致。一般是True即可。

* hadoop_bin: 本地hadoop包

* hadoop_base_output_path: 图分片的输出目录


### 运行

```
sh hadoop_run.sh 
```

### demo说明

假设我现在有两种类型边，分别是u2t和u2f。 

u2t的边放在/your/hadoop/path/u2t_edges.txt;

u2f的边放在/your/hadoop/path/u2f_edges.txt;

node_types文件存放在/your/hadoop/path/node_types.txt.

我想要把数据分成1000份，分片完的数据存放到/your/hadoop/path_shard/目录。
那么我的`hadoop_run.sh`有如下配置：

```
map_task=200
reduce_task=1000
symmetry="True"
hadoop_bin='/home/work/liweibin02/apps/hadoop-client-global/hadoop/bin/hadoop'

hadoop_base_output_path="/your/hadoop/path_shard/"

hadoop_input_path="/your/hadoop/path/u2t_edges.txt"
hadoop_output_path="${hadoop_base_output_path}/u2t"
graph_data_sharding ${hadoop_input_path} ${hadoop_output_path} ${bidirection} "no"

hadoop_input_path="/your/hadoop/path/u2f_edges.txt"
hadoop_output_path="${hadoop_base_output_path}/u2f"
graph_data_sharding ${hadoop_input_path} ${hadoop_output_path} ${bidirection} "no"

hadoop_node_type_path="/your/hadoop/path/node_types.txt"
hadoop_node_type_output_path="${hadoop_base_output_path}/node_types"
graph_data_sharding ${hadoop_node_type_path} ${hadoop_node_type_output_path} "no" "yes"

```

进行上述配置后并运行，分片好的数据就会存放在以下几个目录：

u2t的边存放在/your/hadoop/path_shard/u2t/;

u2f的边存放在/your/hadoop/path_shard/u2f/;

node_types节点文件存放在/your/hadoop/path_shard/node_types/。


有了这几个新的数据目录之后，在`../../user_configs`目录的
配置文件中的`etype2files`和`ntype2files`参数即为：

```
shard_num: 1000
etype2files: "u2t:u2t,u2f:u2f"
ntype2files: "u:node_types,t:node_types,f:node_types"
```
