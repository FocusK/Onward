set -x

# config
task_name=graph_data_sharding

# map_task: hadoop streaming 中mapper的个数
map_task=200
# reduce_task: hadoop streaming最终生成的文件数。这个需要跟`../../user_configs/`目录下的配置文件中的`shard_num`参数保持一致。
reduce_task=1000
# symmetry: 是否是双向图。这个也需要跟`../../user_configs/`目录下的配置文件中的`symmetry`参数保持一致。一般是True即可。
symmetry="True"
# hadoop_bin: 本地hadoop
hadoop_bin='/home/work/liweibin02/apps/hadoop-client-global/hadoop/bin/hadoop'

if [ "${symmetry}" = "True" ] || [ "${symmetry}" = "true" ]; then
    bidirection="yes"
else
    bidirection="no"
fi

# hadoop function
function clear_hadoop_files() {
   local file_path=$1
   ${hadoop_bin} fs -test -e ${file_path}
   if [ $? -eq 0 ]; then
       ${hadoop_bin} fs -rmr ${file_path}
   fi
}

function graph_data_sharding() {
    local hadoop_input_path=$1
    local hadoop_output_path=$2
    local symmetry=$3
    local node_type_shard=$4
    clear_hadoop_files ${hadoop_output_path}
    
    $hadoop_bin streaming \
        -D mapred.job.name=${task_name} \
        -D mapred.job.map.capacity=10000 \
        -D mapred.job.reduce.capacity=5000 \
        -D mapred.map.tasks=${map_task} \
        -D mapred.reduce.tasks=${reduce_task} \
        -D stream.memory.limit=2000 \
        -D mapred.map.over.capacity.allowed=true \
        -D mapred.job.priority=HIGH \
        -D abaci.split.optimize.enable=true \
        -D abaci.job.base.environment=default \
        -D mapred.output.key.comparator.class="org.apache.hadoop.mapred.lib.KeyFieldBasedComparator" \
        -D mapred.text.key.comparator.options="-k1,1" \
        -input  ${hadoop_input_path} \
        -output ${hadoop_output_path} \
        -mapper "export LANG=en_US.UTF-8;export LC_ALL=en_US.UTF-8;export LC_CTYPE=en_US.UTF-8; python ./hashcode.py map ${reduce_task} ${symmetry} ${node_type_shard}" \
        -reducer "export LANG=en_US.UTF-8;export LC_ALL=en_US.UTF-8;export LC_CTYPE=en_US.UTF-8; python ./hashcode.py reduce" \
        -file hashcode.py \

}

# demo 说明
<<COMMENT
假设我现在有两种类型边，分别是u2t和u2f。 

u2t的边放在/your/hadoop/path/u2t_edges.txt;

u2f的边放在/your/hadoop/path/u2f_edges.txt;

node_types文件存放在/your/hadoop/path/node_types.txt.

我想要把分片完的数据存放到/your/hadoop/path_shard/目录。

那么我的配置就如下命令所示：
COMMENT

# hadoop_base_output_path: 图分片后的输出目录
hadoop_base_output_path="/your/hadoop/path_shard/"

hadoop_input_path="/your/hadoop/path/u2t_edges.txt"
hadoop_output_path="${hadoop_base_output_path}/u2t"
graph_data_sharding ${hadoop_input_path} ${hadoop_output_path} ${bidirection} "no"

hadoop_input_path="/your/hadoop/path/u2f_edges.txt"
hadoop_output_path="${hadoop_base_output_path}/u2f"
graph_data_sharding ${hadoop_input_path} ${hadoop_output_path} ${bidirection} "no"

hadoop_node_type_path="/your/hadoop/path/node_types.txt"
#NOTE:  hadoop_node_type_output_path 的最后一级目录要与../../user_configs/ 中的ntype2files保持一致
hadoop_node_type_output_path="${hadoop_base_output_path}/node_types"
graph_data_sharding ${hadoop_node_type_path} ${hadoop_node_type_output_path} "no" "yes"

