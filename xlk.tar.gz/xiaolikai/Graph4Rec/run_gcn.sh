#!bin/bash
source ~/.bashrc

workPath=`pwd`;
cd $workPath
logs="$workPath/logs"

if [ ! -d $logs ]; then
    mkdir -p $logs
fi

dst_day=$1
if [ ! -n "$1" ];then
    echo "need give data"
    dst_day=$(date -d "last day" +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)
overdue_day=$(date -d "-2 days $dst_day" +%Y%m%d)
# scene: [shortvideo mu vod au]
scene=$2
if [ ! -n "$2" ];then
    echo "need give scene!! quit"
    exit -1
fi

log="$logs/train_${scene}_${dst_day}.log"

hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/model/$scene/$overdue_day"
hk -rmr $hadoop_path

######  执行今日任务 #######
modify_yaml(){
    dst_day=$1
    scene=$2

    # 获取之前执行的日期并替换
    yaml_file="${workPath}/user_configs/lightgcn.yaml"
    old_day=`cat $yaml_file | grep 'etype2files:' | awk -F '/' '{print $3}' | awk -F '"' '{print $1}' | awk -F '=' '{print $2}'`
    echo $old_day
    sed -i 's/'"${old_day}"'/'"${dst_day}"'/g' ./user_configs/lightgcn.yaml

    # 替换场景
    old_scene=`cat $yaml_file | grep 'etype2files:' | awk -F '/' '{print $2}'`
    echo $old_scene
    sed -i 's/'"${old_scene}"'/'"${scene}"'/g' ./user_configs/lightgcn.yaml
}

{
    modify_yaml $dst_day $scene
    echo $dst_day
    echo $scene
    echo 'succ modify lightgcn.yaml'
    sh submit.sh ./user_configs/lightgcn.yaml
} > $log 2>&1
