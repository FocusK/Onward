#!/bin/bash
#usage: sh submit.sh ./user_configs/multi_metapath2vec.yaml

function parse_yaml {
    local file=$1
    local key=$2
    grep "^$key" $file | sed s/#.*//g | grep $key | awk -F':' -vOFS=':' '{$1=""; print $0;}' | awk '{print $2;}' | sed 's/ //g; s/"//g'
}

unset http_proxy https_proxy
if [ $# -lt 1 ]; then
    echo "config file must be specified !"
    echo "usage: sh pdc_submit.sh ./user_configs/your_config.yaml"
    exit 0
fi

src_config_file=$1
tgt_config_file=./env_run/src/config.yaml
cp ${src_config_file} ${tgt_config_file}


# ------------- k8s gpu group on paddlecloud -----------------------------------#
# The below parameters are set for k8s gpu group on paddlecloud

function correct_hadoop_path() {
    # only support "/your/hadoop/path"
    # do not support "afs:/your/hadoop/path" and "afs://xxx.afs.baidu.com:9902/your/hadoop/path" format, then correct it
    local_path=$1
    if [[ ${local_path} =~ "baidu.com:" ]]; then
        res=`echo ${local_path} | awk -F"/" '{for(i=4;i<=NF;i++){if(i==4){printf("/%s/", $i)}else if(i<NF){printf("%s/", $i)}else{printf("%s", $i)}}}' | awk -F"%" '{print $1}'`
    elif [[ ${local_path} =~ "afs:" ]]; then
        res=`echo ${local_path} | awk -F":" '{print $2}'`
    elif [[ ${local_path} =~ "hdfs:" ]]; then
        res=`echo ${local_path} | awk -F":" '{print $2}'`
    else
        res=${local_path}
    fi
    echo ${res}
}

pdc_info_output_path=`parse_yaml ${tgt_config_file} pdc_info_output_path`
pdc_info_output_path=`correct_hadoop_path ${pdc_info_output_path}`

echo "
fs_name=`parse_yaml ${tgt_config_file} fs_name`
fs_ugi=`parse_yaml ${tgt_config_file} fs_ugi`
output_path="${pdc_info_output_path}"
mount_afs=true
mpi_on_k8s=1
" > ./tmp_config.ini

job_name=`parse_yaml ${tgt_config_file} job_name`
JOB_NAME=`echo ${job_name} | sed "s/\./_/g"`
file_dir="./env_run"
gpus=`grep gpus: ${tgt_config_file} |sed s/#.*//g | grep gpus | awk -F':' '{print $2}' | sed "s/\[//g" | sed "s/\]//g" | sed "s/ //g"`
gpu_num=`echo $gpus | sed "s/\[//g" | sed "s/\]//g" | awk -F"," '{print NF}'`
start_cmd="bash ./scripts/build_env_and_train_run.sh"
job_version="paddle-fluid-custom"
group_name=`parse_yaml ${tgt_config_file} group_name`
k8s_priority=`parse_yaml ${tgt_config_file} k8s_priority`
wall_time=`parse_yaml ${tgt_config_file} wall_time`
image_addr=`parse_yaml ${tgt_config_file} image_addr`
algo_id="algo-8ac58a6aec4940f4"

echo "paddlecloud job parameters: "
echo "JOB_NAME: ${JOB_NAME}; group_name: ${group_name};"
echo "file_dir: ${file_dir}; job_version: ${job_version}"
echo "gpu_num: ${gpu_num}; k8s_priority: ${k8s_priority}"
echo "wall_time: ${wall_time}; image_addr: ${image_addr}"

# please use "paddlecloud config" to set your ak/sk first
paddlecloud job \
    train --job-name $JOB_NAME\
    --job-conf ./tmp_config.ini \
    --group-name ${group_name} \
    --start-cmd "${start_cmd}" \
    --file-dir ${file_dir} \
    --job-version ${job_version}  \
    --k8s-gpu-cards ${gpu_num} \
    --k8s-priority ${k8s_priority} \
    --wall-time ${wall_time} \
    --image-addr ${image_addr} \
    --algo-id ${algo_id}
    $EXTFLAGS

rm ./tmp_config.ini
