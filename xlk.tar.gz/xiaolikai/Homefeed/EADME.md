<!-- Homefeed工作相关 -->
Homefeed
---adapter_fea  特征抽取算子的使用
---business  商业化工作相关
---recall 召回工作相关
---tools 记录HF场景下的一些脚本工具，如离在线一致性
---user_action_ana 分析用户行为数据
---rank_model 记录rank下的各个模型
---off_on_consistence 离在线一致性分析脚本以及其他相关分析脚本