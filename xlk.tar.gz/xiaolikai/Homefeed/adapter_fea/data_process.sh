#!bin/bash
source ~/.bashrc

workPath=`pwd`;
local_data_path="${workPath}/data"
logs_path="${workPath}/logs"
hf_file_name="hf_sample.txt"
hf_sign="hf_train.data"
if [ ! -d "$logs_path" ]; then
    mkdir $logs_path
fi

log=${logs_path}/check_data.log
# hk -getmerge /user/dumi/duer/dumi_bot_rec/homefeed_sample_dump/train_data_new/event_day=20221022/pass=005 hf_data.txt
# #### 下载数据 ####
# # hadoop_path="/user/dumi/duer/dumi_bot_rec/music_rec_pipeline/0_music_sample/music_sample/dt=20220606"
# hadoop_path="/user/dumi_strategy_online/rus/sample_dump/feedback_samhkple/event_day=20220628"
# hk -getmerge ${hadoop_path} "${local_data_path}/${file_name}"

# #### 使用adapter 和 fe处理数据 ####
# # 指定 rec_type，生成json
cat ${local_data_path}/${hf_file_name} | ./adapter -format=b64_zstd -json -rec_type=hf > "./hf_sample.json"

# 生成 feasign
cat ${local_data_path}/${hf_file_name} | ./adapter -format=b64_zstd -pb -rec_type=hf | ./feature-extract -conf_dir=./din/ > './hf_train_data.data'