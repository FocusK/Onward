"""fea_slot
分析HF训练样本中的正负比
"""
#coding:utf-8
import os
import sys
import csv
import json
import numpy as np


def test_train_data_valid(hf_sign_path):
    '''
    下面代码用于验证变长特征及其权重的数量是否对应
    '''

    varlen_slot = {'2003':0,'2004':0,'2005':0,'2006':0,'1006':0,'1007':0}
    varlen_weight_slot = {'12003':0,'12004':0,'12005':0,'12006':0,'11006':0,'11007':0}
    sparse_slot = {'3001':0,'3002':0,'3003':0,'1000':0,'1001':0,'1002':0,'1003':0,'1004':0,'1005':0,'2001':0,'2002':0,'2000':0}
    dense_inputs_slots = {'2010':0,'2011':0,'2012':0,'2013':0,'2014':0,'2015':0,'2016':0, \
            '2017':0,'2018':0,'2019':0,'2020':0,'2021':0,'2022':0,'2023':0,'2024':0,\
            '2025':0,'2026':0,'2027':0,'2028':0,'2029':0,'2030':0,'2031':0,'2032':0,\
            '2033':0,'2034':0,'2035':0}

    flag = 0
    for line in open(hf_sign_path):
        show_click_info, sparse_feature_info, \
            dense_feature_info, label_info, tag_info = line.strip('\r\n').split('\t')
        _, _, label, weight = show_click_info.split(' ')
        if label not in ['0', '1']:
            print('ERROR 1, invalid label')
            print(line)
            flag = 1
        # 计算变长特征权重的频次
        for extract_feature in dense_feature_info.split():
            fea_slot, fea_vals = extract_feature.split(':', 1)
            if fea_slot in varlen_weight_slot:
                varlen_weight_slot[fea_slot] = len(fea_vals.split(':'))
            elif fea_slot in dense_inputs_slots:
                dense_inputs_slots[fea_slot] = 1
            else:
                print('ERROR 2, invalid dense slot')
                print(line)
                flag = 1
        # 计算变长特征的频次
        for extract_feature in sparse_feature_info.split():
            fea_sign, fea_slot = extract_feature.split(':')
            if fea_slot in varlen_slot:
                varlen_slot[fea_slot] = varlen_slot[fea_slot] + 1
            elif fea_slot in sparse_slot:
                sparse_slot[fea_slot] = sparse_slot[fea_slot] + 1
            else:
                print('ERROR 3, invalid sparse slot')
                print(line)
                flag = 1
        # 判断是否所有的稀疏特征都有值
        for key, value in sparse_slot.items():
            if value == 0:
                print('ERROR 4, miss slot %s' % (key))
                print(line)
                flag = 1
        # 判断特征与其权重的频次是否一一对应
        for key, value in varlen_slot.items():
            new_key = "1" + key
            if value != varlen_weight_slot[new_key]:
                print('ERROR5 !!!!!!')
                print(key, '\t', value, '\t', varlen_weight_slot[new_key])
                print(line)
                flag = 1
        # 置零
        for key in varlen_slot.keys():
            varlen_slot[key] = 0
            new_key = "1" + key
            varlen_weight_slot[new_key] = 0
        for key in sparse_slot.keys():
            sparse_slot[key] = 0
        for key in dense_inputs_slots.keys():
            dense_inputs_slots[key] = 0
        
        if flag:
            break
    
    if flag == 0:
        print('%s no problem!' % hf_sign_path)
            
if __name__ == '__main__':
    hf_sign_path = './test2.data'
    print('test %s' % (hf_sign_path))
    test_train_data_valid(hf_sign_path)

















'''
统计NO_ACTION中是否有正样本
'''
# hf_data_path = 'data/hf_data.txt'
# play_cnt = 0
# finished_cnt = 0
# for sample in open(hf_data_path):
#     sample_js = json.loads(sample)
#     sample_js_context = sample_js["context"]
#     for cand in sample_js_context:
#         # 获取用户反馈
#         user_feedback = cand["hf_user_feedback"]["action_type"]
#         is_finished = cand["hf_user_feedback"]["is_finished"]
#         play_seconds = cand["hf_user_feedback"]["play_seconds"]
#         if user_feedback == "NO_ACTION":
#             if is_finished != False:
#                 finished_cnt = finished_cnt + 1
#             if play_cnt > 0:
#                 play_cnt = play_cnt + 1
# print(finished_cnt)
# print(play_cnt)


