# -*- utf-8 -*-
import os
import sys

terms = ["刎","恨","狠","杀","死","毒","赌","诡异","短裙","脱衣","蔡英文","俄乌","丧尸","打架","骂人","辣妹","色情","JK"]

with open("./anti_test_dict.log", 'r') as f:
    for line in f:
        for term in terms:
            if term in line:
                print(line[:-1])
                break


