"""
评估黄反词典的效果
"""
import os
import numpy as np

# step1 读取黄反词典
antiporn_dict = []
with open('single_term.txt', "r") as f:
    for line in f:
        lines = line.strip('\n').split('\t')
        antiporn_dict.append(lines[0])

# step2 加载评估数据
samples = set()
dict_filtered = []
model_n = set()
with open('5hf.txt', 'r') as f:
    for line in f:
        lines = line.strip('\n').split('\t')
        if lines[1] == "0":
            samples.add(lines[0])
        for anti_term in antiporn_dict:
            if anti_term in lines[0]:
                # print(lines[0] + '\t' + anti_term + '\t' + lines[1])
                dict_filtered.append([lines[0], anti_term, lines[1]])
                model_n.add(lines[0])
                break

print("############ tn ##########")
for ele in samples:
    print(ele)
print("############ dict_filtered ##########")
fn = 0
tn = 0
for ele in dict_filtered:
    print(ele[0] + '\t' + ele[1] + '\t' + ele[2])
#     if int(ele[2]) == 1:
#         fn += 1
#     else:
#         tn += 1
# print(fn)
# print(tn)

