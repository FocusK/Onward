# -*- utf-8 -*-
import os
import sys
import csv

file_path = "/ssd1/work/xiaolikai/fly1000.csv"
output = "final.txt"
idx = 0
with open(output, "w") as fin:
    with open(file_path, "r") as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            if idx == 0:
                idx += 1
                continue
            title = row[0]
            fly_res = row[1]
            human_res = row[2]
            simple_fly_res = ""
            if "不适合" in fly_res:
                simple_fly_res = "F"
            elif "适合" in  fly_res:
                simple_fly_res = "T"
            else:
                simple_fly_res = "N"
            fin.write(title + "\t" + simple_fly_res + "\t" + fly_res + "\t" + human_res + "\n")
            
