# -*- coding:utf-8 -*-
import os
import sys
import time
import datetime
import json
import requests
import copy
import websocket
import uuid
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
import logging
import traceback

class History(object):
    role : str
    content : str

    def __init__(self, role, content):
        self.role = role
        self.content = content

class Message(object):
    message : list[dict]
    def __init__(self):
        self.message = []
        pass

    def add_template(self, role, prompt, input_variables, **kwargs):
        inputs = {}
        if input_variables:
            for key in input_variables:
                inputs[key] = kwargs[key]
        content = prompt.format(**inputs)
        self.add(role, content, **kwargs)
    
    def add(self, role, content, **kwargs):
        self.message.append({"role" : role, "content" : content})

    @property
    def data(self):
        return self.message


class FlyBirdServer(object):
    OPENAI_LLM_PATH = "llm/chat"

    url : str = os.environ.get('FLYBIRD_BASE', None) or 'http://offline.aibirdflying.com:8445/flybird/api'
    stream_url :str  = os.environ.get('FLYBIRD_STREAM_BASE', None) or 'ws://offline.aibirdflying.com:8445/flybird/ws/api'
    token : str = os.environ.get('FLYBIRD_KEY', None) or '51ce4e8496656667fc9dc646cf04cdf69c7237bb'
    timeout = float(os.environ.get("FLYBIRD_TIMEOUT", 5.0))
    headers : object = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.96 Safari/537.36',
        'Authorization': f'Bearer {token}',
    }
    
    req : object = {
            "path":"",
            "qid":"",
            "data":{
                "stream":False,
                "temperature":0,
                "max_tokens":1024,
                "n":1,
                "best_of":1,
                "frequency_penalty":0,
                "presence_penalty":0
                }
            }

    history : list[History]

    def __init__(self):
        self.reset()
    
    def reset(self):
        self.history = []

    def resize_history(self, n):
        self.history = self.history[:n]

    def init_req(self, path, **kwargs):
        new_req = copy.deepcopy(FlyBirdServer.req)
        new_req['path'] = path
        new_req['qid'] = str(uuid.uuid1())
        for key in kwargs:
            if key in new_req['data']:
                new_req['data'][key] = kwargs[key]
        return new_req

    def make_embedding_request(self, path, querys, **kwargs):
        new_req = self.init_req(path, **kwargs)
        if path == 'embedding/ada2':
            new_req['data']['prompts'] = querys
        else:
            raise ValueError(f'unknow path {path}')
        return new_req

    def make_llm_request(self, path, prompt_template,  prompt_vals_dict = None, use_history = False, **kwargs):
        if not prompt_template:
            raise ValueError('prompt_template is empty')
        new_req = self.init_req(path, **kwargs)
        if path == 'llm/chat':
            messages = self.make_messages(prompt_template, prompt_vals_dict, use_history, **kwargs)
            new_req['data']['messages'] = messages
        else:
            raise ValueError(f'unknow path {path}')
        
        return new_req

    def make_messages(self, prompt_template, prompt_vals_dict = None, use_history = False, **kwargs):
        message = Message()
        roles = ['system', 'user', 'assistant']
        for role in roles:
            if role in prompt_template:
                message.add_template(role = role, prompt = prompt_template[role], input_variables = prompt_vals_dict.get(role, []), **kwargs)
                if role == 'user' and use_history:
                    self.history.append(History(**message.data[-1]))
        
        return message.data

    def get_result(self, req, use_history = False, **kwargs):
        payload = json.dumps(req)
        response = requests.request("POST", FlyBirdServer.url, headers=FlyBirdServer.headers, data=payload)
        if response.status_code == 200:
            try:
                res = json.loads(response.text.strip())
            except:
                return response.text
        else:
            raise ValueError(f'request error {response.status_code}')

        if res.get('ended', 0) != 1:
            logging.debug(f'req = {payload}')
            raise ValueError(f'response error {response.status_code}, {res}')

        if req['path'] == self.OPENAI_LLM_PATH:
            if res['ended'] == 1:
                answer = res['data'].get('answer','')
            else:
                answer = response.text
            if use_history:
                self.history.append(History(role = 'assistant', content = answer))
            return answer
        elif req['path'] == 'embedding/ada2':
            results = [item["embedding"] for item in res["data"]["embeddings"]]
            return results
        else:
            return response.text

if __name__ == "__main__":
    import time
    flybird_server = FlyBirdServer()
    prompt_template = {
        "system":"",
        "user":"{question}"}
    title_file = "./sv_titles.txt"
    flybird_result = "./flybird_result_random.txt"
    result_list = []
    with open(flybird_result, "a", encoding="utf-8") as file1:
        with open(title_file, "r") as file:
            for line in file:
                line = line.strip('\n').split('\t')
                if len(line) != 1:
                    continue
                # query = "怪兽军团把赛罗哥哥给抓住了，小赛罗孤身前往营救"
                time.sleep(2)
                once_req = flybird_server.make_llm_request("llm/chat", prompt_template, prompt_vals_dict = {'user' : ['question']},
                            question = line[0])
                once_res = flybird_server.get_result(once_req)
                result_list.append([line[0], once_res])
                file1.write(line[0]+'\t'+once_res+"\n")
                
                