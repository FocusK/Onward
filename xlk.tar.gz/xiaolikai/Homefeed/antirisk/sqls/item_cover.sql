udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_sv_item_cover_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';
create TEMPORARY FUNCTION row_number_by_sort as 'org.apache.hadoop.hive.ql.udf.UDFRowNumberByPreSort';

-- drop table if exists hf_sv_author_cover_table;
create external table if not exists hf_sv_item_cover_table (
    resource_id string,
    show_nums string
) partitioned by (event_day string)
row format delimited fields terminated by '\t'
location 'afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/hf_exp_ana/hf_item_cover_table';


-- select
--     tb.id, tb.image
-- from(
--     select
--         resource_id
--     from hf_sv_item_cover_table
--     where event_day="20230611"
-- )ta
-- inner join(
--     select id, image 
--     from udw_ns.default.duer_bot_video_es_info
--     where event_day="20230616"
-- )tb
-- on ta.resource_id = tb.id;


-- select
--     tb.name
-- from(
--     select
--         resource_id
--     from hf_sv_item_cover_table
--     where event_day="20230611"
--     order by rand()
--     limit 2000
-- )ta
-- inner join(
--     select id, name
--     from udw_ns.default.duer_bot_video_es_info
--     where event_day="20230616"
-- )tb
-- on ta.resource_id = tb.id;


select
    td.resource_id
from(
    select 
        distinct ta.userid, ta.resource_id, ta.rus_logid
    from(
        select
            userid,
            resource_id,
            rus_logid
        from duer_ns.homefeed_user_show_feedback_detail_data_1d
        where event_day <= "20230704"
            and event_day >= "20230701"
            and source_type = "ai.dueros.bot.short_video"
            and action <> "NO_ACTION"
    )ta
)td 
order by rand()
limit 1500;
        








-- 统计每个资源的曝光频次
-- insert overwrite table hf_sv_item_cover_table partition (event_day=${hivevar:dst_day})
-- select
--     resource_id, show_nums
-- from(
--     select
--         resource_id,
--         count(*) as show_nums
--     from hf_sv_u2author_table
--     where event_day = "${hivevar:dst_day}"
--     group by resource_id
-- )ta
-- order by show_nums desc;

-- 统计最近一周总资源曝光量
-- select
--     count(*) as all_itemid
-- from hf_sv_u2author_table
-- where event_day="20230619";

-- 统计过去一月top1万的曝光资源的流量占比
-- select
--     count(*) as pv
-- from(
--     select
--         resource_id
--     from hf_sv_item_cover_table
--     where event_day = "20230611"
--     limit 200000
-- )ta 
-- inner join (
--     select
--         resource_id,
--         userid
--     from hf_sv_u2author_table
--     where event_day="20230619"
-- )tb 
-- on ta.resource_id = tb.resource_id;

-- -- 统计过去一月top10万的曝光资源的流量占比
-- select
--     count(*) as pv
-- from(
--     select
--         resource_id
--     from hf_sv_item_cover_table
--     where event_day = "20230611"
--     limit 300000
-- )ta 
-- inner join (
--     select
--         resource_id,
--         userid
--     from hf_sv_u2author_table
--     where event_day="20230619"
-- )tb 
-- on ta.resource_id = tb.resource_id;


-- /user/dumi/duer/dumi_bot_rec/homefeed_sample_dump/feedback_data/homefeed_user_show_feedback_detail_data_1d
-- 统计每次HF曝光对应的uid  resource_id  uploader
-- insert overwrite table hf_sv_u2author_table partition (event_day=${hivevar:dst_day})
-- select
--     tc.userid, tc.resource_id, tc.uploader
-- from(
--     select 
--         distinct ta.userid, ta.resource_id, ta.rus_logid, tb.uploader
--     from(
--         select
--             userid,
--             resource_id,
--             rus_logid
--         from duer_ns.homefeed_user_show_feedback_detail_data_1d
--         where event_day <= "${hivevar:dst_day}"
--             and event_day >= "${hivevar:start_day}"
--             and source_type = "ai.dueros.bot.short_video"
--             and action <> "NO_ACTION"
--     )ta
--     inner join(
--         select id, uploader 
--         from udw_ns.default.duer_bot_video_es_info
--         where event_day>=date_sub(concat(substr("${hivevar:start_day}", 1, 4), '-', substr("${hivevar:start_day}", 5, 2), '-', substr("${hivevar:start_day}", 7, 2)), 7) 
--             and event_day<="${hivevar:dst_day}"
--     )tb
--     on ta.resource_id = tb.id
-- )tc;




-- -- 计算每个作者的被曝光PV
-- insert overwrite table hf_sv_author_cover_table partition (event_day=${hivevar:dst_day})
-- select
--     *
-- from(
--     select
--         uploader,
--         count(*) as show_nums
--     from hf_sv_u2author_table
--     where event_day="${hivevar:dst_day}"
--     group by uploader
-- ) td
-- order by td.click_nums desc;


-- -- 计算最近一个月内活跃的用户总量UV
-- select
--     distinct userid
-- from hf_sv_u2author_table
-- where event_day="${hivevar:dst_day}";

-- -- 计算最近一个月内PV
-- select
--     count(*) as pv
-- from hf_sv_u2author_table
-- where event_day="${hivevar:dst_day}";


-- -- top100作者覆盖资源数
-- select
--     count(*) as pv,  -- 这100个作者的影响面
--     count(distinct tb.resource_id) as uv  -- 这100个作者覆盖多少用户
-- from(   -- 统计头部100 uploader
--     select
--         uploader
--     from hf_sv_author_cover_table  
--     where event_day="${hivevar:dst_day}"
--     limit 100
-- )ta
-- inner join
-- (
--     select
--         userid,
--         uploader
--     from hf_sv_u2author_table   -- 最近一个月每条点击日志下 uid -- uploader
--     where event_day="${hivevar:dst_day}"
-- )tb
-- on ta.uploader = tb.uploader;

-- -- top100作者覆盖资源数
-- select
--     count(distinct tb.resource_id) as nums
-- from(
--     select
--         uploader
--     from hf_sv_author_cover_table
--     where event_day="${hivevar:dst_day}"
--     limit 100
-- )ta
-- inner join
-- (
--     select
--         resource_id,
--         uploader
--     from hf_sv_u2author_table
--     where event_day="${hivevar:dst_day}"
-- )tb
-- on ta.uploader = tb.uploader;


-- -- top500作者覆盖资源数
-- select
--     count(*) as pv,  -- 这500个作者的影响面
--     count(distinct tb.resource_id) as uv  -- 这500个作者覆盖多少用户
-- from(   -- 统计头部500 uploader
--     select
--         uploader
--     from hf_sv_author_cover_table  
--     where event_day="${hivevar:dst_day}"
--     limit 500
-- )ta
-- inner join
-- (
--     select
--         userid,
--         uploader
--     from hf_sv_u2author_table   -- 最近一个月每条点击日志下 uid -- uploader
--     where event_day="${hivevar:dst_day}"
-- )tb
-- on ta.uploader = tb.uploader;

-- -- top500作者覆盖资源数
-- select
--     count(distinct tb.resource_id) as nums
-- from(
--     select
--         uploader
--     from hf_sv_author_cover_table
--     where event_day="${hivevar:dst_day}"
--     limit 500
-- )ta
-- inner join
-- (
--     select
--         resource_id,
--         uploader
--     from hf_sv_u2author_table
--     where event_day="${hivevar:dst_day}"
-- )tb
-- on ta.uploader = tb.uploader;


-- -- top1000作者覆盖资源数
-- select
--     count(*) as pv,  -- 这1000个作者的影响面
--     count(distinct tb.resource_id) as uv  -- 这1000个作者覆盖多少用户
-- from(   -- 统计头部100 uploader
--     select
--         uploader
--     from hf_sv_author_cover_table  
--     where event_day="${hivevar:dst_day}"
--     limit 1000
-- )ta
-- inner join
-- (
--     select
--         userid,
--         uploader
--     from hf_sv_u2author_table   -- 最近一个月每条点击日志下 uid -- uploader
--     where event_day="${hivevar:dst_day}"
-- )tb
-- on ta.uploader = tb.uploader;

-- -- top1000作者覆盖资源数
-- select
--     count(distinct tb.resource_id) as nums
-- from(
--     select
--         uploader
--     from hf_sv_author_cover_table
--     where event_day="${hivevar:dst_day}"
--     limit 1000
-- )ta
-- inner join
-- (
--     select
--         resource_id,
--         uploader
--     from hf_sv_u2author_table
--     where event_day="${hivevar:dst_day}"
-- )tb
-- on ta.uploader = tb.uploader;