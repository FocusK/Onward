#!/bin/bash
source ~/.bashrc

#### common header ####
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
sqls=${workPath}/sqls_youku
logs=${workPath}/logs

#### 日期范围 ####
dst_day=$1
if [ ! -n "$1" ];then
    dst_day=$(date -d "last day" +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)
start_day=$(date -d "-5 days $dst_day" +%Y%m%d)

#### 生成当天数据 ####
log="${logs}/yk_vod_hot_data_${dst_day}.log"

cd ${sqls}
{
    rm *.txt
    # 初步构建热门优酷数据
    echo "run sql for getting origin youku hot data..."
    qexlk -f youku_vod_hot_resources_ana.sql --hivevar currentDate=${curDate} start_day=$start_day end_day=$dst_day 

    # 本地进行数据后处理
    echo "download data to local, run post process"
    hadoop_base="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/youku_hot_resource"
    hadoop_path=${hadoop_base}/"event_day=${dst_day}"
    local_origin_path=${sqls}/"youku_origin_data.txt"
    local_final_path=${sqls}/"youku_hot_vod.txt"
    hk -getmerge ${hadoop_path} ${local_origin_path}
    set +e
    hk -rmr ${hadoop_path}
    hk -rmr "${hadoop_base}/*"
    set -e

    py3 post_process.py ${local_origin_path} ${local_final_path}

    # 上传至hadoop
    hk -put ${local_final_path} ${hadoop_base} 
    echo "success upload file to hadoop"
    # 传到RUS机器
    RUS_DEST_PATH="/home/disk1/rus/offline-pipeline-routine/baidu/oxygen/rus-pipeline/pipeline-migrate/HotPoolItemPipeline/data/mis_local/hot_category_item_pool"
    scp_file_to_rus ${local_final_path} ${RUS_DEST_PATH}
    echo "success copy file to rus"
} > ${log} 2>&1
