# -*- coding: utf-8 -*-

"""
    Author: Xiao Likai
    Date: 2023-01-29 10:36
    Desc: 芒果/优酷热榜数据后处理
"""
import os
import sys

def post_process(input_file, output_file):
    """
        输入: 热榜数据文件, 每列为 resource_id  source_from(session/top_list)
        输出: 处理后的数据文件, 每列为 ai.dueros.bot.short_video  resource_id  source_from  score
        功能: 默认初始score为1 去重, 重复的资源id保留top_list来源并累加score
    """
    hot_resources = []
    # 读入原始数据, 并做排序处理
    with open(input_file, 'r') as f_in:
        for line in f_in:
            mess = line.strip('\n').split('\t')
            if len(mess) != 2:
                continue
            hot_resources.append([mess[0], mess[1], 1.0])
    hot_resources.sort(key=lambda x:x[0], reverse=False)
    post_hot_resources = [hot_resources[0]]
    # 重复资源处理
    for idx in range(1, len(hot_resources)):
        last_idx = len(post_hot_resources) - 1
        if hot_resources[idx][0] == post_hot_resources[last_idx][0]:
            post_hot_resources[last_idx][2] += hot_resources[idx][2]
        else:
            post_hot_resources.append(hot_resources[idx])
    # 写入至输出文件
    source_type = 'ai.dueros.bot.video_on_demand'
    with open(output_file, 'w') as f_out:
        for ele in post_hot_resources:
            ele = [source_type, "VD_" + ele[0], ele[1], str(ele[2])]
            f_out.writelines('\t'.join(ele) + '\n')
    
if __name__ == '__main__':
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    post_process(input_file, output_file)

