udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=1;
SET mapred.reduce.tasks=1;
SET mapred.job.name=duer_strategy_youku_vod_hot_resources_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';
create TEMPORARY FUNCTION row_number_by_sort as 'org.apache.hadoop.hive.ql.udf.UDFRowNumberByPreSort';

drop table if exists youku_hot_resource;

create external table if not exists youku_hot_resource(
    resource_id string,
    source_from string
) partitioned by (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/youku_hot_resource";

insert overwrite table youku_hot_resource partition (event_day="${hivevar:end_day}")
select
    resource_id,
    source_from
from(
    select --播放pv300以上
        distinct
        id as resource_id,
        data_from as source_from
    from udw_ns.default.duer_bot_data_top_resources 
    where event_day = "${hivevar:end_day}"
        and bot = "vod"
        and site_name = "youku_mobile"
        and data_from = "session"
        and hot >= 50
    union all
    select  -- 各个榜单前10名
        distinct 
        id as resource_id,
        substr(sub_from, 6) as source_from
    from udw_ns.default.duer_bot_data_top_resources 
    where event_day = "${hivevar:end_day}"
        and bot = "vod"
        and site_name = "youku_mobile"
        and data_from = "toplist"
        and sub_from is not null
        and sub_from != "\N"
        and hot <= 20
)ta;


-- -- 分析热度时效性表中每天芒果和优酷资源的数量
-- select
--     event_day,
--     site_name,
--     count(*) as top_nums
-- from(
--     select
--         distinct event_day, id, site_name
--     from udw_ns.default.duer_bot_data_top_resources 
--     where event_day >= "${hivevar:start_day}" and event_day <= "${hivevar:end_day}"
--         and bot = "short_video"
--         and site_name in ("youku_mobile", "mg_mobile")
-- )ta
-- group by event_day, site_name
-- order by event_day, site_name;
