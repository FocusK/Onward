"""
    @module hotstart from mpi-pslib
    @function
    @class
    @method
"""
import yaml
import numpy as np
from google.protobuf import text_format
import paddle.fluid.incubate.fleet.parameter_server.pslib.ps_pb2 as pslib
import config

class PSlibDenseLoader(object):
    """
    PSlibDenseLoader
    PSlibDenseTranstoPaddle
    """
    def __init__(self, fleet_util):
        self.place = None
        self.scope = None
        self._is_join = None
        self._fleet_util = fleet_util

    def load_dense_model_pslib(self, place, scope, program, model_file_name, variable_names, is_join, test_mode):
        """
        load_dense_model_pslib
        """
        self.place = place
        self.scope = scope
        self._is_join = is_join
        # for var in program.list_vars():
        #     if var.persistable:
        #         self._fleet_util.rank0_info("program var.persistable name : %s" % (var.name))
        # read table
        model_obj = open(model_file_name)
        model_lines = model_obj.readlines()
        line_index = 0
        for variable_name in variable_names:
            # self._fleet_util.rank0_info("process %s...." %(variable_name))
            if 'summary_table' in model_file_name:
                line_index = self.process_summary_param(variable_name, model_lines,
                        line_index)
            else:
                line_index = self.process_dnn_param(variable_name, model_lines,
                        line_index, test_mode)
        self._fleet_util.rank0_info("%s finished...line count: %d" % (model_file_name, line_index))

    def set_tensor(self, name, para):
        """
        set para to tensor specified by name
        """
        para = para.astype(np.float32)
        batch_size_tensor = self.scope.find_var(name).get_tensor()
        batch_size_tensor.set(para, self.place)   

    def get_tensor_shape(self, name):
        """
        set para to tensor specified by name
        """
        batch_size_tensor = self.scope.find_var(name).get_tensor()
        ori_array = np.array(batch_size_tensor)
        return ori_array.shape

    def process_summary_param(self, param, model_lines, line_index):
        """
        process_summary_param
        """
        summary_list = []
        row, = self.get_tensor_shape(param)
        # parse summary
        # self._fleet_util.rank0_info('param %s shape: [%s]' % (param, row))
        for j in range(row):
            summary_list.append(float(model_lines[line_index]))
            line_index += 1
        summary_array = np.array(summary_list)
        # fill summary to data_norm
        self.set_tensor(param, summary_array)
        return line_index

    def process_dnn_param(self, param, model_lines, line_index, test_mode):
        """
        process_dnn_param
        """
        tensor_shape = self.get_tensor_shape(param)
        # self._fleet_util.rank0_info('param %s shape: [%s]' % (param, tensor_shape))
        dnn_weight_list = []
        dnn_moment1_list = []
        dnn_moment2_list = []
        weight_index = 0
        if test_mode and "use_avg_weight" in dir(config) and config.use_avg_weight:
            # use avg_w instead of w in test_mode
            weight_index = 1
            self._fleet_util.rank0_info("test_mode use avgerage weight: set weight_index = %s", str(weight_index))
        # parse w, avg_w, ada_d2sum, ada_g2sum, mom_velocity
        for j in range(np.prod(tensor_shape)):
            fields = model_lines[line_index].split()
            dnn_weight_list.append(float(fields[weight_index]))
            dnn_moment1_list.append(float(fields[4]))
            dnn_moment2_list.append(float(fields[3]) / float(fields[2]))
            line_index += 1
        dnn_weight_a = np.array(dnn_weight_list).reshape(tensor_shape)
        dnn_moment1_a = np.array(dnn_moment1_list).reshape(tensor_shape)
        dnn_moment2_a = np.array(dnn_moment2_list).reshape(tensor_shape)
        beta_pow = np.array([0]).astype("float32") # actually no need for aibox adam
        self.set_tensor(param, dnn_weight_a)
        if self._is_join:
            prefix = 0
        elif "from_pslib_185" in dir(config) and config.from_pslib_185 is True:
            prefix = 0
        else:
            # old pslib version(eg. microvideo)
            prefix = 1
        if not test_mode:
            self.set_tensor(param + "_beta1_pow_acc_" + str(prefix), beta_pow)
            self.set_tensor(param + "_beta2_pow_acc_" + str(prefix), beta_pow)
            self.set_tensor(param + "_moment1_" + str(prefix), dnn_moment1_a)
            self.set_tensor(param + "_moment2_" + str(prefix), dnn_moment2_a)
        return line_index
