# !/usr/bin/env python
# -*- coding:utf-8 -*-

"""
    @module util
    @function
    @class
    @method
"""
from __future__ import print_function

import os
import time
import numpy as np
from concurrent import futures
import subprocess
import math
import paddle
import paddle.fluid as fluid
from paddle.fluid.incubate.fleet.parameter_server.pslib import fleet
from paddle.fluid.incubate.fleet.utils.fleet_util import GPUPSUtil, FleetUtil
import pslib_model_loader
import paddle.fluid.incubate.fleet.parameter_server.pslib.ps_pb2 as pslib
from google.protobuf import text_format
import decorator
import contextlib

import config

fleet_util = GPUPSUtil()

def clear_metrics(scope, var_list, var_types):
    """
    clear_metrics
    """
    for i in range(len(var_list)):
        fleet_util.set_zero(var_list[i].name, scope, param_type=var_types[i])


def remove_op(program, name):
    """
    remove op
    """
    block = program.global_block()
    for ids, op in list(enumerate(block.ops)):
        if op.type == name:
            block._remove_op(ids)
            return


def remove_backword(program):
    """
    remove_backword
    """
    block = program.global_block()
    last_idx = -1
    for ids, op in list(enumerate(block.ops)):
        if op.type == "scale":
            last_idx = ids
            print(op.type + "  idx:" + str(ids))
            break
    last_idx -= 1 # remove fill_constant
    for ids, op in list(enumerate(block.ops)):
        if ids > last_idx:
            block._remove_op(last_idx + 1)


def split_inner_pass_files(filelist, pass_index, inner_split_pass):
    """
    split_inner_pass_files
    """
    list_len = len(filelist)
    inner_index = (pass_index - 1) % inner_split_pass
    blocksize = list_len // inner_split_pass    # 200
    remainder = list_len % inner_split_pass    # 5
    blocks = [blocksize] * inner_split_pass   # [200 200 ... 200]
    for i in range(remainder):
        blocks[i] += 1  # [201  201  201 .. 201 ... 200]
    split_files = [[]] * inner_split_pass
    begin = 0
    for i in range(inner_split_pass):
        split_files[i] = filelist[begin:begin + blocks[i]]
        begin += blocks[i]
    return split_files[inner_index]

def split_inner_pass_files2(filelist, inner_split_pass):
    """
    split_inner_pass_files
    """
    list_len = len(filelist)
    blocksize = list_len // inner_split_pass    # 200
    remainder = list_len % inner_split_pass    # 5
    blocks = [blocksize] * inner_split_pass   # [200 200 ... 200]
    for i in range(remainder):
        blocks[i] += 1  # [201  201  201 .. 201 ... 200]
    split_files = [[]] * inner_split_pass
    begin = 0
    for i in range(inner_split_pass):
        split_files[i] = filelist[begin:begin + blocks[i]]
        begin += blocks[i]
    return split_files


def get_day_path(online_pass_interval, day, pass_per_day, is_data_hourly_placed):
    """
    get_day_path
    """
    cur_path_list=[]
    for pass_index in range(1, pass_per_day * config.inner_split_pass + 1):
        real_index = (pass_index - 1) // config.inner_split_pass
        cur_pass = online_pass_interval[real_index]
        cur_path = []
        for interval in cur_pass:
            for p in config.train_data_path:
                if is_data_hourly_placed:
                    cur_path.append(p + "/" + day + "/" + interval[:2])
                else:
                    cur_path.append(p + "/" + day + "/" + interval)
        cur_path_list.append(cur_path)
    return cur_path_list


def create_slots_name(slot_name):
    """
    create_slots_name
    """
    all_slot = []
    with open(slot_name) as fin:
        for i in fin:
            all_slot.append(i.strip())
    return all_slot


def get_metrics(scope, name):
    """
    get_mtrics
    """
    metric = np.array(scope.find_var(name).get_tensor())
    old_metric_shape = np.array(metric.shape)
    metric = metric.reshape(-1)
    global_metric = np.copy(metric) * 0
    fleet._role_maker._all_reduce(metric, global_metric)
    global_metric = global_metric.reshape(old_metric_shape)
    return global_metric[0]


def get_global_metrics_str(scope, metric_list, prefix):
    """
    get_global_metrics_str
    """
    if len(metric_list) != 10 and len(metric_list) != 6:
        raise ValueError("len(metric_list) != 10 and !=6, %s" % len(metric_list))
    if len(metric_list) == 10:
        auc, bucket_error, mae, rmse, actual_ctr, predicted_ctr, copc, \
        mean_predict_qvalue, total_ins_num = fleet_util.get_global_metrics( \
            scope, metric_list[2].name, metric_list[3].name, metric_list[4].name, metric_list[5].name, \
            metric_list[6].name, metric_list[7].name, metric_list[8].name, metric_list[9].name)
        metrics_str = "%s global AUC=%.6f BUCKET_ERROR=%.6f MAE=%.6f "\
                      "RMSE=%.6f Actural_CTR=%.6f Predicted_CTR=%.6f "\
                      "COPC=%.6f MEAN Q_VALUE=%.6f Ins number=%s" % \
                      (prefix, auc, bucket_error, mae, rmse, \
                      actual_ctr, predicted_ctr, copc, mean_predict_qvalue, \
                      total_ins_num)
    elif len(metric_list) == 6:
        local_sqrerr, local_abserr, local_prob, local_q, local_pos_num, local_ins_num = metric_list
        global_abserr = get_metrics(scope, local_abserr.name)
        global_sqrerr = get_metrics(scope, local_sqrerr.name)
        global_prob = get_metrics(scope, local_prob.name)
        global_pos_num = get_metrics(scope, local_pos_num.name)
        total_ins_num = get_metrics(scope, local_ins_num.name)
        mae = math.sqrt(global_abserr / total_ins_num)
        rmse = math.sqrt(global_sqrerr / total_ins_num)
        auc_ctr = global_pos_num / total_ins_num
        pre_ctr = global_prob / total_ins_num
        copc = 0.0
        if abs(pre_ctr > 1e-6):
            copc = auc_ctr / pre_ctr
            metrics_str = "%s global MAE=%.6f RMSE=%.6f Actural_CTR=%.6f Predicted_CTR=%.6f COPC=%.6f Ins number=%s" % \
                          (prefix, mae, rmse, auc_ctr, pre_ctr, copc, total_ins_num)
    return metrics_str


def save_paddle_inference_model(
                                hdfs_client,
                                executor,
                                scope,
                                program,
                                feeded_vars,
                                target_vars,
                                output_path,
                                day,
                                pass_id,
                                hadoop_fs_name,
                                hadoop_fs_ugi,
                                hadoop_home="$HADOOP_HOME",
                                path_idx="model",
                                save_combine=True):
    """
    save paddle inference model, and upload to hdfs dnn_plugin path
    """
    fleet_util.rank0_info("begin save_paddle_inference_model ....")
    day = str(day)
    pass_id = str(pass_id)
    feeded_var_names = [i.name for i in feeded_vars]
    model_name = "inference_model"
    prog = program.clone()
    out = prog.global_block().var("click")
    prog.global_block()._insert_op(
                                    0,
                                    type='fill_constant',
                                    outputs={"Out": out},
                                    attrs = {
                                        "value": 0.0,
                                        "force_cpu": True,
                                        "shape": [1, 1],
                                        "dtype": out.dtype
                                    }
                                )
    # pull dense before save
    if fleet.worker_index() == 0:
        begin = time.time()
        with fluid.scope_guard(scope):
            if save_combine:
                fluid.io.save_inference_model(
                    dirname=model_name,
                    feeded_var_names=feeded_var_names,
                    target_vars=target_vars,
                    executor=executor,
                    main_program=prog,
                    params_filename="params")
            else:
                fluid.io.save_inference_model(
                    dirname=model_name,
                    feeded_var_names=feeded_var_names,
                    target_vars=target_vars,
                    executor=executor,
                    main_program=prog)
        fleet_util.rank0_info("save save_inference_model cost %s s" % (time.time() - begin))
        if pass_id == "-1":
            dest = "%s/%s/base/dnn_plugin/%s/" % (output_path, day, path_idx)
        else:
            dest = "%s/%s/delta-%s/dnn_plugin/%s/" % (output_path, day,
                                                   pass_id, path_idx)
        if not hdfs_client.is_exist(dest):
            hdfs_client.mkdirs(dest)
        dest_model_path = dest + "/" + model_name
        if not hdfs_client.is_exist(dest_model_path):
            hdfs_client.mkdirs(dest_model_path)
        inference_file_list = os.listdir('./' + model_name)
        for file in inference_file_list:
            hdfs_client.upload('./' + model_name + '/' + file, dest_model_path + '/' + file)
        # hdfs_client.upload(model_name, dest_model_path)


def save_delta(hdfs_client, config, day, pass_index, xbox_base_key,
                cur_path, exe, scope_join, scope_update, join_model, update_model,
                join_save_params, update_save_params):
    """
    save xbox or delta model
    """

    fleet_util.rank0_info("begin save delta model for %s - %s" % (day, pass_index))
    begin = time.time()
    fleet.set_file_num_one_shard(0, 1)
    if pass_index == -1:
        # fleet_util.save_xbox_base_model(config.output_path, day)
        suffix_name = "/%s/base/" % day
        model_path = config.output_path + suffix_name
        fleet.save_one_table(0, model_path, mode=2)
    else:
        suffix_name = "/%s/delta-%s/" % (day, pass_index)
        model_path = config.output_path + suffix_name
        fleet.save_one_table(0, model_path, mode=1)
    end = time.time()
    fleet_util.rank0_info("save delta sparse model cost %s min" % ((end - begin) / 60.0))

    # only save
    if fleet.worker_index() == 0:
        if pass_index == -1:
            model_path = "%s/%s/base/dnn_plugin/" % (config.output_path, day)
        else:
            model_path = "%s/%s/delta-%s/dnn_plugin/" % (config.output_path,
                                                    day, pass_index)
        # only save dense vars in xbox base, delta only need inference_model
        if pass_index == -1:
            fleet_util.rank0_info("going to save delta dense model %s" % model_path)
            if join_model is not None:
                with fluid.scope_guard(scope_join):
                    join_vars = [join_model._train_program.global_block().var(i) for i in join_save_params]
                    fluid.io.save_vars(exe, "./", join_model._train_program,
                                        vars=join_vars, filename="paddle_dense.model.0")
            if update_model is not None:
                with fluid.scope_guard(scope_update):
                    update_vars = [update_model._train_program.global_block().var(i) for i in update_save_params]
                    fluid.io.save_vars(exe, "./", update_model._train_program, vars=update_vars,
                                    filename="paddle_dense.model.1")

            if hdfs_client.is_exist(model_path):
                hdfs_client.delete(model_path)
            hdfs_client.mkdirs(model_path)
            if join_model is not None:
                join_model_path = model_path + "/paddle_dense.model.0"
                hdfs_client.upload("./paddle_dense.model.0", join_model_path)
            if update_model is not None:
                update_model_path = model_path + "/paddle_dense.model.1"
                hdfs_client.upload("./paddle_dense.model.1", update_model_path)
    end = time.time()
    fleet_util.rank0_info("end save delta cost %s min" % ((end - begin) / 60.0))


def save_checkpoint_sparse_model(output_path, day, pass_id, mode):
    """
    save_checkpoint_sparse_model
    """
    fleet_util.rank0_info("begin save delta model for %s - %s" % (day, pass_id))
    begin = time.time()
    model_path = "%s/%s/%s/" % (output_path, day, pass_id)
    fleet_util.rank0_info("going to save sparse model %s" % model_path)
    fleet.set_date(0, day)
    fleet.set_file_num_one_shard(0, 1)
    fleet.save_one_table(0, model_path, mode=mode)
    fleet_util.rank0_info("save sparse model done, cost time %s min " % ((time.time() - begin) / 60.0))


def save_model(thread_executor, hdfs_client, output_path, day, pass_id, exe, join_program, scope1,
               update_program=None, scope2=None, mode=0):
    """
    save checkpoint or batch model
    mode: 0 means save all pserver model (checkpoint)
          3 means save batch model
    """
    def name_not_have_sparse(var):
        """
        persistable var which not contains pull_box_sparse
        """
        res = "sparse" not in var.name and fluid.io.is_persistable(var)
        return res
    begin = time.time()
    task = thread_executor.submit(save_checkpoint_sparse_model, output_path, day, pass_id, mode)
    task_list = [task]

    if fleet.worker_index() == 0:
        model_path = "%s/%s/%s/001/" % (output_path, day, pass_id)
        fleet_util.rank0_info("going to save dense model %s" % model_path)
        if join_program is not None:
            with fluid.scope_guard(scope1):
                fluid.io.save_vars(exe, "./", join_program, predicate=name_not_have_sparse, 
                                    filename="paddle_dense.model.0")
        if update_program is not None:
            with fluid.scope_guard(scope2):
                fluid.io.save_vars(exe, "./", update_program, predicate=name_not_have_sparse,
                                    filename="paddle_dense.model.1")
        if hdfs_client.is_exist(model_path):
            hdfs_client.delete(model_path)
        hdfs_client.mkdirs(model_path)
        if join_program is not None:
            join_model_path = model_path + "/paddle_dense.model.0"
            hdfs_client.upload("./paddle_dense.model.0", join_model_path)
        if update_program is not None:
            update_model_path = model_path + "/paddle_dense.model.1"
            hdfs_client.upload("./paddle_dense.model.1", update_model_path)
    end = time.time()
    fleet_util.rank0_info("save dense model done, cost time %s min " % ((end - begin) / 60.0))
    futures.wait(task_list, return_when = futures.ALL_COMPLETED)
    end = time.time()
    fleet_util.rank0_info("save model done, all cost time %s min " % ((end - begin) / 60.0))


def load_model(hdfs_client, path, exe, join_program, join_scope, update_program, update_scope,
               place, join_save_params, update_save_params, load_mode):
    """
    load_model
    if test_mode = True, only load param for join program
    if test_mode = False, load param for join program & update program
    """
    test_mode = update_program is None
    # load sparse model
    begin = time.time()
    if "is_hot_from_pslib" not in dir(config) or config.is_hot_from_pslib is False:
        fleet.set_file_num_one_shard(0, 1)
    # mode=0: load checkpoint
    # mode=1: load delta
    # mode=2: load xbox
    if "is_hot_from_pslib" not in dir(config) or config.is_hot_from_pslib is False:
        fleet.load_one_table(0, path, mode = load_mode + 4)
    else:
        fleet.load_one_table(0, path, mode = load_mode + 4)
    end = time.time()
    fleet_util.rank0_info("load sparse model done, cost time %s min " % ((end - begin) / 60.0))
    # load dense model
    def name_not_have_sparse(var):
        """
        persistable var which not contains pull_box_sparse
        """
        res = "sparse" not in var.name and fluid.io.is_persistable(var)
        return res
    begin = time.time()
    if fleet.worker_index() == 0:
        if "is_hot_from_pslib" in dir(config) and config.is_hot_from_pslib is True:
            # hot start from pslib (3 table)
            model_path = "%s/dnn_plugin/" % (path)
            os.system("rm -rf ./dnn_plugin/")
            os.mkdir("./dnn_plugin/")
            hdfs_client.download(model_path, "./dnn_plugin/")
            fleet_util.rank0_info('hotstart dense from pslib(paddle-fleet)...')
            ml = pslib_model_loader.PSlibDenseLoader(fleet_util)
            # read pslib prototxt
            ps_param = pslib.PSParameter()
            with open("fleet_desc.prototxt") as f:
                text_format.Merge(f.read(), ps_param)

            #trainer_param_len = len(ps_param.trainer_param)
            #assert trainer_param_len == 1, 'not support trainer_param len: %s' % trainer_param_len
            dense_tables = ps_param.trainer_param[0].dense_table
            # new fleet_desc
            if len(ps_param.trainer_param) > 1:
                dense_tables_2 = ps_param.trainer_param[1].dense_table
            if join_program:
                variable_names = list(dense_tables[0].dense_variable_name)
                ml.load_dense_model_pslib(place, join_scope, join_program,
                        "./dnn_plugin/join_dnn_table", variable_names, True, test_mode)
                variable_names = list(dense_tables[1].dense_variable_name)
                ml.load_dense_model_pslib(place, join_scope, join_program,
                        "./dnn_plugin/join_summary_table", variable_names, True, test_mode)

            if update_program:
                if "only_update" in dir(config) and config.only_update == True:
                    variable_names = list(dense_tables[0].dense_variable_name)
                    ml.load_dense_model_pslib(place, update_scope, update_program,
                        "./dnn_plugin/update_table", variable_names, False, test_mode)
                else: 
                    if len(dense_tables) > 2:
                        variable_names = list(dense_tables[2].dense_variable_name)
                    else:
                        variable_names = list(dense_tables_2[0].dense_variable_name)
                    ml.load_dense_model_pslib(place, update_scope, update_program,
                        "./dnn_plugin/update_table", variable_names, False, test_mode)
        else:
            # hot start from paddle (psgpu)
            if load_mode == 1 or load_mode == 2:
                # load xbox or delta
                model_path = "%s/dnn_plugin/" % (path)
            else:
                 # load checkpoint
                model_path = "%s/001/" % (path)
                fleet_util.rank0_info("model_path: %s" % model_path)

            if join_program:
                os.system("rm -rf ./paddle_dense.model.0")
                hdfs_client.download(model_path + "paddle_dense.model.0", "./paddle_dense.model.0")
                
            if update_program:
                os.system("rm -rf ./paddle_dense.model.1")
                hdfs_client.download(model_path + "paddle_dense.model.1", "./paddle_dense.model.1")

            fleet_util.rank0_info("download dense model done, cost time %s min " % ((time.time() - begin) / 60.0))

            # load xbox (save xbox vars)
            if load_mode != 0:
                if join_program:
                    join_vars = [join_program.global_block().var(i) for i in join_save_params]
                    with fluid.scope_guard(join_scope):
                        fluid.io.load_vars(exe, "./", join_program, vars=join_vars,
                                        filename="paddle_dense.model.0")
                if update_program:
                    update_vars = [update_program.global_block().var(i) for i in update_save_params]
                    with fluid.scope_guard(update_scope):
                        fluid.io.load_vars(exe, "./", update_program, vars=update_vars,
                                        filename="paddle_dense.model.1")

            # load checkpoint (save_checkpoint perdicate)
            else:
                if join_program: 
                    with fluid.scope_guard(join_scope):
                        fluid.io.load_vars(exe, "./", join_program, predicate=name_not_have_sparse,
                                        filename="paddle_dense.model.0")
                if update_program:
                    with fluid.scope_guard(update_scope):
                        fluid.io.load_vars(exe, "./", update_program, predicate=name_not_have_sparse,
                                        filename="paddle_dense.model.1")


    end = time.time()
    fleet_util.rank0_info("download + load dense model done, cost time %s min " % ((end - begin) / 60.0))

## cuda graph
def can_use_cuda_graph():
    """ can_use_cuda_graph
    """
    return paddle.is_compiled_with_cuda() and not paddle.is_compiled_with_rocm()

global_cuda_graph = None

def enable_cuda_graph(place):
    """ trainer_online中调用, 允许开启图捕获
    """
    if can_use_cuda_graph():
        import paddle.device.cuda.graphs as cuda_graph
        paddle.set_flags({
            'FLAGS_allocator_strategy': 'auto_growth',
            'FLAGS_sync_nccl_allreduce': False,
            'FLAGS_cudnn_deterministic': True,
            'FLAGS_use_stream_safe_cuda_allocator': False,
        })
        global global_cuda_graph
        global_cuda_graph = cuda_graph.CUDAGraph(place, mode="thread_local")


def cuda_graph_begin_capture():
    """ 开始捕获图, 要求被捕获的算子不能有可变的输入和输出
    """
    if global_cuda_graph is not None:
        global_cuda_graph.capture_begin()


def cuda_graph_end_capture():
    """ 停止捕获
    """
    if global_cuda_graph is not None:
        global_cuda_graph.capture_end()
        # 释放, 实际上不需要这个图
        global_cuda_graph.reset()

def mean_with_mask(value, mask):
    """ mean_with_mask
    """
    value = paddle.multiply(value, mask)
    num = paddle.maximum(paddle.ones([1], 'float32'),
        paddle.sum(mask))
    loss_tmp = paddle.sum(value) / num
    return loss_tmp


@decorator.decorator
def signature_safe_contextmanager(func, *args, **kwargs):
    """ copy from paddle/fluid/wrapped_decorator.py
    """
    wrapped_func = contextlib.contextmanager(func)
    return wrapped_func(*args, **kwargs)



@signature_safe_contextmanager
def cuda_graph_capture_guard(need_capture=True):
    """ 为了支持 with utils.cuda_graph_capture_guard() 的语法
    """
    if need_capture:
        cuda_graph_begin_capture()
    yield
    if need_capture:
        cuda_graph_end_capture()


@signature_safe_contextmanager
def stop_cuda_graph_capture_guard(need_capture=False):
    """ 临时停止捕获
    """
    if not need_capture:
        cuda_graph_end_capture()
    yield
    if not need_capture:
        cuda_graph_begin_capture()


def captured_data(*args, **kwargs):
    """ 将data复制一份, 使后续计算可以被cudagraph捕获
        stop_capture: 临时停止cuda_graph_capture, 用于在捕获过程中才初始化data
    """
    d = fluid.layers.data(*args, **kwargs)
    if global_cuda_graph is not None:
        copied = fluid.layers.assign(d)
        copied.input_data = d
        return copied
    return d


def get_input_data(data):
    """ 获取使用self.data创建的实际输入
    """
    if hasattr(data, 'input_data'):
        return data.input_data
    return data


def can_nccl_capture():
    """ https://docs.nvidia.com/deeplearning/nccl/user-guide/docs/usage/cudagraph.html
    Starting with NCCL 2.9, NCCL operations can be captured by CUDA Graphs.
    """
    if not hasattr(paddle.fluid.core, 'nccl_version'):
        return False
    return int(paddle.fluid.core.nccl_version()) >= 2900
    

def alarm(str):
    """ alarm
    """
    os.system('sh scripts/alarm.sh ' + str)


