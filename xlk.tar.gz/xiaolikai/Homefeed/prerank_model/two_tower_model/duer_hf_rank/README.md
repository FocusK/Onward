# GPUPS 使用
## 执行以下命令可以开始集群训练

```
1. 修改config.py, 包括fs_name\ugi、train_data_path、output_path、slot_path等信息
2. 修改conf/config.ini,包括队列名、任务名、paddlecloud打包路径
3. 提交任务：bash -x scripts/submit.sh train
```

* 执行以下命令可以开始集群预测infer

```
1. 修改config.py, 包括fs_name\ugi、train_data_path、output_path、slot_path等信息
2. 修改conf/config.ini,包括队列名、任务名、paddlecloud打包路径
3. 提交任务：bash -x scripts/submit.sh test
```

## 执行以下命令可以开始本地训练

```
第一次：
1. 创建docker容器: registry.baidu.com/paddlecloud/base-images:paddlecloud-centos7.8-gcc8.2-cuda11.0-cudnn8 
export CUDA_SO="$(\ls /usr/lib64/libcuda* | xargs -I{} echo '-v {}:{}') $(\ls /usr/lib64/libnvidia* | xargs -I{} echo '-v {}:{}')"
export DEVICES="$(\ls /dev/nvidia* | grep -v cap | xargs -I{} echo '--device {}:{}') $(\ls /dev/nvidia-caps/* | xargs -I{} echo '--device {}:{}')"
export NVIDIA_SMI="-v /usr/bin/nvidia-smi:/usr/bin/nvidia-smi”
sudo docker run ${CUDA_SO} ${DEVICES} ${NVIDIA_SMI} -d --privileged --name xxx_psgpu_dev(修改) --network=host --security-opt seccomp=unconfined -it -v /home/users/fengdanlei(修改):/fengdanlei(修改) registry.baidu.com/paddlecloud/base-images:paddlecloud-centos7.8-gcc8.2-cuda11.0-cudnn8 /bin/bash
sudo docker exec -it xxx_psgpu_dev(修改) /bin/bash

2. 环境准备，执行: sh -x scripts/build_local.sh

之后：
1. 修改config.py, 包括fs_name\ugi、train_data_path、output_path、slot_path等信息
2. 执行nohup sh scripts/run_local.sh train &
```

## 执行以下命令可以开始本地预测

```
1. 修改config.py, 包括fs_name\ugi、train_data_path、output_path、slot_path等信息
2. 执行nohup sh scripts/run_local.sh test &
```


## paddlecloud 作业监控
```
1. sh tool/rerun_pdc.sh
```

## 本地训练终止任务
```
1. sh tool/stop_train.sh
```

## 替换自己编译的paddle whl 包
```
1. scripts/before_hook.sh 里注释 hadoop get paddle whl 这一行
2. 将自己编译的paddle whl包放在模型路径 ./bin/ 目录下
```


## paddlepaddle whl 版本说明
```
v1: 小视频全流量任务时使用，202112
v2: 新增全流程优化，202203
v3: 新增afsclient适配afsapi，加速save，与v2对应的trainer_online和util不兼容，202204
v4: 新增beginpass优化,stable分支
```

更多可见wiki： http://wiki.baidu.com/pages/viewpage.action?pageId=1786148863
