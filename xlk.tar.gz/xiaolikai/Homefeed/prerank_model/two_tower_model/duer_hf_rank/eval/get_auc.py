"""
    @module process log for auc
    @function
    @class
    @method cat xx.log | python get_auc.py
"""
#!/usr/bin/env python
#coding=utf-8

import sys
start_day_tag = "going to train day/pass "#"going to train day/pass "
#"wait to train day "
#end_day_tag = "======== END DAY:"
start_pass_tag = "going to train day/pass "
#end_pass_tag = "==== end delta "
auc_tag1 = "join all pass: global AUC="#"join pass: global AUC="
#" join_pass: AUC="
auc_tag2 = "update all pass: global AUC="#"common pass: global AUC="
#" join_common_pass: AUC="
#" update_pass: AUC="
ins_tag = "Ins number="
#" INS Count="

last_day = ""
last_pass = ""
last_auc1 = ""
last_auc2 = ""
print("day,pass,join_auc,update_auc,,ins_count")
for line in sys.stdin:
    line = line.strip()
    #if "  Writing done str" in line:
    #   continue
    if start_day_tag in line:
        start_pos = line.index(start_day_tag) + len(start_day_tag)
        end_pos = line.index("=", start_pos)
        day_pass = line[start_pos:end_pos]#.split("/")
        day = day_pass.split('/')[0]#[0]
        last_day = day
        #cur_pass = day_pass[1]
        #last_pass = cur_pass
    if start_pass_tag in line:
        start_pos = line.index(start_pass_tag) + len(start_pass_tag)
        end_pos = line.index("=", start_pos)
        cur_pass = line[start_pos:end_pos]
        cur_pass = cur_pass.split('/')[-1]
        last_pass = cur_pass

    elif auc_tag1 in line:
        start_pos = line.index(auc_tag1) + len(auc_tag1)
        end_pos = line.index(" ", start_pos)
        last_auc1 = line[start_pos:end_pos]
    elif auc_tag2 in line:
        start_pos = line.index(auc_tag2) + len(auc_tag2)
        end_pos = line.index(" ", start_pos)
        last_auc2 = line[start_pos:end_pos]
        start_pos = line.index(ins_tag) + len(ins_tag)
        ins = line[start_pos:]
        print("%s,%s,%s,%s,%s" % (last_day, last_pass, last_auc1, last_auc2, ins))

