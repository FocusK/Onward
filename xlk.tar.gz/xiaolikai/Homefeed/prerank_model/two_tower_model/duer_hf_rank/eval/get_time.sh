#!/bin/bash
# the log file we need to prcocess
logfile=$1
# the file we need to store the result
result_file=$2
# =======================================================================================
tmp_log_path=".tmp_log_process"

build_cpu_ps_file=${tmp_log_path}/"build_cpu_ps_file"
build_cpu_pull_file=${tmp_log_path}/"build_cpu_pull_file"
build_gpu_ps_file=${tmp_log_path}/"build_gpu_ps_file"
begin_pass_file=${tmp_log_path}/"begin_pass_file"
load_into_memory_file=${tmp_log_path}/"load_into_memory_file"
join_train_file=${tmp_log_path}/"join_train_file"
update_train_file=${tmp_log_path}/"update_train_file"
delta_train_file=${tmp_log_path}/"delta_train_file"
infer_train_file=${tmp_log_path}/"infer_train_file"
save_delta_all_train_file=${tmp_log_path}/"save_delta_all_train_file"
pass_cost_file=${tmp_log_path}/"pass_cost_file"
epoch_file=${tmp_log_path}/"epoch_file"
ins_num_file=${tmp_log_path}/"ins_num_file"
cache_file=${tmp_log_path}/"cache_file"
endpass_file=${tmp_log_path}/"endpass_file"
tmp_file=${tmp_log_path}/"tmp_file"

# =======================================================================================

mkdir ${tmp_log_path}

cat ${logfile} | grep "thread PreBuildTask" | awk -F 'time: ' '{print $2}' | awk -F 's' '{print $1/60}' > ${build_cpu_ps_file}
cat ${logfile} | grep "CpuPS into GpuPS" | awk -F 'cost ' '{print $2}' | awk -F ' ' '{print $1/60}' > ${build_cpu_pull_file}
cat ${logfile} | grep "BuildGPUTask" | awk -F 'time: ' '{print $2}' | awk -F 's' '{print $1/60}' > ${build_gpu_ps_file}
cat ${logfile} | grep "BeginPass end, cost"| awk -F 'time: ' '{print $2}' | awk -F 's' '{print $1/60}' > ${begin_pass_file}
cat ${logfile} | grep "load into memory + shuffle done" | awk -F 'cost ' '{print $2}' | awk -F ' min' '{print $1}'> ${load_into_memory_file}
cat ${logfile} | grep "finished train day" | grep "pass" | awk -F 'join:' '{print $2}' | awk -F ' min' '{print $1}' > ${join_train_file}
cat ${logfile} | grep "finished train day" | grep "pass" | awk -F 'update:' '{print $2}' | awk -F ' min' '{print $1}' > ${update_train_file}
cat ${logfile} | grep "print_table_stat" |awk -F 'cost ' '{print $2}' | awk -F ' min' '{print $1}' > ${cache_file}
cat ${logfile} | grep "EndPass" |awk -F 'cost time: ' '{print $2}' | awk -F 's' '{print $1/60}' > ${endpass_file}
cat ${logfile} | grep "end save delta" | awk -F 'cost ' '{print $2}' | awk -F ' min' '{print $1}' > ${delta_train_file}
cat ${logfile} | grep "paddle_inference_model" | awk -F 'cost ' '{print $2}' | awk -F ' s' '{print $1/60}' > ${infer_train_file}
cat ${logfile} | grep "save delta + inference model" | awk -F 'cost ' '{print $2}' | awk -F ' s' '{print $1/60}' > ${save_delta_all_train_file}
cat ${logfile} | grep "finished train day" | grep "pass" | awk -F 'time cost:' '{print $2}' | awk -F ' min' '{print $1}'  > ${pass_cost_file}
cat ${logfile} | grep "finished train day" | grep "pass" |awk -F 'pass ' '{print $2}' | awk -F ' time cost' '{print $1}'  > ${epoch_file}

cat ${logfile} | grep "join target :realfr" |awk -F 'Ins number=' '{print $2}' > ${ins_num_file}

# paste -d, ${build_cpu_ps_file} ${build_gpu_ps_file} ${load_into_memory_file} ${train_file} ${pass_cost_file} > ${result_file}
# paste -d, ${epoch_file} ${load_into_memory_file} ${train_file} ${pass_cost_file} > ${tmp_file}

# cat ${result_file} | awk -F ',' '{print ($1+$2+$3+$4)/$5*100000}' > ${tmp_file}

# rm ${result_file}
# echo "epoch,build_gpu_ps_time,load_into_memory_time,train_time,insnum,tmp_file" > ${result_file}
echo "epoch,load_into_memory_time,build_cpu,pull,pull_build_gpu,begin_pass,join,update,endpass,cache,delta_train_file,infer_train_file,save_delta_all,total_cost,ins_num" > ${result_file}

paste -d, ${epoch_file} ${load_into_memory_file} ${build_cpu_ps_file} ${build_cpu_pull_file} ${build_gpu_ps_file} ${begin_pass_file} ${join_train_file} ${update_train_file} ${endpass_file} ${cache_file} ${delta_train_file} ${infer_train_file} ${save_delta_all_train_file} ${pass_cost_file} ${ins_num_file}>> ${result_file}

rm -rf ${tmp_log_path}
