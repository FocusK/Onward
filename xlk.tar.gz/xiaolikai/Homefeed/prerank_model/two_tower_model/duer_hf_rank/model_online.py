"""
    @module model
    @function
    @class
    @method
"""
#!/usr/bin/env python
#coding=utf-8

import paddle
import paddle.nn.functional as F
import paddle.fluid as fluid
from paddle.fluid.incubate.fleet.parameter_server.pslib import fleet
from paddle.fluid.incubate.fleet.utils.fleet_util import FleetUtil
from paddle.fluid.layers.nn import _pull_gpups_sparse
import config

class Model(object):
    """
    model
    """
    def __init__(self, all_slots, use_cvm):
        """
        init
        """
        self._train_program = fluid.Program()
        self._startup_program = fluid.Program()
        self._emb_dim = 9 + 3
        self._init_range = 0.2
        self._use_cvm = use_cvm
        self._all_slots = all_slots

        self.user_sparse_inputs_slots = ['1000', '1001', '1002', '1003', '1004', '1005', '1006', '1017',\
            '1018', '1019', '1020', '1021', '1022', '1023', '1024', '1025', '1026', '1027', \
            '1028', '1029', '1030', '1031', '1032']
        self.user_var_sparse_inputs_slots = ['1011', '1012', '1013', '1014', '1033', '1034', '1035', '1036', '1037']
        self.user_var_sparse_inputs_weight_slots = ['11011', '11012', '11013', '11014', '11033',\
             '11034', '11035', '11036', '11037']
        self.item_sparse_inputs_slots = ['2000', '2001', '2002', '2005', '2009', '2010', '3001', '3002', '3003']
        self.item_var_sparse_inputs_slots = ['2003', '2004', '2006']
        self.item_var_sparse_inputs_weight_slots = ['12003', '12004', '12006']
        
        self.user_sparse_slots = [] # 用户侧离散特征
        self.user_sparse_weight_slots = [] # 用户侧mask特征
        self._user_feed_var = [] # 用户塔的输入
        self._user_main_target_var = [] # 用户塔的输出
        self.user_emb_sizes = [] # 用户侧每个特征对应的embedding长度
        self.user_tower_fc_sizes = [(self._emb_dim - 3) * 32, 256, (self._emb_dim - 3) * 2]
        self._tower_emb_dim = 32  # 用户塔和物品塔产出的embeding维度
        
        self.item_sparse_slots = [] # 物品侧离散特征
        self.item_sparse_weight_slots = [] # 物品侧mask特征
        self._item_feed_var = [] # 物品塔的输入
        self._item_main_target_var = [] # 物品塔的输出
        self.item_emb_sizes = [] # 物品侧每个特征对应的embedding长度
        self.item_tower_fc_sizes = [(self._emb_dim - 3) * 15, 256, (self._emb_dim - 3) * 2]
        

        self.gpu_slot = [] # 所有slot
        self.use_var_list = [] # 所有的输入
        self.mf_sizes = []
        self.auc_metrics = {} 
        self.stat_var = []
        
        with fluid.program_guard(self._train_program, self._startup_program):
            with fluid.unique_name.guard():
                ###################### 构建模型输入 + embedding处理 ######################

                self.click = fluid.layers.data(name="click", shape=[-1, 1], dtype="int64", 
                                                lod_level=1, append_batch_size=False)

                self.input_slots_data = [] # 记录除label外所有的输入slot

                for i in self._all_slots:
                    if i in self.user_sparse_inputs_slots + self.user_var_sparse_inputs_slots: # 用户侧离散特征
                        l = fluid.layers.data(name=i, shape=[1], dtype="int64", lod_level=1)
                        self.user_sparse_slots.append(l)
                        self.user_emb_sizes.append(self._emb_dim)
                        self.mf_sizes.append(self._emb_dim - 3)
                    
                    if i in self.user_var_sparse_inputs_weight_slots: # 用户侧weight特征
                        l = fluid.layers.data(name=i, shape=[1], dtype="float32", lod_level=1)
                        self.user_sparse_weight_slots.append(l)

                    if i in self.item_sparse_inputs_slots + self.item_var_sparse_inputs_slots: # 资源侧离散特征
                        l = fluid.layers.data(name=i, shape=[1], dtype="int64", lod_level=1)
                        self.item_sparse_slots.append(l)
                        self.item_emb_sizes.append(self._emb_dim)
                        self.mf_sizes.append(self._emb_dim - 3)

                    if i in self.item_var_sparse_inputs_weight_slots:  # 资源侧weight特征
                        l = fluid.layers.data(name=i, shape=[1], dtype="float32", lod_level=1)
                        self.item_sparse_weight_slots.append(l)
                    self.gpu_slot.append(int(i))
                    self.input_slots_data.append(l)
                
                ##### 处理用户侧特征embedding #####
                user_all_embs = _pull_gpups_sparse(self.user_sparse_slots, self.user_emb_sizes,
                                            is_distributed=True, is_sparse=True)
                assert len(user_all_embs) == len(self.user_sparse_slots)
                user_sparse_embs = user_all_embs[:len(self.user_sparse_inputs_slots)]
                user_var_sparse_embs = user_all_embs[len(self.user_sparse_inputs_slots):]
                
                user_weighted_var_sparse_embs = []
                for i in range(len(user_var_sparse_embs)):
                    user_weighted_var_sparse_embs.append(
                        fluid.layers.elementwise_mul(user_var_sparse_embs[i], self.user_sparse_weight_slots[i])
                    )
                
                ##### 处理资源侧特征embedding #####
                item_all_embs = _pull_gpups_sparse(self.item_sparse_slots, self.item_emb_sizes,
                                            is_distributed=True, is_sparse=True)
                assert len(item_all_embs) == len(self.item_sparse_slots)
                item_sparse_embs = item_all_embs[:len(self.item_sparse_inputs_slots)]
                item_var_sparse_embs = item_all_embs[len(self.item_sparse_inputs_slots):]
                
                item_weighted_var_sparse_embs = []
                for i in range(len(item_var_sparse_embs)):
                    item_weighted_var_sparse_embs.append(
                        fluid.layers.elementwise_mul(item_var_sparse_embs[i], self.item_sparse_weight_slots[i])
                    )
                # 构建模型输入
                self._user_feed_var = user_all_embs + self.user_sparse_weight_slots
                self._item_feed_var = item_all_embs + self.item_sparse_weight_slots

                # fused_seqpool_cvm
                cast_label = fluid.layers.cast(self.click, dtype='float32')
                cast_label.stop_gradient = True
                ones = fluid.layers.fill_constant_batch_size_like(
                    input=self.click, shape=[-1, 1], dtype="float32", value=1) # [batch_size, 1]
                show_clk = fluid.layers.cast(fluid.layers.concat([ones, cast_label], axis=1), dtype='float32') # [batch_size, 2]
                show_clk.stop_gradient = True

                user_cvms = fluid.contrib.layers.fused_seqpool_cvm(
                    user_sparse_embs + user_weighted_var_sparse_embs, 'sum', show_clk, use_cvm=False)
                user_concat = fluid.layers.concat(user_cvms, axis=1)
                user_cvms_tensor = paddle.reshape(user_concat, [-1, len(self.user_sparse_slots), self._emb_dim - 2])
                print("user cvms len: " + str(len(user_cvms)))   # 32
                print("user cvms[0] shape: " + str(user_cvms[0].shape))   #(-1,10)
                print("user concat shape: " + str(user_concat.shape))     #(-1,320)
                print("user cvms_tensor shape: " + str(user_cvms_tensor.shape))  #(-1,32,10)

                item_cvms = fluid.contrib.layers.fused_seqpool_cvm(
                    item_sparse_embs + item_weighted_var_sparse_embs, 'sum', show_clk, use_cvm=False)
                item_concat = fluid.layers.concat(item_cvms, axis=1)
                item_cvms_tensor = paddle.reshape(item_concat, [-1, len(self.item_sparse_slots), self._emb_dim - 2])
                print("item cvms len: " + str(len(item_cvms)))  # 12
                print("item cvms[0] shape: " + str(item_cvms[0].shape))   #(-1,10)
                print("item concat shape: " + str(item_concat.shape))     #(-1,120)
                print("item cvms_tensor shape: " + str(item_cvms_tensor.shape))  #(-1,12,10)

                user_feat_embeddings = fluid.layers.crop_tensor(
                    user_cvms_tensor, shape = [-1, len(self.user_sparse_slots), self._emb_dim - 3], offsets = [0, 0, 1])
                user_feat_embeddings = paddle.reshape(user_feat_embeddings, [-1, len(self.user_sparse_slots) * (self._emb_dim - 3)])
                print("user_feat_embeddings shape is " + str(user_feat_embeddings.shape))

                item_feat_embeddings = fluid.layers.crop_tensor(
                    item_cvms_tensor, shape = [-1, len(self.item_sparse_slots), self._emb_dim - 3], offsets = [0, 0, 1])
                item_feat_embeddings = paddle.reshape(item_feat_embeddings, [-1, len(self.item_sparse_slots) * (self._emb_dim - 3)])
                print("item_feat_embeddings shape is " + str(item_feat_embeddings.shape))


                user_embedded = self.single_tower_net(user_feat_embeddings, self.user_tower_fc_sizes, "user")
                item_embedded = self.single_tower_net(item_feat_embeddings, self.item_tower_fc_sizes, "item")
                # user_embedded = self.deep_net(user_feat_embeddings, self.user_tower_fc_sizes, "user", False)
                # item_embedded = self.deep_net(item_feat_embeddings, self.item_tower_fc_sizes, "item", False)

                print("final user embedded shape is " + str(user_embedded.shape))
                print("final item embedded shape is " + str(item_embedded.shape))

                self._user_main_target_var.append(user_embedded)
                self._item_main_target_var.append(item_embedded)

                similarity = F.cosine_similarity(user_embedded, item_embedded, axis=1).reshape([-1, 1])

                # similarity = fluid.layers.reduce_sum(fluid.layers.elementwise_mul(user_embedded, \
                #                     item_embedded), dim=1, keep_dim=True)
                pred_q = fluid.layers.sigmoid(fluid.layers.clip(similarity, min=-1.0, max=1.0))
                self.predict_score = pred_q
                cost = fluid.layers.log_loss(input=pred_q, label=cast_label)
                self.avg_cost = fluid.layers.mean(x=cost)

                # auc
                binary_predict = fluid.layers.concat(
                    input=[fluid.layers.elementwise_sub(fluid.layers.ceil(pred_q), pred_q), pred_q], axis=1)
                auc, batch_auc, [batch_stat_pos, batch_stat_neg, stat_pos, stat_neg] = \
                    fluid.layers.auc(input=binary_predict, label=self.click, curve='ROC', 
                                        num_thresholds=4096)
                self.batch_auc = batch_auc
                # fluid.layers.Print(batch_auc, summarize=-1, print_tensor_name=False, print_tensor_lod=False, \
                #                 print_tensor_layout=False, print_tensor_type=False, message="batch auc")
                sqrerr, abserr, prob, q, pos, total = \
                    fluid.contrib.layers.ctr_metric_bundle(pred_q, cast_label)
                ls = [stat_pos, stat_neg, sqrerr, abserr, prob, q, pos, total]
                self.stat_var.extend(ls)
                metric_list = [batch_stat_pos, batch_stat_neg, stat_pos, stat_neg, \
                                sqrerr, abserr, prob, q, pos, total]
                metric_types =  ["int64"] * 4 + ["float32"] * 6
                metric_all = [metric_list, metric_types]
                self.auc_metrics["click"] = metric_all
                # for input mapping
                self.use_var_list.append(self.click)
                self.use_var_list.extend(self.input_slots_data)

    def deep_net(self, input, layers, prefix, last_None, lr_x=1.0):
        """
        deep_net
        """
        fc_layers_input = [input]
        fc_layers_size = layers
        if last_None:
            fc_layers_act = ["relu"] * (len(fc_layers_size) - 1) + [None]
        else:
            fc_layers_act = ["relu"] * (len(fc_layers_size))
        scales_tmp = [input.shape[1]] + fc_layers_size
        scales = []
        for i in range(len(scales_tmp)):
            scales.append(self._init_range / (scales_tmp[i] ** 0.5))

        for i in range(len(fc_layers_size)):
            w_name = '{}_{}.w_0'.format(prefix, i)
            b_name = '{}_{}.b_0'.format(prefix, i)

            fc = fluid.layers.fc(
                    input = fc_layers_input[-1],
                    size = fc_layers_size[i],
                    act = fc_layers_act[i],
                    param_attr =
                        fluid.ParamAttr(
                            learning_rate=lr_x,
                            initializer=fluid.initializer.NormalInitializer(
                                loc=0.0, scale=1.0 * scales[i]
                            ),
                            name=w_name
                        ),
                    bias_attr =
                        fluid.ParamAttr(
                            learning_rate=lr_x,
                            initializer=fluid.initializer.NormalInitializer(
                                loc=0.0, scale=1.0 * scales[i]
                            ),
                            name=b_name
                        )
                    )
            fc_layers_input.append(fc)
        
        return fc_layers_input[-1]

    def single_tower_net(self, feat_embeddings, fc_sizes, prefix, lr_x=1.0):
        """
            定义单塔模型
        """
        # feat_embeddings = fluid.layers.crop_tensor(
        #     cvm_tensors, shape = [-1, slots_nums, self._emb_dim - 3], offsets = [0, 0, 1])
        # feat_embeddings = paddle.reshape(feat_embeddings, [-1, slots_nums * (self._emb_dim - 3)])
        # print(prefix + "feat_embeddings shape is " + str(feat_embeddings.shape))

        tower_output = self.deep_net(feat_embeddings, fc_sizes, prefix, False)
        print(prefix + "feat_embeddings shape is " + str(tower_output.shape))
        # print("haha  " + tower_output.shape[1])
        scale = self._init_range / (tower_output.shape[1] ** 0.5)
        click_w = prefix + "_last_fc_w"
        click_b = prefix + "_last_fc_b"
        click_fc = fluid.layers.fc(
            input = tower_output,
            size = self._tower_emb_dim,
            param_attr=fluid.ParamAttr(
                learning_rate=lr_x,
                initializer=fluid.initializer.NormalInitializer(
                    loc=0.0, scale=1.0 * scale
                ),
                name = click_w
            ),
            bias_attr=fluid.ParamAttr(
                learning_rate=lr_x,
                initializer=fluid.initializer.NormalInitializer(
                    loc=0.0, scale=1.0 * scale
                ),
                name = click_b
            ),
        )

        return click_fc

    # def _base_net(self, user_sparse_slots, user_emb_sizes, user_sparse_weight_slots, item_sparse_slots,
    #         item_emb_sizes, item_sparse_weight_slots, label):
    #     """
    #         define base net
    #     """
    #     ones = fluid.layers.fill_constant_batch_size_like(
    #                 input=self.click, shape=[-1, 1], dtype="float32", value=1)
    #     show_clk = fluid.layers.cast(fluid.layers.concat([ones, label], axis=1), dtype='float32')
    #     show_clk.stop_gradient = True
        
    #     # 用户侧特征embedding
    #     user_all_embs = _pull_gpups_sparse(user_sparse_slots, user_emb_sizes,
    #                                         is_distributed=True, is_sparse=True)
    #     assert len(user_all_embs) == len(user_sparse_slots)
    #     user_sparse_embs = user_all_embs[:len(self.user_sparse_inputs_slots)]
    #     user_var_sparse_embs = user_all_embs[len(self.user_sparse_inputs_slots):]
        
    #     self._user_feed_var = user_all_embs + user_sparse_weight_slots  # 用户塔输入

    #     user_weighted_var_sparse_embs = []
    #     for i in range(len(user_var_sparse_embs)):
    #         user_weighted_var_sparse_embs.append(
    #             fluid.layers.elementwise_mul(user_var_sparse_embs[i], user_sparse_weight_slots[i])
    #         )
    #     user_cvms = fluid.contrib.layers.fused_seqpool_cvm(
    #                 user_sparse_embs + user_weighted_var_sparse_embs, 'sum', show_clk, use_cvm=False)
    #     user_concat = fluid.layers.concat(user_cvms, axis=1)
    #     user_cvms_tensor = paddle.reshape(user_concat, [-1, len(self.user_sparse_slots), self._emb_dim - 2])
    #     print("user cvms len: " + str(len(user_cvms)))   # 32
    #     print("user cvms[0] shape: " + str(user_cvms[0].shape))   #(-1,10)
    #     print("user concat shape: " + str(user_concat.shape))     #(-1,320)
    #     print("user cvms_tensor shape: " + str(user_cvms_tensor.shape))  #(-1,32,10)
        
    #     # 物品侧特征embedding
    #     item_all_embs = _pull_gpups_sparse(item_sparse_slots, item_emb_sizes,
    #                                         is_distributed=True, is_sparse=True)
    #     assert len(item_all_embs) == len(item_sparse_slots)
    #     item_sparse_embs = item_all_embs[:len(self.item_sparse_inputs_slots)]
    #     item_var_sparse_embs = item_all_embs[len(self.item_sparse_inputs_slots):]

    #     self._item_feed_var = item_sparse_embs + item_sparse_weight_slots  # 物品塔输入
        
    #     item_weighted_var_sparse_embs = []
    #     for i in range(len(item_var_sparse_embs)):
    #         item_weighted_var_sparse_embs.append(
    #             fluid.layers.elementwise_mul(item_var_sparse_embs[i], item_sparse_weight_slots[i])
    #         )
    #     item_cvms = fluid.contrib.layers.fused_seqpool_cvm(
    #                 item_sparse_embs + item_weighted_var_sparse_embs, 'sum', show_clk, use_cvm=False)
    #     item_concat = fluid.layers.concat(item_cvms, axis=1)
    #     item_cvms_tensor = paddle.reshape(item_concat, [-1, len(item_sparse_slots), self._emb_dim - 2])
    #     print("item cvms len: " + str(len(item_cvms)))  # 12
    #     print("item cvms[0] shape: " + str(item_cvms[0].shape))   #(-1,10)
    #     print("item concat shape: " + str(item_concat.shape))     #(-1,120)
    #     print("item cvms_tensor shape: " + str(item_cvms_tensor.shape))  #(-1,12,10)

    #     # 执行模型
    #     self.user_embedded = self.single_tower_net(user_cvms_tensor, len(user_sparse_slots), \
    #                                 self.user_tower_fc_sizes, "user")
    #     self.item_embedded = self.single_tower_net(item_cvms_tensor, len(item_sparse_slots), \
    #                                 self.item_tower_fc_sizes, "item")

    #     print('user_embedded shape: ' + str(self.user_embedded.shape))  #(-1, 32)
    #     print('user_embedded shape: ' + str(self.user_embedded.shape))  #(-1, 32)

    #     similarity = fluid.layers.reduce_sum(fluid.layers.elementwise_mul(self.user_embedded, \
    #                                 self.item_embedded), dim=1, keep_dim=True)
    #     self.pred_q = fluid.layers.sigmoid(fluid.layers.clip(similarity, min=-15.0, max=15.0))

    #     # 计算loss
    #     cost = fluid.layers.log_loss(input=self.pred_q, label=label)
    #     self.avg_cost = fluid.layers.mean(x=cost)

    #     # 计算auc
    #     binary_predict = fluid.layers.concat(
    #         input=[fluid.layers.elementwise_sub(fluid.layers.ceil(self.pred_q), self.pred_q), self.pred_q], axis=1)
    #     auc, batch_auc, [batch_stat_pos, batch_stat_neg, stat_pos, stat_neg] = \
    #         fluid.layers.auc(input=binary_predict, label=self.click, curve='ROC', 
    #                             num_thresholds=4096)
    #     self.batch_auc = batch_auc

    #     sqrerr, abserr, prob, q, pos, total = \
    #         fluid.contrib.layers.ctr_metric_bundle(self.pred_q, label)
    #     ls = [stat_pos, stat_neg, sqrerr, abserr, prob, q, pos, total]
    #     self.stat_var.extend(ls)
    #     metric_list = [batch_stat_pos, batch_stat_neg, stat_pos, stat_neg, \
    #                     sqrerr, abserr, prob, q, pos, total]
    #     metric_types =  ["int64"] * 4 + ["float32"] * 6
    #     metric_all = [metric_list, metric_types]
    #     self.auc_metrics["click"] = metric_all
        
    #     # 记录模型输入和输出
    #     self.use_var_list.append(self.click)
    #     self.use_var_list.extend(self.input_slots_data)
    #     self._user_main_target_var.append(self.user_embedded) # 用户塔输出
    #     self._item_main_target_var.append(self.item_embedded) # 物品塔输出

    def get_stat_var_names(self):
        """
        get_stat_var_names
        """
        return [v.name for v in self.stat_var]
    
    def get_save_params(self):
        """
        get_save_params
        return list
        """
        save_vars = self._train_program.global_block().vars
        save_params = []
        for var in save_vars:
            if save_vars[var].persistable:
                if not var.startswith("_") and not var.startswith("embedding"):
                    save_params.append(var)
        return save_params
    
    def get_auc_metric_dict(self):
        """
        get_auc_metric_dict
        eg.{"wanbo": [auc_stat_list_wanbo, auc_stat_types_wanbo]}
        """
        return self.auc_metrics