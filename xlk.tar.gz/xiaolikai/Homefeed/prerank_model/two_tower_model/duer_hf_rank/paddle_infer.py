#coding=utf-8

import numpy as np
import argparse
import paddle

from paddle.inference import Config
from paddle.inference import create_predictor


def init_predictor(args):
    if args.model_dir is not "":
        config = Config(args.model_dir)
    else:
        config = Config(args.model_file, args.params_file)

    config.enable_memory_optim()
    config.set_cpu_math_library_num_threads(args.thread)
    if args.use_onnxruntime == 1:
        config.enable_onnxruntime()
        config.enable_ort_optimization()
    elif args.use_onnxruntime == 2:
        # If not specific mkldnn, you can set the blas thread.
        # The thread num should not be greater than the number of cores in the CPU.
        config.enable_mkldnn()
        #config.switch_ir_debug(True)
        #config.set_optim_cache_dir("debug")


    print("thread:", args.thread) 
    predictor = create_predictor(config)
    return predictor


def run(predictor, data):
    # copy img data to input tensor
    output_names = predictor.get_output_names()
    output_tensors = []
    for i, name in enumerate(output_names):
        output_tensor = predictor.get_output_handle(name)
        output_tensors.append(output_tensor)
    input_names = predictor.get_input_names()
    for name in input_names:
        print("input name:", name, data[name].shape)
        input_tensor = predictor.get_input_handle(name)
        input_tensor.set_lod(np.array([[0, 1]]))
        input_tensor.reshape(data[name].shape)
        #print(input_tensor.name)
        input_tensor.copy_from_cpu(data[name].copy())

    # do the inference
    #warm up
    for i in range(20):
        predictor.run()
    import time
    s = time.time()
    for i in range(100):
        predictor.run()
    e = time.time()
    print("total time:", (e - s)*10.0)

    results = []
    # get out data from output tensor
    for output_tensor in output_tensors:
        output_data = output_tensor.copy_to_cpu()
        results.append(output_data)

    return results


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model_file",
        type=str,
        default="./infer_model_hf/__model__",
        help="Model filename, Specify this when your model is a combined model."
    )
    parser.add_argument(
        "--params_file",
        type=str,
        default="./infer_model_hf/params",
        help=
        "Parameter filename, Specify this when your model is a combined model."
    )
    parser.add_argument(
        "--model_dir",
        type=str,
        default="",
        help=
        "Model dir, If you load a non-combined model, specify the directory of the model."
    )
    parser.add_argument("--use_onnxruntime",
                        type=int,
                        default=0,
                        help="Whether use onnxruntime.")
    parser.add_argument("--thread",
                        type=int,
                        default=1,
                        help="Whether use onnxruntime.")
    return parser.parse_args()


if __name__ == '__main__':
    args = parse_args()
    batch = 1
    pred = init_predictor(args)
    np.random.seed(17)
    sparse_shape = (batch, 19)
    varlen_sparse_weight_shape = (batch, 1)
    # dense_shape = (batch, 24)
    data = {
        "pull_gpups_sparse_0.tmp_0": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_1": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_2": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_3": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_4": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_5": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_6": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_7": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_8": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_9": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_10": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_11": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_12": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_13": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_14": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_15": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_16": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_17": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_18": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_19": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_20": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_21": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_22": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_23": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_24": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_25": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_26": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_27": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_28": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_29": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_30": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_31": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_32": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_33": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_34": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_35": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_36": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_37": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_38": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_39": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_40": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_41": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_42": np.random.rand(*sparse_shape).astype("float32"),
        "pull_gpups_sparse_0.tmp_43": np.random.rand(*sparse_shape).astype("float32"),
        "11011": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
        "11012": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
        "11013": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
        "11014": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
        "11033": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
        "11034": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
        "11035": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
        "11036": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
        "11037": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
        "12003": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
        "12004": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
        "12006": np.random.rand(*varlen_sparse_weight_shape).astype("float32"),
    }
    result = run(pred, data)
    print("-------------------")
    print(result)
