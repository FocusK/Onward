echo "Run before_hook.sh begin..."

if [ ! -d bin ]; then
    echo "start to mkdir [./bin] dir"
    mkdir ./bin
fi

bin_path="/user/paddle/fengdanlei/heterps-models/"
hadoop_fs="afs://yinglong.afs.baidu.com:9902"
hadoop_ugi="paddle,aig@paddle@2021"
# [1. download bin]
hadoop fs -D hadoop.job.ugi=$hadoop_ugi -D fs.default.name=$hadoop_fs -get $bin_path"/bin/libjemalloc.so" ./bin/
hadoop fs -D hadoop.job.ugi=$hadoop_ugi -D fs.default.name=$hadoop_fs -get $bin_path"/bin/read_from_afs.nogz" ./bin/
hadoop fs -D hadoop.job.ugi=$hadoop_ugi -D fs.default.name=$hadoop_fs -get $bin_path"/bin/xbox_pb_converter" ./bin/
hadoop fs -D hadoop.job.ugi=$hadoop_ugi -D fs.default.name=$hadoop_fs -get $bin_path"/bin/xbox_pb_deconverter" ./bin/
chmod +x ./bin/*
echo "********* End download bin ***********"

# [2. download and install paddlewhl]
hadoop fs -D hadoop.job.ugi=$hadoop_ugi -D fs.default.name=$hadoop_fs -get $bin_path"/whl/mf/paddlepaddle_gpu-0.0.0-cp37-cp37m-linux_x86_64.whl" ./bin/
export PYTHONPATH=/opt/_internal/cpython-3.7.0/lib/python3.7/:${PATH}
python3.7 -m pip install ./bin/paddlepaddle_gpu-0.0.0-cp37-cp37m-linux_x86_64.whl --force-reinstall
python3.7 -m pip install protobuf==3.10.0 --force-reinstall
echo "********* End install paddle ***********"

# [3. download and install hmpclient]
hadoop fs -D hadoop.job.ugi=$hadoop_ugi -D fs.default.name=$hadoop_fs -get $bin_path"/tar/hmpclent.tar.gz" .
tar -zxvf hmpclent.tar.gz
if [ -f `pwd`/.hmpclient/bin/hadoop ]; then
    sed -i 's/.*limit\s\+/exec /g' `pwd`/.hmpclient/bin/hadoop
fi
if [ -f `pwd`/.hmpclient/hadoop-client/hadoop/bin/hadoop ]; then
    sed -i 's/.*limit\s\+/exec /g' `pwd`/.hmpclient/hadoop-client/hadoop/bin/hadoop
    sed -i '2i\unset LD_PRELOAD' `pwd`/.hmpclient/hadoop-client/hadoop/bin/hadoop
    echo 'unset LD_PRELOAD in `pwd`/.hmpclient/hadoop-client/hadoop/bin/hadoop'
fi
rm hmpclent.tar.gz

echo "********* End before_hook.sh***********"
