#!/bin/bash
if [ ! -d ../core ]; then
    echo "fail to find core dir[../core]"
    exit -1
fi

ln -s ../core ./

sh ./scripts/before_hook.sh

echo "End local build..." 
