rm -rf hdfs_err.log hs_err_pid* join_* update_* http.log update_* 1* 2*
rm -rf __pycache__/ 
rm -rf core.*
rm -rf paddle_dense*
rm -rf log*
rm -rf database_*
rm -rf dnn_plugin
rm -rf inference_model
rm -rf donefile.txt
rm -rf fleet_desc.prototxt 
rm -rf xbox_base_done.txt xbox_patch_done.txt
