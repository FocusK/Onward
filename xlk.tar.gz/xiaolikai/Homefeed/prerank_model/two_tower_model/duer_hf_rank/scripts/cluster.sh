#!/bin/bash

sh ./scripts/before_hook.sh &> ../log/build.log

# environment variables for fleet distribute training
export PYTHONPATH=/opt/_internal/cpython-3.7.0/lib/python3.7/:${PATH}
export HADOOP_HOME=`pwd`/.hmpclient/

unset http_proxy
unset https_proxy

export PADDLE_TRAINER_ID=0

export GLOG_v=1

export FLAGS_LAUNCH_BARRIER=0
export PADDLE_PSERVER_NUMS=1

iner_port=`expr $PADDLE_PORT + 1`
export PADDLE_PSERVERS_IP_PORT_LIST=$POD_IP":"$iner_port
export PADDLE_PSERVER_PORT_ARRAY=($iner_port)
export PADDLE_TRAINER_ENDPOINTS=`echo $PADDLE_TRAINER_ENDPOINTS | awk -F ',' '{print $1}'`
echo "PADDLE_TRAINER_ENDPOINTS: "$PADDLE_TRAINER_ENDPOINTS

export PADDLE_TRAINERS=1
export PADDLE_TRAINERS_NUM=${PADDLE_TRAINERS}

export FLAGS_use_stream_safe_cuda_allocator=false

echo "SERVER----"${PADDLE_PSERVERS_IP_PORT_LIST}

export TRAINING_ROLE=PSERVER
export FLAGS_selected_gpus="0"

export LD_PRELOAD=./bin/libjemalloc.so

training_script="core/trainer_online.py pserver"
if [ "$1" = "test" ];then
    training_script="core/infer.py pserver"
fi

for((i=0;i<$PADDLE_PSERVER_NUMS;i++))
do
    cur_port=${PADDLE_PSERVER_PORT_ARRAY[$i]}
    echo "PADDLE WILL START PSERVER "$cur_port
    export PADDLE_PORT=${cur_port}
    echo "training scripts:"$training_script
    python3.7 -u $training_script &> ../log/pserver.$i.user_log &
done

export TRAINING_ROLE=TRAINER
training_script="core/trainer_online.py trainer"
if [ "$1" = "test" ];then
    training_script="core/infer.py trainer"
fi
SC="core/trainer_online.py trainer"

for((i=0;i<$PADDLE_TRAINERS;i++))
do
    echo "PADDLE WILL START Trainer "$i
    PADDLE_TRAINER_ID=$i
    echo "training scripts:"$training_script
    python3.7 -u $training_script &> ../log/trainer.$i.user_log
done

echo "Training user_log stored in ../log/"
