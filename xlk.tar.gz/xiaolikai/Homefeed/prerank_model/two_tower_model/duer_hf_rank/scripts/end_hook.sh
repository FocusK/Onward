echo "Run end_hook.sh ..."
cp ./log/afs_agent.log ../log/afs_agent.log