export GLOG_v=1
export PYTHONPATH=/opt/_internal/cpython-3.7.0/lib/python3.7/:${PATH}
export PADDLE_TRAINER_ENDPOINTS="127.0.0.1:8601"
export FLAGS_selected_gpus="0,1,2,3,4,5,6,7"
export HADOOP_HOME=`pwd`/.hmpclient/

export LD_PRELOAD=./bin/libjemalloc.so


mode=$1
if [ "${mode}"x = "test"x ]; then
    sh scripts/run_local_exec.sh TEST PSERVER 8600 0 &
    sh scripts/run_local_exec.sh TEST TRAINER 8000 0 &
else
    sh scripts/run_local_exec.sh TRAIN PSERVER 8600 0 &
    sh scripts/run_local_exec.sh TRAIN TRAINER 8000 0 &
fi


