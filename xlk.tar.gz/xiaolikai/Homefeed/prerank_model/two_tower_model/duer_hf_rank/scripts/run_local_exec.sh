export PADDLE_TRAINER_ENDPOINTS="127.0.0.1:8000"
export PADDLE_PSERVERS_IP_PORT_LIST="127.0.0.1:8600"
export PADDLE_TRAINERS_NUM=1
export POD_IP=127.0.0.1
export PADDLE_PORT=$3
export PADDLE_TRAINER_ID=$4

training_script="core/trainer_online.py"
if [ "$1" = "TEST" ];then
    training_script="core/infer.py"
fi

echo "run "$1" mode, training scripts:"$training_script

if [ "$2" = "TRAINER" ];then
    echo "TRAINER !"
    export TRAINING_ROLE=TRAINER
    python3.7 -u $training_script

else
    echo "PSERVER !"
    export TRAINING_ROLE=PSERVER
    python3.7 -u $training_script
fi

exit 0
