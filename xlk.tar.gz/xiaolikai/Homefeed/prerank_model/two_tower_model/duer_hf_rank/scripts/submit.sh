#!/bin/bash
#set -x
source conf/config.ini

JOB_NAME=$JOB_NAME
PDC_QUEUE=$PDC_QUEUE
PRIORITY=$PRIORITY
WALL_TIME=$WALL_TIME
rm -rf logs

EXTFLAGS="--is-standalone 1"
if [[ $MPI_NODE_NUM -gt 1 ]]; then
    EXTFLAGS="--distribute-job-type NCCL2 --k8s-trainers ${MPI_NODE_NUM} --is-standalone 0"
fi
if [ ! -z "$3" ]; then
    EXTFLAGS="$EXTFLAGS --job-tags=$3"
fi


if [ ! -d ../core ]; then
    echo "fail to find [../core] dir"
    exit -1
fi
if [ -d core ]; then
    echo "remove [./core] dir"
    rm -rf core
fi

cp -rf ../core ./

mode=$1
if [ "${mode}" = "test" ]; then
    TRAIN_MODE="test"
else
    TRAIN_MODE="train"
fi

algo_id="algo-8ac58a6aec4940f4"

# please use "paddlecloud config" to set your ak/sk first
function submit_paddle_cloud_job() {
    k8s_gpu_cards=1
    image_addr="iregistry.baidu-int.com/paddlecloud/base-images:paddlecloud-centos7.8-gcc8.2-cuda11.0-cudnn8"
    paddlecloud job \
        train --job-name ${JOB_NAME}\
        --job-conf conf/config.ini \
        --group-name ${PDC_QUEUE} \
        --start-cmd "bash +x scripts/cluster.sh "$TRAIN_MODE \
        --file-dir "." \
        --job-version paddle-fluid-custom  \
        --image-addr ${image_addr} \
        --k8s-gpu-cards ${k8s_gpu_cards} \
        --k8s-priority ${PRIORITY} \
        --wall-time ${WALL_TIME} \
        --algo-id ${algo_id} \
        $EXTFLAGS

}

submit_paddle_cloud_job

exit 0
