#!bin/bash
source ~/.bashrc

workPath=`pwd`;
cd $workPath

####### 获取当前日期 #######
dst_day=$1
if [ ! -n "$1" ];then
    dst_day=$(date -d "last day" +%Y%m%d)
fi
train_days="days=\"{$dst_day..$dst_day}\""

log="/home/work/xiaolikai/baidu/duer/vertical-recommend-rank/vertical_recommend_rank/logs/train_$dst_day.log"
{
    ####### 删除过期模型 #######
    overdue_day=$(date -d "-20 days $dst_day" +%Y%m%d)
    overdue_model_path="afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/homefeed_rank_data/model_deepfm/$overdue_day"
    hk -rmr $overdue_model_path

    ####### 训练模型 #######
    rm sed*
    sed -i '/days=/d' ./config.py
    sed -i '$a\'$train_days ./config.py

    sh scripts/submit.sh train
} > ${log} 2>&1
