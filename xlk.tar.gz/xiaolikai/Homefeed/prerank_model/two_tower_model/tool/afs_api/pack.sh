set -x
ar_str=""
for i in "$@"; do
    fullname=$(basename $i)
    path=$(echo $fullname | cut -d . -f1)
    #echo $path
    ar_str="$ar_str $path/*.o"
    if [ -d $path ]; then
        echo "$path exist"
    fi
    mkdir $path
    cp $i ./
    cd $path
    ar -x ../$fullname
    cd ..
done

ar -qc libafsdep.a $ar_str
ranlib libafsdep.a

