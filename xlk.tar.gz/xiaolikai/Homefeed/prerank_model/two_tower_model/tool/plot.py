# -*- coding: utf-8 -*-
import sys
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from datetime import datetime

#fig1 = plt.figure(dpi=150)
fig1 = plt.figure(figsize=(16, 16))
ax1 = fig1.add_subplot(111, aspect='equal')
#ax1.add_patch(
#        patches.Rectangle(
#            (0.1, 0.1),   # (x,y)
#            100,          # width
#            100,          # height
#            )
#        )

load = []
prebuild = []
pull = []
hbm = []
join = []
update = []
dump = []
time_begin = 0
cost_begin = 0

def get_diff(line):
    aaa = ':'.join(line.strip().split()[2].split(":")[:-2])
    time_str = datetime.strptime(aaa, "%H:%M:%S")
    diff = (time_str - time_begin).seconds + cost_begin
    return diff, aaa

cnt = 0
flag = 1
skip = int(sys.argv[2])
skip_cnt = 0

for line in sys.stdin:
    if line.find("LoadIntoMemory cost:") != -1:
        if flag:
            aaa = ':'.join(line.strip().split()[2].split(":")[:-2])
            time_begin = datetime.strptime(aaa, "%H:%M:%S")
            cost_begin = float(line.strip().split("LoadIntoMemory cost: ")[-1][:-1])
            flag = 0
        diff, time_str = get_diff(line)
        cost = float(line.strip().split("LoadIntoMemory cost: ")[-1][:-1])
        load.append([diff, cost, time_str])
    elif line.find("thread PreBuildTask end") != -1:
        diff, time_str = get_diff(line)
        cost = float(line.strip().split()[-1][:-1])
        #cost = float(line.strip().split()[-2])
        prebuild.append([diff, cost, time_str])
    elif line.find("pull sparse") != -1:
        diff, time_str = get_diff(line)
        cost = float(line.strip().split()[-2])
        pull.append([diff, cost, time_str])
        #print(time_str, cost)
    elif line.find("build hbm cost") != -1:
        diff, time_str = get_diff(line)
        cost = float(line.strip().split()[-2])
        hbm.append([diff, cost, time_str])
    elif line.find("GpuPs worker 0 train cost") != -1:
        cnt += 1
        diff, time_str = get_diff(line)
        cost = float(line.strip().split()[-4])
        if cnt % 2 == 1:
            join.append([diff, cost, time_str])
        else:
            update.append([diff, cost, time_str])
    elif line.find("EndPass") != -1:
        diff, time_str = get_diff(line)
        cost = float(line.strip().split()[-1][:-1])
        dump.append([diff, cost, time_str])

x_lim = 500
y_lim = 200
Y = y_lim - 10 
fact0 = 5.0
fact1 = 5.0


offset = load[skip][0] - load[skip][1] - load[0][0] + load[0][1]
load = load[skip:]
prebuild = prebuild[skip:]
pull = pull[skip:]
hbm = hbm[skip:]
join = join[skip:]
update = update[skip:]
dump = dump[skip:]
print(offset)
for i in range(0, len(load)):
    rec2 = patches.Rectangle(( (load[i][0] - load[i][1] - offset) / fact0 , Y - i * fact1), load[i][1] / fact0, fact1, color='red')
    print(i, load[i][2], load[i][1], load[i][0])
    ax1.add_patch(rec2)
    if (i < len(prebuild)):
        rec2 = patches.Rectangle(( (prebuild[i][0] - prebuild[i][1] - offset) / fact0 , Y - i * fact1), prebuild[i][1] / fact0, fact1, color='blue')
        print(i, prebuild[i][2], prebuild[i][1], prebuild[i][0])
        ax1.add_patch(rec2)
    
    if (i < len(pull)):
        rec2 = patches.Rectangle(( (pull[i][0] - pull[i][1] - offset) / fact0 , Y - i * fact1), pull[i][1] / fact0, fact1, color='yellow')
        print(i, pull[i][2], pull[i][1], pull[i][0])
        ax1.add_patch(rec2)
        
    if (i < len(hbm)):
        rec2 = patches.Rectangle(( (hbm[i][0] - hbm[i][1] - offset) / fact0 , Y - i * fact1), hbm[i][1] / fact0, fact1, color='green')
        print(i, hbm[i][2], hbm[i][1], hbm[i][0])
        ax1.add_patch(rec2)

    if (i < len(join)):
        rec2 = patches.Rectangle(( (join[i][0] - join[i][1] - offset) / fact0 , Y - i * fact1), join[i][1] / fact0, fact1, color='#0099FF')
        print(i, join[i][2], join[i][1], join[i][0])
        ax1.add_patch(rec2)
        
    if (i < len(update)):
        rec2 = patches.Rectangle(( (update[i][0] - update[i][1] - offset) / fact0 , Y - i * fact1), update[i][1] / fact0, fact1, color='#EB70AA')
        print(i, update[i][2],  update[i][1], update[i][0])
        ax1.add_patch(rec2)
        
    if (i < len(dump)):
        rec2 = patches.Rectangle(( (dump[i][0] - dump[i][1] - offset) / fact0 , Y - i * fact1), dump[i][1] / fact0, fact1, color='pink')
        print(i, dump[i][2], dump[i][1], dump[i][0])
        ax1.add_patch(rec2)

ax1.set_xlim(0,x_lim)
ax1.set_ylim(0,y_lim)

fig1.savefig(sys.argv[1], dpi=90, bbox_inches='tight')
