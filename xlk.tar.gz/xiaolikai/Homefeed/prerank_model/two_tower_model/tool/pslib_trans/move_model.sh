#!/bin/bash

# trans_sparse MR output
ori_path="/user/feed_video/job_data/production/latent_recall/ucf_graph_offline/day_click_sign_uid/20100917/"
# new path
dest_path="/user/feed_video/user/wuxinxuan/microvideo/hottrain_1017/"
# trans date
trans_date="20211017"

# 1. mv ori_path to dest_path
hadoop fs -Dfs.default.name='afs://xingtian.afs.baidu.com:9902' -Dhadoop.job.ugi=feed_video,D3a0z8 -mkdir $dest_path/$trans_date/0/000/
hadoop fs -Dfs.default.name='afs://xingtian.afs.baidu.com:9902' -Dhadoop.job.ugi=feed_video,D3a0z8 -mv $ori_path/* $dest_path/$trans_date/0/000/
# 2. put donefile.txt to dest_path (***you should create donefile.txt fisrt***)
hadoop fs -Dfs.default.name='afs://xingtian.afs.baidu.com:9902' -Dhadoop.job.ugi=feed_video,D3a0z8 -put donefile.txt $dest_path

echo "finish"
hadoop fs -Dfs.default.name='afs://xingtian.afs.baidu.com:9902' -Dhadoop.job.ugi=feed_video,D3a0z8 -ls $dest_path
