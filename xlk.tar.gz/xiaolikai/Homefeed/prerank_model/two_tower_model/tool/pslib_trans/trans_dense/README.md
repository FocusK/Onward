PslibDense2Paddle
===
pslib(paddle_fleet) dense参数转paddle工具, 用于psgpu热启参数加载

快速开始
---
1. 合并pslib参数，保存为3张表： `python concat_pslib_dense.py`

- 修改`config.py`:
- - date: 日期
- - fs_name: pslib dense参数路径的hadoop name （源）
- - fs_ugi: pslib dense参数路径的hadoop ugi （源）
- - upload_fs_name: 输出路径的hadoop name （目标）
- - upload_fs_ugi: 输出路径的hadoop ugi （目标）
- - load_pslib_dense_path: pslib dense参数路径 （源）
- - output_dense_path: 保存的输出路径 （目标）

2. 热启时在`config.py`中设置`is_hot_from_pslib=True `，任务会调用`pslib_model_loader.PSlibDenseLoader()`类进行dense参数转换。

3. 注意： 使用pslib转换后的模型进行热启时，需要将pslib原来的fleet_desc.prototxt拷贝到训练目录下，已保证正确解析table顺序。


转换代码：
```
core/pslib_model_loader.py
```

pslib 与paddle dense参数区别与联系：
---
- 不同：存储格式不同。paddle为每个var一个文件，pslib与abacus基本一致，数据格式为：
```
# 除data norm层之外的dense参数
struct AdamSGDValue {
    float w; # weight
    float avg_w; #没有用到
    float ada_d2sum; # adam相关的参数
    float ada_g2sum; # adam相关的参数
    float mom_velocity; # adam相关的参数
}
  
  
# data norm层的参数
struct SummarySGDValue {
    float w; # weight
}
```
存储上pslib中dense参数保存为gz文件，180个trainer有180个part保存参数，每个part行数相同。最后一个文件少了的行填默认值补齐。
```
fc默认值：0 0 9993.46 0 0
data normn默认值：0
```
- 相同：内部顺序一致。均为行主序，slot切分。

转换思路
---
1. 小文件聚合：存储为3个表，join_dnn_table / join_summary_table/ update_table
2. 热启时像aibox一样加载pslib_model_loader类处理
3. 根据fleet_desc.prototxt文件确定table中var顺序
4. 每行读取，由于内部顺序和paddle一致，因此按shape 进行load到paddle的var中即可
