import os
import sys
from config import *

def concat_dense(dense_path, local_path):
    """
    concat all .gz file into one table
    """
    cmd = '%s -text %s/* > %s' % (hadoop_fs, dense_path, local_path)
    print 'cmd: %s' % cmd
    os.system(cmd)
    print("concat dense "+ local_path + " finished...")


def concat_upload_pslib_dense(load_pslib_dense_path, model_local_path, output_dense_path):
    """
    1. concat into three tables
    2. upload three tables
    """
    if not os.path.isdir(model_local_path):
        os.system('mkdir -p %s' % model_local_path)
    concat_dense(load_pslib_dense_path + "/001/", model_local_path + "/join_dnn_table")
    concat_dense(load_pslib_dense_path + "/002/", model_local_path + "/join_summary_table")
    concat_dense(load_pslib_dense_path + "/003/", model_local_path + "/update_table")

    cmd = '%s -rmr %s' % (upload_hadoop_fs, output_dense_path)
    print 'cmd: %s' % cmd
    os.system(cmd)
    cmd = '%s -put %s %s' % (upload_hadoop_fs, model_local_path, output_dense_path)
    print 'cmd: %s' % cmd
    os.system(cmd)


if __name__ == "__main__":
    concat_upload_pslib_dense(load_pslib_dense_path, model_local_path, output_dense_path)
    print("finish....")
