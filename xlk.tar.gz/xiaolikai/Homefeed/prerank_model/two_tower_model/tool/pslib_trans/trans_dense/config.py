#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author: fengdanlei@baidu.com (Danlei Feng)
@Copyright: Copyright (c) 2016 Baidu.com, Inc. All Rights Reserved
@Desc:
@ChangeLog:
"""

date = 20211017
hadoop_fs = "hadoop fs -Dfs.default.name='afs://xingtian.afs.baidu.com:9902' -Dhadoop.job.ugi=feed_video,D3a0z8"
upload_hadoop_fs = hadoop_fs
load_pslib_dense_path = 'afs:/user/feed_video/micro_video_model/dnn_recall/nearline_esmm_twice/%s/0/' % date
model_local_path = "./pslib_dense/"
output_dense_path = "afs:/user/feed_video/user/wuxinxuan/microvideo/hottrain_1017/%s/0/dnn_plugin/" % date
