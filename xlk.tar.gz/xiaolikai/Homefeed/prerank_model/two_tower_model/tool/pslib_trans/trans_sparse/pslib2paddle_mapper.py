"""
    @module pslib2paddle_mapper
    @function
    @class
    @method 
"""
import sys
import time
import datetime

shard_num = 37

trans_date = sys.argv[1]
date1 = time.strptime(trans_date, "%Y%m%d")
date = datetime.datetime(date1[0], date1[1], date1[2])
base_date = datetime.datetime(1970, 01, 01)
diff_day = (date - base_date).days - 1
for line in sys.stdin:
    line = line.strip().split()
    if len(line) < 8:
        print '\t'.join(line)
        continue

    key = int(line[0]) % shard_num
    unseen_day = diff_day - int(line[1])
    decay_rate = 0.95 ** int(line[1])
    show = float(line[3]) / decay_rate
    click = float(line[4]) / decay_rate

    print line[0] + ' ' + str(key) + '\t' + str(unseen_day) + ' ' + line[2] + ' ' + \
            str(show) + ' ' + str(click) + ' ' + ' '.join(line[5:])