#!/bin/bash
source ~/.bash_profile

###[MR任务]转sparse table：from pslib to paddle 
###pslib2paddle_mapper.py

DATE=20100910

trans_date=20211204

INPUT_PATH="afs://xingtian.afs.baidu.com:9902/user/feed_video/micro_video_model/dnn_recall/nearline_esmm_twice/${trans_date}/0/000/"
OUTPUT_PATH="afs://xingtian.afs.baidu.com:9902/user/feed_video/job_data/production/latent_recall/ucf_graph_offline/cjq_tmp_data/${DATE}/00"

JOB_NAME="feed_production_hour_latent_recall_test_data_${DATE}"
echo ${JOB_NAME}

hadoopxt  fs -rmr $OUTPUT_PATH

alias hadoop='/home/work/.hmpclient/bin/hadoop --config /home/work/hadoop-client-1.5.9/hadoop-client/hadoop/conf-xt/'

hadoop streaming \
-file "pslib2paddle_mapper.py" \
-input "${INPUT_PATH}" \
-output "${OUTPUT_PATH}" \
-mapper "python pslib2paddle_mapper.py ${trans_date}" \
-reducer "cat" \
-jobconf mapred.job.map.capacity=2000 \
-jobconf mapred.job.reduce.capacity=1000 \
-jobconf mapred.reduce.tasks=37 \
-jobconf mapred.compress.map.output=true \
-jobconf hadoop.job.ugi="feed_video,D3a0z8" \
-jobconf mapred.output.compress=true \
-jobconf mapred.map.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec \
-jobconf mapred.job.priority="HIGH" \
-jobconf mapred.job.name=${JOB_NAME} \
-jobconf mapred.job.queue.name=feed-video \
-jobconf num.key.fields.for.partition=1 \
-jobconf stream.num.map.output.key.fields=1 \
-partitioner com.baidu.sos.mapred.lib.MapIntPartitioner