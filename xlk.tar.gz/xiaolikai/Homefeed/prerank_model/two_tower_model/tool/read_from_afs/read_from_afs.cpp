#include <stdio.h>
#include <stdlib.h>
#include <ext/hash_map>
#include <fstream>
#include <unistd.h>
#include <string>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>
#include "baidu/inf/afs-api/client/afs_filesystem.h"
#include <zlib.h>

using namespace std;
using namespace __gnu_cxx;

void Zerr(int ret) {
    fputs("zpipe: ", stderr);
    switch (ret) {
    case Z_ERRNO:
        if (ferror(stdin))
            fputs("error reading stdin\n", stderr);
        if (ferror(stdout))
            fputs("error writing stdout\n", stderr);
        break;
    case Z_STREAM_ERROR:
        fputs("invalid compression level\n", stderr);
        break;
    case Z_DATA_ERROR:
        fputs("invalid or incomplete deflate data\n", stderr);
        break;
    case Z_MEM_ERROR:
        fputs("out of memory\n", stderr);
        break;
    case Z_VERSION_ERROR:
        fputs("zlib version mismatch!\n", stderr);
    }
}

int read_from_afs(const std::string &fs_name,
                  const std::string &fs_ugi,
                  const std::vector<string>& filenames) {
    const int MAX_BUF_SIZE = 1024 * 1024 * 4;
    const int CHUNK = MAX_BUF_SIZE;
    ///
    char *buf = (char *)calloc(CHUNK, sizeof(char));
    z_stream zstream;
    int zerr;
    zstream.zalloc = Z_NULL;
    zstream.zfree = Z_NULL;
    zstream.opaque = Z_NULL;
    zstream.next_in = NULL;
    zstream.avail_in = 0;
    zstream.data_type = Z_UNKNOWN;

    //zerr = inflateInit2(&zstream, -MAX_WBITS);
    zerr = inflateInit2(&zstream, 16+MAX_WBITS);
    if (zerr != Z_OK) {
        fprintf(stderr, "zlib init error, exit\n");
        _exit(-1);
    }
    ///
    afs::AfsFileSystem *_afshandler = nullptr;
    afs::Reader* _reader = nullptr;

    auto split = fs_ugi.find(",");
    string user = fs_ugi.substr(0, split);
    string pwd = fs_ugi.substr(split+1);

    _afshandler = new afs::AfsFileSystem(fs_name.c_str(), user.c_str(), pwd.c_str(), "./conf/client.conf");
    int ret = _afshandler->Init(true, true);
    if (ret != 0) {
        fprintf(stderr, "AFS Init Error\n");
        _exit(-1);
    }
    ret = _afshandler->Connect();
    if (ret != 0) {
        fprintf(stderr, "AFS Connect Error\n");
        _exit(-1);
    }
    char *f = (char *)calloc(MAX_BUF_SIZE, sizeof(char));
    if (f == NULL) {
        fprintf(stderr, "Memory Not Enough, exit\n");
        _exit(-1);
    }
    for (int i = 0; i < (int)filenames.size(); ++i){
        int size = 0;
        _reader = _afshandler->OpenReader(filenames[i].c_str());
        if (_reader == NULL) {
            fprintf(stderr, "Create Reader Fail\n");
            _exit(-1);
        }
        while ((size = _reader->Read(f, MAX_BUF_SIZE)) > 0) {
            zstream.next_in = f;
            zstream.avail_in = size;
            do {
                zstream.next_out = (Bytef*) buf;
                zstream.avail_out = CHUNK;
                zerr = inflate(&zstream, Z_NO_FLUSH);
                if (zerr != Z_OK && zerr != Z_STREAM_END) {
                    Zerr(zerr);
                    _exit(-1);
                }
                int have = CHUNK - zstream.avail_out;
                if ((long) fwrite(buf, sizeof(char), have, stdout) < have) {
                    fprintf(stderr, "Write to stdout Failed\n");
                    _exit(-1);
                }
            } while (zstream.avail_out == 0);
        }
        if (_reader != NULL) {
            _afshandler->CloseReader(_reader);
            _reader = NULL;
        }
    }
    if (f != NULL) {
        free(f);
        f = NULL;
    }
    if (_afshandler != NULL) {
        _afshandler->DisConnect();
        _afshandler->Destroy();
        delete _afshandler;
        _afshandler = nullptr;
    }
    inflateEnd(&zstream);
    free(buf);
    buf = NULL;
    return 0;
}

int main(int argc, char *argv[]) {
  // argv: fs_name, fs_ugi, filelist 
  if (argc < 4) {
    fprintf(stderr, "Wrong Parameter Number in read_from_afs\n");
    _exit(-1);
  }
  std::string fs_name = std::string(argv[1]);
  std::string fs_ugi = std::string(argv[2]);
  std::vector<std::string> filenames;
  for (int i = 3; i < argc; ++i) { 
      string filename(argv[i]); 
      if (strncmp(filename.c_str(), "afs:", 4) == 0) {
        filename = filename.substr(4);
      }
      filenames.push_back(filename);
  }
  read_from_afs(fs_name, fs_ugi, filenames);
  std::fflush(stdout);
  _exit(0);
}
