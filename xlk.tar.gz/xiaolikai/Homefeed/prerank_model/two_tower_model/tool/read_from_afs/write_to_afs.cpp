#include <stdio.h>
#include <stdlib.h>
#include <ext/hash_map>
#include <fstream>
#include <unistd.h>
#include <string>
#include <cstring>
#include <iostream>
#include <unordered_map>
#include <vector>
#include "baidu/inf/afs-api/client/afs_filesystem.h"
using namespace std;
using namespace __gnu_cxx;

int write_to_afs(const std::string &fs_name, const std::string &fs_ugi, const std::string& filename){
    const int MAX_BUF_SIZE = 1024 * 1024 * 4;
    size_t buf_len = MAX_BUF_SIZE;
    afs::AfsFileSystem *_afshandler = nullptr;

    auto split = fs_ugi.find(",");
    string user = fs_ugi.substr(0, split);
    string pwd = fs_ugi.substr(split+1);

    _afshandler = new afs::AfsFileSystem(fs_name.c_str(), user.c_str(), pwd.c_str(), "./conf/client.conf");
    int ret = _afshandler->Init(true, true);
    if (ret != 0) {
        fprintf(stderr, "AFS Init Error\n");
        _exit(-1);
    }
    ret = _afshandler->Connect();
    if (ret != 0) {
        fprintf(stderr, "AFS Connect Error\n");
        _exit(-1);
    }
    char *line_buf = (char *)calloc(buf_len + 1, sizeof(char));
    if (line_buf == NULL) {
        fprintf(stderr, "Memory Not Enough, exit\n");
        _exit(-1);
    }
    afs::WriterOptions w_options;
    w_options.write_mode = afs::kPipeLine;
    w_options.num_safe_replica = 2;
    w_options.buffer_size = 1 * 1024 * 1024;
    afs::Writer* writer = _afshandler->OpenWriter(filename.c_str(), w_options);
    if (writer == NULL) {
        fprintf(stderr, "fail to open writer for file %s, errno:%d, errmsg:%s", filename.c_str(), afs::GetRc(), afs::Rc2Str(afs::GetRc()));
        _exit(-1);
    }
    int read_count = 0;
    FILE* fp_in = stdin;
    while ((read_count = getline(&line_buf, &buf_len, fp_in)) > 0) {
        int res_len = writer->Append(line_buf, read_count); 
        if (res_len < 0) {
            fprintf(stderr, "fail to append, expect_len:%d, errno:%d, errmsg:%s", read_count, res_len, afs::Rc2Str(res_len));
            _exit(-1);
        } else if (res_len != read_count) {
            fprintf(stderr, "fail to append, expect_len:%d, res_len:%d\n", read_count, res_len);
            _exit(-1);
        }
    }
    if (line_buf != NULL) {
        free(line_buf);
        line_buf = NULL;
    }
    if (_afshandler != NULL) {
        _afshandler->CloseWriter(writer);
        _afshandler->DisConnect();
        _afshandler->Destroy();
        delete _afshandler;
        _afshandler = nullptr;
    }
    return 0;
}

int main(int argc, char *argv[]) {
  // argv: fs_name, fs_ugi, filelist 
  if (argc < 4) {
    fprintf(stderr, "Wrong Parameter Number in read_from_afs\n");
    _exit(-1);
  }
  std::string fs_name = std::string(argv[1]);
  std::string fs_ugi = std::string(argv[2]);
  int use_gz = 0;
  string filename(argv[4]); 
  if (strncmp(filename.c_str(), "afs:", 4) == 0) {
    filename = filename.substr(4);
  }
  
  write_to_afs(fs_name, fs_ugi, filename);
  std::fflush(stdout);
  _exit(0);
}
