#!/bin/bash
JOBID=job-0bb62ecb31492086
res=`paddlecloud job state $JOBID|grep clusterJobStatus|awk -F ': "' '{print $2}' |awk -F '"' '{print $1}'`

echo $res
# while true; do
#     res=`paddlecloud job state $JOBID|grep clusterJobStatus|awk -F ': "' '{print $2}' |awk -F '"' '{print $1}'`
#     if [ "$res" = "Failed" ];then
#     #if [ "$res" = "Running" ];then
#         echo `date`"]: job failed; rerun"
# 	out=`paddlecloud job rerun $JOBID`
#         #JOBID=`cat $out|awk -F 'newJobId = ' '{print $2}' | awk -F ',' '{print $1}'`
#         JOBID=`tail nohup.out |grep 'newJobId'|awk -F 'newJobId = ' '{print $2}' | awk -F ',' '{print $1}'`
# 	echo "change job id: "$JOBID
#     elif [ "$res" = "Succeed" ];then
# 	echo `date`"]: job Succeed; rerun"
# 	#paddlecloud job rerun $JOBID
# 	out=`paddlecloud job rerun $JOBID`
#         JOBID=`tail nohup.out |grep 'newJobId'|awk -F 'newJobId = ' '{print $2}' | awk -F ',' '{print $1}'`
# 	echo "change job id: "$JOBID
#     else
#         echo `date`"]: wait for job failed or success:"$res
# 	sleep 300s
#     fi
# done
