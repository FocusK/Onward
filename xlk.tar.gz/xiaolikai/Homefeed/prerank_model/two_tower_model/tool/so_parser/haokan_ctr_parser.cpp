#include "custom_parser.h"
#include "feature_sign.pb.h"
#include <vector>
#include <sys/time.h>
#include <string>
#include <assert.h>
#include <unordered_map>
#include <iostream>
#include <cmath>
#include <iostream>

namespace paddle {
namespace framework {

class TiebaPleParser : public CustomParser {
public:
    TiebaPleParser() {}
    virtual ~TiebaPleParser() {
      std::cout << "delete tieba parser" << std::endl;
    }
    bool Init(const std::vector<AllSlotInfo>& slots) {
        return true;
    }
    void Init(const std::vector<SlotConf> &conf) {
        slot_info = conf;
        for (size_t i = 0; i < slot_info.size(); ++i) {
          if (slot_info[i].name == "show") {
            show_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "click") {
            click_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "readlist") {
            readlist_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "ins_tag") {
            ins_tag_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].use_slots_index == -1) {
            continue;
          }
          int slot = atoi(slot_info[i].name.c_str());
          slot_map[slot] = slot_info[i].use_slots_index;
        }
    }
    
    void ParseOneInstance(const char* str, Record* instance) {
        assert(0);
    }
    
    int ParseInstance(int read_len, const char* str, std::vector<Record>* instances) {
        //struct timeval _start;
        //struct timeval _now;
        //int64_t _elapsed;
        //gettimeofday(&_start, NULL);
        char* cursor = const_cast<char*>(str);
        char* pos = (char*)memchr(cursor, '\n', read_len);
        while (pos != NULL) {
            int ins_len = static_cast<int>(pos - cursor + 1);
            
            ParseOnePb(cursor, ins_len - 1, instances);
            cursor += ins_len;
            read_len -= ins_len;
            pos = (char*)memchr(cursor, '\n', read_len);
        }
        //gettimeofday(&_now, NULL);
        //_elapsed = (_now.tv_sec - _start.tv_sec) * 1000 * 1000L +
        //       (_now.tv_usec - _start.tv_usec);
        //std::cout << "ParseInstance cost: " << _elapsed / 1000.0 << std::endl;
        return read_len;
    }
private:
    bool ParseOnePb(char *linebuf, const int len, std::vector<Record>* instances) {
        if (len <= 0) {
            fprintf(stderr, "data len error, len: %d\n", len);
            return false;
        }
        uint64_t feasign = 0;
        int slot = 0;
        thread_local std::vector<std::string> vec;
        thread_local std::vector<std::string> dense_vec;
        thread_local std::vector<std::string> dense_vec_fea;
        thread_local std::vector<std::string> t_l;
        thread_local std::vector<std::string> label_item;
        thread_local std::vector<std::vector<uint64_t>> uint64_feasigns;
        uint64_feasigns.resize(slot_info.size());
        for (auto &t : uint64_feasigns) {
            t.clear();
        }

        std::string line = std::string(linebuf, len);
        thread_local std::vector<std::vector<float>> float_feasigns;
        float_feasigns.resize(slot_info.size());
        for (auto &t : float_feasigns) {
            t.clear();
        }
        vec.clear();
        dense_vec.clear();
        dense_vec_fea.clear();
        t_l.clear();
        label_item.clear();
/////////
        split_string(line, '\t', vec, 3);
        if (vec.size() != 4) {
            return true;
        }
        std::string ins = trim_space(vec[0]);
        std::string vec_str = trim_space(vec[1]);
        std::string label_str = trim_space(vec[2]);
        std::string tags = trim_space(vec[3]);

        // std::string label_str = trim_space(vec[1]);
        // if (ins.size() == 0 || label_str.size() == 0) {
        //     continue;
        // }
        int flag = 0;
        for (auto& label : labels) {
            if (label_str.find(label) != label_str.npos) {
                flag = 1;
                break;
            }
        }
        if (!flag) return true;
        if (tags.find("VIDEO_14") == tags.npos) return true;
        
        
        split_string(vec_str, ' ', vec);
        for (auto& dense : vec) {
            split_string(dense, ':', dense_vec, 1);
            std::string dense_slot = trim_space(dense_vec[0]);
            if (dense_slot == "10000") {
                split_string(trim_space(dense_vec[1]), ':', dense_vec_fea);
            }
        }
        if (dense_vec_fea.size() != 9) {
            dense_vec_fea.clear();
            dense_vec_fea.resize(9);
            for (int i = 0; i < 9; i++) {
                dense_vec_fea[i] = "0";
            }
        }

        int show = 0;
        int clk = 0;
        int pl = 0;
        int app_version = 0;
        int ua = -1;
        int imms_auto_play = 0;

        // click_count,show_count, duration_total,app_version,ua,imms_auto_play
        split_string(label_str, ' ', t_l);
        for (auto& label : t_l) {
            split_string(label, ':', label_item);
            std::string trim_label = trim_space(label_item[1]);
            if (label.find("duration_total:") != label.npos)
                pl = std::stoi(trim_label);
            else if (label.find("app_version:") != label.npos)
                app_version = std::stoi(trim_label);
            else if (label.find("ua:") != label.npos)
                ua = std::stoi(trim_label);
            else if (label.find("imms_auto_play:") != label.npos)
                imms_auto_play = std::stoi(trim_label);
            else if (label.find("show_count:") != label.npos) {
                show = std::stoi(trim_label);
                if (show > 1) show = 1;
            }
            else if (label.find("click_count:") != label.npos) {
                clk = std::stoi(trim_label);
                if (clk > 1) clk = 1;
            }
        }

        
//        std::cout << pl << std::endl;
//        std::cout << app_version << std::endl;
//        std::cout << ua << std::endl;
//        std::cout << imms_auto_play << std::endl;
//        std::cout << show << std::endl;
//        std::cout << click << std::endl;
        
        int pos = clk;
        int neg = show - clk;
        bool is_autoplay = false;
        if (ua == 16) {
            is_autoplay = false;
        }
        else if (ua == 6 || ua == 15) {
            if (imms_auto_play == 1) {
                is_autoplay = true;
            }
        }
        if (is_autoplay) {
            if (pl <= 5 and clk > 0) {
                pos = 0;
                neg = 3;
            }
            else if (pl <= 20 and clk > 0) {
                pos = 0;
                neg = 1;
            }
            else if (clk == 0) {
                pos = 0;
                neg = 0;
            }
        }
 
        int mode = 0;
        if (tags.find("MASTER") == tags.npos) {
            ua = 0;
            mode = 1;
        }
        if (mode == 1) {
            dense_vec_fea.clear();
            dense_vec_fea.resize(9);
            for (int i = 0; i < 9; i++) {
                dense_vec_fea[i] = "0";
            }
        }
        
        size_t pos_s = line.find(' ');
        if (pos_s == std::string::npos) {
            fprintf(stderr, "error line: [%s]\n", line.c_str());
            return false;
        }

        char* head_ptr = NULL;
        std::string ins_id = line.substr(0, pos_s);
        head_ptr = const_cast<char*>(line.c_str());
        head_ptr += pos_s;
        int show_ = strtoul(head_ptr, &head_ptr, 10);
        int click_ = strtoul(head_ptr, &head_ptr, 10);

        int feasign_num = 0;
        // int other_slot = 0;

        for (size_t j = 0; j < dense_vec_fea.size(); j++) {
            float_feasigns[readlist_pos].push_back(std::stof(dense_vec_fea[j]));
        }
        uint64_feasigns[ins_tag_pos].push_back(ua); 
        while (*head_ptr != '\t') {
          feasign = strtoul(head_ptr, &head_ptr, 10);
          if (*head_ptr != '\t' && *head_ptr == ':') {
            head_ptr++;
            slot = strtoul(head_ptr, &head_ptr, 10);
            feasign_num++;
            if (slot_map.find(slot) == slot_map.end()) {
            //   other_slot++;
              continue;
            }
            if (mode == 1) continue;
            uint64_feasigns[slot_map[slot]].push_back(feasign);
          } else {
            break;
          }
        }
        // std::cout << "useless slot:" << other_slot << std::endl;

        
        for (int i = 0; i < neg; i++) {
            Record instance;
            std::string line_id = ins_id;
            line_id.append("-neg-");
            line_id.append(std::to_string(i));
            instance.ins_id_ = line_id;
            int show = 1;
            int click = 0;
            
            if (tags.find("MASTER") == tags.npos) {
                show = 0;
                click = 0;
            }
            uint64_feasigns[show_pos].clear();
            uint64_feasigns[click_pos].clear();
            uint64_feasigns[show_pos].push_back(show);
            uint64_feasigns[click_pos].push_back(click);
            add_instance(&instance, float_feasigns, uint64_feasigns);
            instances->push_back(instance);
        }

        for (int j = 0; j < pos; j++) {
            Record instance;
            std::string line_id = ins_id;
            line_id.append("-pos-");
            line_id.append(std::to_string(j));
            instance.ins_id_ = line_id;
            int show = 1;
            int click = 1;
            
            if (tags.find("MASTER") == tags.npos) {
                show = 0;
                click = 0;
            }
            uint64_feasigns[show_pos].clear();
            uint64_feasigns[click_pos].clear();
            uint64_feasigns[show_pos].push_back(show);
            uint64_feasigns[click_pos].push_back(click);
            add_instance(&instance, float_feasigns, uint64_feasigns);
            instances->push_back(instance);
        }
/////////
        return true;
    }

    void add_instance(Record* instance, std::vector<std::vector<float>>& float_feasign, std::vector<std::vector<uint64_t>> uint64_feasign) {
        for (size_t i = 0; i < slot_info.size(); ++i) {
          int idx = slot_info[i].use_slots_index;
          if (idx != -1) {
            if (slot_info[i].type[0] == 'f') {  // float
              for (size_t j = 0; j < float_feasign[i].size(); ++j) {
                float feasign = float_feasign[i][j];
                // if float feasign is equal to zero, ignore it
                // except when slot is dense
                if (fabs(feasign) < 1e-6 && !slot_info[i].use_slots_is_dense) {
                  continue;
                }
                FeatureFeasign f;
                f.float_feasign_ = feasign;
                instance->float_feasigns_.push_back(FeatureItem(f, idx));
              }
            } else if (slot_info[i].type[0] == 'u') {  // uint64
              for (size_t j = 0; j < uint64_feasign[i].size(); ++j) {
                uint64_t feasign = uint64_feasign[i][j];
                // if uint64 feasign is equal to zero, ignore it
                // except when slot is dense
                if (feasign == 0 && !slot_info[i].use_slots_is_dense) {
                  continue;
                }
                FeatureFeasign f;
                f.uint64_feasign_ = feasign;
                instance->uint64_feasigns_.push_back(FeatureItem(f, idx));
              }
            }
          }
        }
    }
    
    std::vector<std::string> labels = {"ua:6", "ua:15", "ua:16"};
    std::unordered_map<int, int> slot_map;
    std::vector<SlotConf> slot_info;
    int show_pos;
    int click_pos;
    int readlist_pos;
    int ins_tag_pos;
};

}
}

extern "C" {
paddle::framework::CustomParser *CreateParserObject() {
    return new paddle::framework::TiebaPleParser();
}
}
