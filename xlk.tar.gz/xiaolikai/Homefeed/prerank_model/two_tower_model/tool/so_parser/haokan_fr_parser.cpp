#include "custom_parser.h"
#include "feature_sign.pb.h"
#include <vector>
#include <string>
#include <assert.h>
#include <unordered_map>
#include <iostream>
#include <cmath>
#include <iostream>
#include <sstream>
#include <fstream>
namespace paddle {
namespace framework {

class HaokanFRParser : public CustomParser {
public:
    HaokanFRParser() {}
    virtual ~HaokanFRParser() {
      std::cout << "delete tieba parser" << std::endl;
    }
    bool Init(const std::vector<AllSlotInfo>& slots) {
        return true;
    }
    void Init(const std::vector<SlotConf> &conf) {
        slot_info = conf;
        for (size_t i = 0; i < slot_info.size(); ++i) {
          if (slot_info[i].name == "show") {
            show_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "click") {
            click_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "realfr") {
            realfr_pos = slot_info[i].use_slots_index;
            std::cout << "realfr_pos " << realfr_pos << std::endl;
          }
          if (slot_info[i].name == "readlist") {
            readlist_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "ins_tag") {
            ins_tag_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "lowthred_label") {
            lowthred_label_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "highthred_label") {
            highthred_label_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "vi_tag") {
            vi_tag_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "inactive_tag") {
            inactive_tag_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "active_tag") {
            active_tag_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].name == "va_tag") {
            va_tag_pos = slot_info[i].use_slots_index;
          }
          if (slot_info[i].use_slots_index == -1) {
            continue;
          }
          int slot = atoi(slot_info[i].name.c_str());
          slot_map[slot] = slot_info[i].use_slots_index;
        }
    }
    
    void ParseOneInstance(const char* str, Record* instance) {
        assert(0);
    }
    
    int ParseInstance(int read_len, const char* str, std::vector<Record>* instances) {
        //std::cout << "wxx parse instance" << std::endl;
        char* cursor = const_cast<char*>(str);
        int body_len = 0;
        while (read_len) {
            if (read_len >= sizeof(int)) {
                body_len = get_bodylen(cursor);
                if (read_len >= (body_len + sizeof(int))) {
                    cursor += sizeof(int);
                    read_len -= sizeof(int);
                    ParseOnePb(cursor, body_len, instances);
                    cursor += body_len;
                    read_len -= body_len;
                } else {
                    break;
                }

            } else {
                break;
            }
            
        }
        return read_len;
    }
private:
    bool ParseOnePb(const char *line, const int len, std::vector<Record>* instances) {
        if (len <= 0) {
            fprintf(stderr, "data len error, len: %d\n", len);
            return false;
        }
 
        thread_local baidu::feed::mlarch::FeatureSign feasign;
        feasign.Clear();
 
        if (!feasign.ParseFromArray(line, len)) {
            fprintf(stderr, "paser pb error, len: %d\n", len);
            return false;
        }
 
        if (feasign.instance_size() <= 0) {
            fprintf(stderr, "feasign.instance is empty\n");
            return false;
        }
 
        // user
        thread_local std::vector<std::pair<int, uint64_t>> user_feasigns;
        user_feasigns.clear();
        const ::baidu::feed::mlarch::Instance &user_ins = feasign.user_instance();
        for (int i = 0; i < user_ins.slot_id_size(); ++i) {
            uint16_t slot = user_ins.slot_id(i);
            auto &id = slot_map[slot];
            if (id == -1) {
                continue;
            }
            uint64_t sign = user_ins.sign(i);
            user_feasigns.push_back({id, sign});
        }
        for (int i = 0; i < feasign.instance_size(); i++) {
            parser_one_ins(feasign.instance(i), user_ins, user_feasigns, instances);
        }
        return true;
    }
    
    bool parser_one_ins(const ::baidu::feed::mlarch::Instance &ins,
            const ::baidu::feed::mlarch::Instance& user_ins,
            std::vector<std::pair<int, uint64_t>> &user_feasigns,
            std::vector<Record>* instances) {
        std::string label_str = ins.label();
        std::string tags = ins.tag();
        int flag = 0;
        for (auto& label : labels) {
            if (label_str.find(label) != label_str.npos) {
                flag = 1;
                break;
            }
        }
        if (!flag) return true;
        
        thread_local std::vector<float> dense_vec_fea;
        thread_local std::vector<std::string> t_l;
        thread_local std::vector<std::string> label_item;
        dense_vec_fea.clear();
        t_l.clear();
        label_item.clear();
        
        for (auto& ebd : ins.ebd_slot()) {
            if (ebd.slot_id() == 10000) {
                for (auto value : ebd.value()) {
                    dense_vec_fea.push_back(value);
                }
            }
        }
        for (auto& ebd : user_ins.ebd_slot()) {
            if (ebd.slot_id() == 10000) {
                for (auto value : ebd.value()) {
                    dense_vec_fea.push_back(value);
                }
            }
        }
        int read_cnt = dense_vec_fea[1];
        if (dense_vec_fea.size() != 9) {
            dense_vec_fea.clear();
            dense_vec_fea.resize(9);
            for (int i = 0; i < 9; i++) {
                dense_vec_fea[i] = 0;
            }
        }
        int show = 0;
        int clk = 0;
        int ua = -1;
        int du = 0;
        int pl = 0;
        int u_7d_pl = 0;
        int u_7d_freq = 0;

        split_string(label_str, ' ', t_l);
        for (auto& label : t_l) {
            split_string(label, ':', label_item);
            std::string trim_label = trim_space(label_item[1]);
            if (label.find("sv_duration:") != label.npos)
                du = std::stoi(trim_label);
            else if (label.find("duration_v2:") != label.npos)
                pl = std::stoi(trim_label);
            else if (label.find("ua:") != label.npos)
                ua = std::stoi(trim_label);
            else if (label.find("7d_pl:") != label.npos)
                u_7d_pl = std::stoi(trim_label);
            else if (label.find("7d_freq:") != label.npos)
                u_7d_freq = std::stoi(trim_label);
            else if (label.find("show_count:") != label.npos) {
                show = std::stoi(trim_label);
                if (show > 1) show = 1;
            }
            else if (label.find("click_count:") != label.npos) {
                clk = std::stoi(trim_label);
                if (clk > 1) clk = 1;
            }
        }
        if (pl > 0) clk = 1;
        if (clk > show) show = clk;
        if (du == 0) return true;
        if (ua == 6 || ua == 15 || ua == 16) {
            if (clk == 0) return true;
        }
        if (pl > du) pl = du;
        double fr = (double) pl / (double) du;
        if (fr >= 1.0) 
            fr = 0.99999;
        else if (fr <= 0.0) 
            fr = 0.00001;
        
        int pos = clk;
        int neg = show - clk;
        int lowthred = 0;
        int highthred = 0;
        int inactive_tag = 0;
        int active_tag = 0;
        int va_tag = 0;
        int vi_tag = 0;

        if (ua == 107) {
            if (clk >= 1) lowthred = 1;
        }
        else if (ua == 6 || ua == 15 || ua == 16) {
            if (pl >= 5) lowthred = 1;
        }

        if (fr >= 0.95) highthred = 1;

        if (read_cnt <= 20 && clk >= 1) 
            vi_tag = 2;
        else if (read_cnt <= 200 && clk >=1)
            inactive_tag = 3;
        else if (read_cnt <= 999 and clk >=1)
            active_tag = 4;
        else if (read_cnt <= 1000 and clk >=1)
            va_tag = 5;
        
        int mode = 0;
        if (tags.find("MASTER") == tags.npos) {
            show = 0;
            clk = 0;
            fr = 0.0;
            ua = 0;
            mode = 1;
        }

        if (mode == 1) {
            dense_vec_fea.clear();
            dense_vec_fea.resize(9);
            for (int i = 0; i < 9; i++) {
                dense_vec_fea[i] = 0;
            }
        }


        // clear temp vector
        thread_local std::vector<std::vector<uint64_t>> uint64_feasigns;
        uint64_feasigns.resize(slot_info.size());
        for (auto &t : uint64_feasigns) {
            t.clear();
        }
 
        thread_local std::vector<std::vector<float>> float_feasigns;
        float_feasigns.resize(slot_info.size());
        for (auto &t : float_feasigns) {
            t.clear();
        }
 
        //int click = ins.click() ? 1 : 0;
        //uint64_feasigns[click_pos].push_back(click);
        //解析doc侧sparse特征
        // 40257 newid
        for (int j = 0; j < ins.slot_id_size(); ++j) {
            //不在slot列表中过滤掉
            uint16_t slot = ins.slot_id(j);
            auto &id = slot_map[slot];
            if (id == -1) {
                continue;
            }
            uint64_t sign = ins.sign(j);
            uint64_feasigns[id].push_back(sign);
        }
        //将user侧sparse特征合并到doc侧
        std::vector<std::pair<int, uint64_t>>::iterator it;
        for (it = user_feasigns.begin(); it != user_feasigns.end(); ++it) {
            uint64_feasigns[it->first].clear();
        }
        for (it = user_feasigns.begin(); it != user_feasigns.end(); ++it) {
            uint64_feasigns[it->first].push_back(it->second);
        }
        for (int j = 0; j < dense_vec_fea.size(); j++) {
            float_feasigns[readlist_pos].push_back(dense_vec_fea[j]);
        }
        
        
        uint64_feasigns[lowthred_label_pos].push_back(lowthred);
        uint64_feasigns[highthred_label_pos].push_back(highthred);
        uint64_feasigns[vi_tag_pos].push_back(vi_tag);
        uint64_feasigns[inactive_tag_pos].push_back(inactive_tag);
        uint64_feasigns[active_tag_pos].push_back(active_tag);
        uint64_feasigns[va_tag_pos].push_back(va_tag);
        uint64_feasigns[click_pos].push_back(clk);
        uint64_feasigns[ins_tag_pos].push_back(ua);
        float_feasigns[realfr_pos].push_back(fr);
        std::string ins_id = ins.logkey();
        
        for (int j = 0; j < neg; j++) {
            std::string line_id = ins_id;
            line_id.append("-neg-");
            line_id.append(std::to_string(j));
            Record instance;
            instance.ins_id_ = line_id;
            int show = 1;
            int click = 0;
            if (tags.find("MASTER") == tags.npos) {
                show = 0;
                click = 0;
            }
            uint64_feasigns[show_pos].clear();
            uint64_feasigns[click_pos].clear();
            uint64_feasigns[show_pos].push_back(show);
            uint64_feasigns[click_pos].push_back(click);
            add_instance(&instance, float_feasigns, uint64_feasigns);
            instances->push_back(instance);
        }

        for (int j = 0; j < pos; j++) {
            std::string line_id = ins_id;
            line_id.append("-pos-");
            line_id.append(std::to_string(j));
            Record instance;
            instance.ins_id_ = line_id;
            int show = 1;
            int click = 1;
            
            if (tags.find("MASTER") == tags.npos) {
                show = 0;
                click = 0;
            }
            uint64_feasigns[show_pos].clear();
            uint64_feasigns[click_pos].clear();
            uint64_feasigns[show_pos].push_back(show);
            uint64_feasigns[click_pos].push_back(click);
            add_instance(&instance, float_feasigns, uint64_feasigns);
            instances->push_back(instance);
        }
        return true;
    }

    void add_instance(Record* instance, std::vector<std::vector<float>>& float_feasign, std::vector<std::vector<uint64_t>> uint64_feasign) {
        for (size_t i = 0; i < slot_info.size(); ++i) {
          int idx = slot_info[i].use_slots_index;
          if (idx != -1) {
            if (slot_info[i].type[0] == 'f') {  // float
              for (size_t j = 0; j < float_feasign[i].size(); ++j) {
                float feasign = float_feasign[i][j];
                // if float feasign is equal to zero, ignore it
                // except when slot is dense
                if (fabs(feasign) < 1e-6 && !slot_info[i].use_slots_is_dense) {
                  continue;
                }
                FeatureFeasign f;
                f.float_feasign_ = feasign;
                instance->float_feasigns_.push_back(FeatureItem(f, idx));
              }
            } else if (slot_info[i].type[0] == 'u') {  // uint64
              for (size_t j = 0; j < uint64_feasign[i].size(); ++j) {
                uint64_t feasign = uint64_feasign[i][j];
                // if uint64 feasign is equal to zero, ignore it
                // except when slot is dense
                if (feasign == 0 && !slot_info[i].use_slots_is_dense) {
                  continue;
                }
                FeatureFeasign f;
                f.uint64_feasign_ = feasign;
                instance->uint64_feasigns_.push_back(FeatureItem(f, idx));
              }
            }
          }
        }
    }
    
    int get_bodylen(char *buf) {
        int value = 0;
        for (int i = 3; i >= 0; --i) {
            *(((char*) &value) + i) = buf[3 - i];
        }
        return value;
    }
    
    std::vector<std::string> labels = {"ua:6", "ua:15", "ua:16", "ua:107"};
    std::unordered_map<int, int> slot_map;
    std::vector<SlotConf> slot_info;
    int show_pos;
    int click_pos;
    int realfr_pos;
    int readlist_pos;
    int ins_tag_pos;
    int lowthred_label_pos;
    int highthred_label_pos;
    int vi_tag_pos;
    int inactive_tag_pos;
    int active_tag_pos;
    int va_tag_pos;
};

}
}

extern "C" {
paddle::framework::CustomParser *CreateParserObject() {
    return new paddle::framework::HaokanFRParser();
}
}
