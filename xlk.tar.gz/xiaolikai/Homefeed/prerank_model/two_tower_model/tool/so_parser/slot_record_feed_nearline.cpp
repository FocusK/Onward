#include "custom_parser.h"
#include "feature_sign.pb.h"
#include <vector>
#include <string>
#include <assert.h>
#include <unordered_map>
#include <iostream>
#include <cmath>
#include <iostream>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <unordered_set>
#include <ctime>

namespace paddle {
namespace framework {

struct Sample {
  int idx;
//   int show;
//   int click;
  std::string content_type;
  int mt_q;
  int dnn_q;
};
struct Resource {
  Sample sample;
  int dnn_q_pos;
  int mt_q_pos;
  int top_bottom;
};

struct comp {
  bool operator()(const Sample& sample1, const Sample& sample2) {
    // sort by dnn_q value, reverse
    auto dnn_q_1 = sample1.dnn_q;
    auto dnn_q_2 = sample2.dnn_q;
    return dnn_q_1 > dnn_q_2;
  }
};

struct comp2 {
  bool operator()(const Resource& res1, const Resource& res2) {
    auto mt_q_1 = res1.sample.mt_q;
    auto mt_q_2 = res2.sample.mt_q;
    return mt_q_1 > mt_q_2;
  }
};

std::vector<std::string> read_info(std::unordered_map<std::string, std::vector<std::string>>& dict, std::string key, bool is_list = false, std::string default_value = "-1") {
  if (is_list) {
    if (dict.find(key) != dict.end()) return dict[key];
    else return {};
  } else {
    if (dict.find(key) != dict.end()) return {dict[key][0]};
    else return {default_value};
  }
}

/*
int split_string(const std::string& str, char delim, std::vector<std::string>& res, int split_time = -1) {
    int split_cnt = 0;
    if (str.empty()) {
        return 0;
    }   
    res.clear();
    size_t st = 0;
    size_t pos = str.find(delim);
    while (pos != std::string::npos) {
        res.push_back(str.substr(st, pos - st));
        st = pos + 1;
        pos = str.find(delim, pos + 1);
        split_cnt += 1;
        if (split_time != -1 && split_cnt >= split_time) {
            break;
        }
    }   
    res.push_back(str.substr(st));
    return res.size();
}
*/
  
// std::string trim_space(const std::string& str) {
//   const char* p = str.c_str();

//   while (*p != 0 && isspace(*p)) {
//     p++;
//   }

//   size_t len = strlen(p);

//   while (len > 0 && isspace(p[len - 1])) {
//     len--;
//   }

//   return std::string(p, len);
// }

class NLParser : public CustomParser {
    static const int MAX_FETCH_NUM = 10000;
    static const int INT_BYTES = 4;
    typedef std::function<void(SlotRecord*&, int)> GetRecordFunc;
public:
    NLParser() {}
    virtual ~NLParser() {
      std::cout << "delete tieba parser" << std::endl;
    }
    void Init(const std::vector<SlotConf> &conf) {
    }
    bool Init(const std::vector<AllSlotInfo>& slots) {
        std::cout << "wxx init" << std::endl;
        srand((unsigned)time(NULL));
    slot_info = slots;
    for (size_t i = 0; i < slot_info.size(); ++i) {
      // label_duration, has_duration, dnn_q, has_dnn_q, mt_q, has_mt_q
      if (slot_info[i].used_idx == -1 || slot_info[i].slot_value_idx == -1) {
        std::cout << "yxf parser init:: slot idx: " << i << " unused"
                  << std::endl;
        continue;
      }
      if (slot_info[i].type[0] == 'u') {
        if (slot_info[i].slot == "show") {
          show_pos = slot_info[i].slot_value_idx;
        } else if (slot_info[i].slot == "click") {
          click_pos = slot_info[i].slot_value_idx;
        } else if (slot_info[i].slot == "has_dur") {
          has_duration_pos = slot_info[i].slot_value_idx;
        } else if (slot_info[i].slot == "has_dnn_q") {
          has_dnn_q_pos = slot_info[i].slot_value_idx;
        } else if (slot_info[i].slot == "has_mt_q") {
          has_mt_q_pos = slot_info[i].slot_value_idx;
        } else {
          int slot = atoi(slot_info[i].slot.c_str());
          slot_map[slot] = slot_info[i].slot_value_idx;
        }
        ++uint64_slot_num_;
      } else if (slot_info[i].type[0] == 'f') {
        if (slot_info[i].slot == "dur") {
          duration_pos = slot_info[i].slot_value_idx;
        } else if (slot_info[i].slot == "dnn_q") {
          dnn_q_pos = slot_info[i].slot_value_idx;
        } else if (slot_info[i].slot == "mt_q") {
          mt_q_pos = slot_info[i].slot_value_idx;
        }
        ++float_slot_num_;
      }
    }

    std::cout << "wxx init end" << std::endl;
    fprintf(stdout,
            "slot uint64: %d, float: %d, click: %d, show: %d, has_dur: %d, "
            "has_dnn: %d, has_mt: %d"
            "dur pos: %d, dnn pos: %d, mt pos: %d\n",
            uint64_slot_num_,
            float_slot_num_,
            click_pos,
            show_pos,
            has_duration_pos,
            has_dnn_q_pos,
            has_mt_q_pos,
            duration_pos,
            dnn_q_pos,
            mt_q_pos);
    return true;
    }
    
    void ParseOneInstance(const char* str, Record* instance) {
        assert(0);
    }
    
    int ParseInstance(int read_len, const char* str, std::vector<Record>* instances) {
        //std::cout << "wxx parse instance" << std::endl;
        return read_len;
    }
    
    virtual bool ParseFileInstance(
            std::function<int(char *buf, int len)> ReadBuffFunc,
            std::function<void(std::vector<SlotRecord>&, int, int)> PullRecordsFunc,
            int &ret_lines) {
        int offset = 0;
        thread_local std::vector<SlotRecord> records_vec;
        records_vec.clear();
 
        GetRecordFunc func = [this, &offset, &PullRecordsFunc](SlotRecord *&arr,
                int len) {
            if (static_cast<size_t>(offset + len) > records_vec.size()) {
                PullRecordsFunc(records_vec, MAX_FETCH_NUM, offset);
                offset = 0;
            }
            arr = &records_vec[offset];
            offset += len;
        };
 
        int ret = 0;
        int skip_lines = ret_lines;
        int lines = 0;
        bool is_error = false;
 
        thread_local std::string sbuff;
        size_t max_buff_len = 8 * 1024 * 1024; // 8M
        sbuff.resize(max_buff_len);
        char *ptr = &sbuff[0];
 
        size_t body_len = 0;
        size_t left_len = 0;
        size_t need_len = 0;
 
        while ((ret = ReadBuffFunc(ptr, max_buff_len - left_len)) > 0) {
            left_len += ret;
            ptr = &sbuff[0];
            body_len = get_bodylen(ptr);
            need_len = body_len + INT_BYTES;
            if (need_len > max_buff_len) {
                fprintf(stderr, "need_len[%ld] > max_buff_len[%ld]\n", need_len, max_buff_len);
                break;
            }
            while (left_len >= need_len) {
                ++lines;
                if (lines > skip_lines) {
                    if (!parser_one_pb(&ptr[INT_BYTES], body_len, func)) {
                        is_error = true;
                        fprintf(stderr, "[%d] pb lines data error\n", lines);
                    }
                }
                ptr += need_len;
                left_len -= need_len;
                if (left_len < INT_BYTES) {
                    break;
                }
                body_len = get_bodylen(ptr);
                need_len = body_len + INT_BYTES;
            }
            if (left_len > 0) {
                memmove(&sbuff[0], ptr, left_len);
                ptr = &sbuff[0] + left_len;
            } else {
                ptr = &sbuff[0];
            }
        }
 
        // free all
        PullRecordsFunc(records_vec, 0, offset);
        ret_lines = lines;
 
        return (!is_error);
    }
private:
    bool parser_one_pb(const char *line, const int len, GetRecordFunc func) {
        // return true;
        if (len <= 0) {
        fprintf(stderr, "data len error, len: %d\n", len);
        return false;
        }

        thread_local baidu::feed::mlarch::FeatureSign feasign;
        feasign.Clear();

        if (!feasign.ParseFromArray(line, len)) {
        fprintf(stderr, "paser pb error, len: %d\n", len);
        return false;
        }

        if (feasign.instance_size() <= 0) {
        fprintf(stderr, "feasign.instance is empty\n");
        return false;
        }
        return _parser_one_pb(feasign, func);
    }


    bool _parser_one_pb(const baidu::feed::mlarch::FeatureSign& one_pb,
                      GetRecordFunc func) {
    // thread_local std::string label_str = "";
    thread_local std::vector<Sample> cur_feasign_list;
    cur_feasign_list.clear();
    for (int i = 0; i < one_pb.instance_size(); i++) {
      auto label_str = one_pb.instance(i).label();
      thread_local std::vector<std::string> t_l;
      t_l.clear();
      thread_local std::vector<std::string> label_item;
      label_item.clear();
      split_string(label_str, ' ', t_l);

      int dnn_q = -1;
      int mt_q = -1;

      //   thread_local std::string vertical_type = "-1";
      std::string is_microvideo = "-1";
      std::string vertical_type = "-1";

      std::string content_type = "news";

      for (auto& label : t_l) {
        if (label.find("is_microvideo:") != label.npos) {
          split_string(label, ':', label_item);
          is_microvideo = trim_space(label_item[1]);
          //if (is_microvideo == "1") {
              //break;
          //}
        } else if (label.find("dnn_q:") != label.npos) {
          split_string(label, ':', label_item);
          dnn_q = std::stoi(trim_space(label_item[1]));
        } else if (label.find("mt_q:") != label.npos) {
          split_string(label, ':', label_item);
          mt_q = std::stoi(trim_space(label_item[1]));
        } else if (label.find("vertical_type:") != label.npos) {
          split_string(label, ':', label_item);
          vertical_type = trim_space(label_item[1]);
          // if (trim_space(label_item[1]) == "14") {
          //  content_type = "shortvideo";
          //}

        } 
      }

      if (vertical_type == "14" && is_microvideo != "1") content_type = "shortvideo";
      if (vertical_type == "14" && is_microvideo == "1") {
          //continue;
          // content_type = "microvideo";
          continue;
      }
    //   if (vertical_type == "14") {
    //     // if (is_microvideo == "1") {
    //     //   content_type = "microvideo";
    //     // } else {
    //       content_type = "shortvideo";
    //     // }
    //   }
      Sample sample = {i, content_type, mt_q, dnn_q};
      cur_feasign_list.emplace_back(sample);
    }

    process(one_pb, cur_feasign_list, func);

    cur_feasign_list.clear();
    return true;
  }

  void process(const ::baidu::feed::mlarch::FeatureSign& one_pb,
               std::vector<Sample>& cur_feasign_list, GetRecordFunc func) {
    // filter start
    std::sort(cur_feasign_list.begin(), cur_feasign_list.end(), comp());
    std::vector<std::vector<Resource>> split_resource_lists(2);

    // for(int i = 0; i < split_resource_lists.size(); i++) {
    //  split_resource_lists.reserve();
    //}

    std::vector<std::string> vec;
    // std::vector<std::string> ins_seg;
    std::vector<std::string> each_segs;
    // std::unordered_map<std::string, std::vector<std::string>> label_dict;
    std::vector<std::string> value_segs;
    // std::vector<std::string> tokens;

    thread_local std::unordered_map<std::string, float> ubc_dur_dict;
    ubc_dur_dict.clear();


    //   int slot_num = slot_map.size();
    //   int max_feasign_num = 10000;

    for (size_t i = 0; i < cur_feasign_list.size(); i++) {
      auto content_type = cur_feasign_list[i].content_type;
      if (content_type == "shortvideo") {
        split_resource_lists[1].push_back({cur_feasign_list[i], 0, 0, 0});
      } else if (content_type != "microvideo"){
        split_resource_lists[0].push_back({cur_feasign_list[i], 0, 0, 0});
      }
    }

    thread_local std::vector<std::vector<uint64_t>> uint64_feasigns;
    uint64_feasigns.clear();
    uint64_feasigns.resize(uint64_slot_num_);
    for (auto& t : uint64_feasigns) {
      t.clear();
    }
    int user_fea_num = 0;


    const ::baidu::feed::mlarch::Instance& user_ins = one_pb.user_instance();
    std::unordered_set<int> user_slot_set;

    for (int i = 0; i < user_ins.slot_id_size(); ++i) {
      int slot = user_ins.slot_id(i);
      // uint16_t slot = user_ins.slot_id(i);
      if (slot_map.find(slot) == slot_map.end()) continue;
      auto& id = slot_map[slot];
      // if (id == -1) {
      //    continue;
      //}
      uint64_t sign = user_ins.sign(i);
      //   user_feasigns.push_back({id, sign});
      uint64_feasigns[id].push_back(sign);
      user_slot_set.insert(id);
      ++user_fea_num;
    }

    // std::vector<std::pair<int, uint64_t>>::iterator it;
    // for (it = user_feasigns.begin(); it != user_feasigns.end(); ++it) {
    //   uint64_feasigns[it->first].push_back(it->second);
    //   ++user_fea_num;
    // }

    thread_local std::vector<std::vector<float>> float_feasigns;
    float_feasigns.clear();
    float_feasigns.resize(float_slot_num_);
    for (auto& t : float_feasigns) {
      t.resize(1);
    }

    for (int i = 0; i < 2; i++) {
      auto top_index = (int)(0.3 * split_resource_lists[i].size());
      auto bottom_index = (int)(0.7 * split_resource_lists[i].size());
      auto dnn_q_pos_index = (int)(0.2 * split_resource_lists[i].size());

      for (size_t j = 0; j < split_resource_lists[i].size(); j++) {
        if (j < top_index)
          split_resource_lists[i][j].top_bottom = 1;
        else if (j > bottom_index)
          split_resource_lists[i][j].top_bottom = -1;
        else {
          split_resource_lists[i][j].top_bottom = 0;
        }

        if (j < dnn_q_pos_index)
          split_resource_lists[i][j].dnn_q_pos = 1;
        else
          split_resource_lists[i][j].dnn_q_pos = 0;
      }

      std::sort(split_resource_lists[i].begin(),
                split_resource_lists[i].end(),
                comp2());

      auto mt_q_pos_index = (int)(0.2 * split_resource_lists[i].size());

      for (size_t index = 0; index < split_resource_lists[i].size(); index++) {
        if (index < mt_q_pos_index) {
          split_resource_lists[i][index].mt_q_pos = 1;
        } else {
          split_resource_lists[i][index].mt_q_pos = 0;
        }
      }
        
      thread_local std::unordered_map<std::string, std::vector<std::string>> label_dict = {};

      for (size_t index = 0; index < split_resource_lists[i].size(); index++) {
        label_dict.clear();
        ubc_dur_dict.clear();

        auto& ins = one_pb.instance(split_resource_lists[i][index].sample.idx);
        //   std::string line_ = split_resource_lists[i][index].sample.line;
        //   split_string(line_, '\t', vec);
        //   if (vec.size() < 3) {
        //     continue;
        //   }

        //   std::string ins = trim_space(vec[0]);
        //   std::string vec_str = trim_space(vec[1]);
        std::string label_str = ins.label();

        //   split_string(ins, ' ', ins_seg);
        //   if (ins_seg.size() < 4) {
        //     continue;
        //   }

        auto show = ins.show();
        auto click = ins.click();

        // comment to check
        // unshow keep 2.5%
        auto dnn_q_sort_label = split_resource_lists[i][index].top_bottom;
        if (show == 0) {
           if (dnn_q_sort_label == 1) {
            if ((1 + rand() % 400) > 18) continue;
           } else if (dnn_q_sort_label == 0) {
            if ((1 + rand() % 400) > 9) continue;
           } else if (dnn_q_sort_label == -1) {
            if ((1 + rand() % 400) > 3) continue;
           } else
            continue;
        }

        // show and unclick drop 50%
        if (show == 1 && click == 0 && (1 + rand() % 10) <= 5) continue;

        // int channel_id = 1;
        // int vertical_type = -1;
        // thread_local std::vector<std::string> ubc_id_list = {};
        // thread_local std::vector<std::string> ubc_pl_list = {};
        // thread_local std::unordered_map<std::string, std::vector<std::string>> label_dict;

        split_string(label_str, ' ', vec);
        for (auto& each: vec) {
          split_string(each, ':', each_segs);
          if (each_segs.size() < 2) continue;
          auto k = each_segs[0];
          auto v = each_segs[1];
          split_string(v, ',', value_segs);
          label_dict[k] = value_segs;
        }

        auto channel_id = stoi(read_info(label_dict, "channel_id", false, "1")[0]);
        auto vertical_type = stoi(read_info(label_dict, "vertical_type")[0]);
        auto ubc_id_list = read_info(label_dict, "ubc", true);
        auto ubc_pl_list = read_info(label_dict, "ubc_pl", true);
        auto is_microvideo = stoi(read_info(label_dict, "is_microvideo")[0]);

        auto dnn_q = (float)(stoi(read_info(label_dict, "dnn_q", false, "-1")[0]) / (float)1000000.0);
        auto mt_q = (float)(stoi(read_info(label_dict, "mt_q", false, "-1")[0]) / (float)1000000.0);

        /*
        split_string(label_str, ' ', vec);

        for (auto& each : vec) {
        //   split_string(each, ':', each_segs);
        //   if (each_segs.size() < 2) continue;
        //   std::string trim_label = trim_space(each_segs[1]);
          if (each.find("channel_id:") != each.npos) {
              split_string(each, ':', each_segs);
              if (each_segs.size() < 2) continue;
        //   std::string trim_label = trim_space(each_segs[1]);
              channel_id = std::stoi(trim_space(each_segs[1]));
          } else if (each.find("vertical_type:") != each.npos) {
              split_string(each, ':', each_segs);
              if (each_segs.size() < 2) continue;
         //   std::string trim_label = trim_space(each_segs[1]);
              vertical_type = std::stoi(trim_space(each_segs[1]));
          } else if (each.find("ubc:") != each.npos) {
              split_string(each, ':', each_segs);
          if (each_segs.size() < 2) continue;
        //   std::string trim_label = trim_space(each_segs[1]);
              split_string(trim_space(each_segs[1]), ',', value_segs);
              ubc_id_list = value_segs;
          } else if (each.find("ubc_pl:") != each.npos) {
              split_string(each, ':', each_segs);
          if (each_segs.size() < 2) continue;
        //   std::string trim_label = trim_space(each_segs[1]);
              split_string(trim_space(each_segs[1]), ',', value_segs);
              ubc_pl_list = value_segs;
          } 
        //   auto k = each_segs[0];
        //   auto v = each_segs[1];
        //   split_string(v, ',', value_segs);
        //   label_dict[k] = value_segs;
        }
        */

        if (channel_id != 1) continue;
        // auto vertical_type =
        //     std::stoi(read_info(label_dict, "vertical_type")[0]);
        // auto ubc_id_list = read_info(label_dict, "ubc", true);
        // auto ubc_pl_list = read_info(label_dict, "ubc_pl", true);
        //   auto is_microvideo = stoi(read_info(label_dict,
        //   "is_microvideo")[0]);
        // float dnn_q = (float)(split_resource_lists[i][index].sample.dnn_q / (float)1000000.0);
        // float mt_q = (float)(split_resource_lists[i][index].sample.mt_q / (float)1000000.0);
        // auto dnn_q =
        //     (float)(stoi(read_info(label_dict, "dnn_q", false, "-1")[0]) /
        //             (float)1000000.0);
        // auto mt_q =
        //     (float)(stoi(read_info(label_dict, "mt_q", false, "-1")[0]) /
        //             (float)1000000.0);

        auto ins_id = ins.logkey();

        auto has_dnn_q = 0;
        if (dnn_q > 0 && dnn_q < 1) has_dnn_q = 1;
        auto has_mt_q = 0;
        if (mt_q > 0 && mt_q < 1) has_mt_q = 1;

        for (size_t j = 0; j < ubc_id_list.size(); j++) {
          ubc_dur_dict[ubc_id_list[j]] = stof(ubc_pl_list[j]) / 1000;
        }
       
        // for(auto& item: ubc_dur_dict) {
        //  std::cout << item.first << ":" << item.second << std::endl;
        //}


        float duration = -1.0;
        std::unordered_set<int> vertical_type_set{0, 1, 5, 9, 11, 16, 17};

        if (vertical_type == 14) {
          if (ubc_dur_dict.find("485") != ubc_dur_dict.end()) {
            duration = ubc_dur_dict["485"];
          }
        } else if (vertical_type == 29) {

          if (ubc_dur_dict.find("6072") != ubc_dur_dict.end()) {
            duration = ubc_dur_dict["6072"];
          }

        } else if (vertical_type_set.find(vertical_type) !=
                   vertical_type_set.end()) {

          if (ubc_dur_dict.find("346") != ubc_dur_dict.end())
            duration = ubc_dur_dict["346"];

        } else if (vertical_type == 20) {
          float dur1 = -1, dur2 = -1;
          if (ubc_dur_dict.find("1559") != ubc_dur_dict.end())
            dur1 = ubc_dur_dict["1559"];
          if (ubc_dur_dict.find("131") != ubc_dur_dict.end())
            dur2 = ubc_dur_dict["131"];
          duration = std::max(dur1, dur2);

        } else continue;

        if (click == 0) duration = -1;

        float label_duration = 0.0;
        auto has_duration = 0;
        label_duration =
            std::max((float)0.0, std::min((float)1.0, (float)duration / 360));

        if (duration >= 0) {
          has_duration = 1;
        }

/*
        std::string ubc_str = "";
        std::string ubc_pl_str = "";
 
       if(label_dict.find("ubc") != label_dict.end()) {
        for(int k = 0; k < label_dict["ubc"].size();k++) {
          ubc_str = ubc_str + label_dict["ubc"][k];
          if (k + 1 != label_dict["ubc"].size()) ubc_str += ","; 
        }
       }
       if(label_dict.find("ubc_pl") != label_dict.end()) {
        for(int k = 0; k < label_dict["ubc_pl"].size();k++) {
          ubc_pl_str = ubc_pl_str + label_dict["ubc_pl"][k];
          if (k + 1 != label_dict["ubc_pl"].size()) ubc_pl_str += ","; 
        }
       }

        std::cout << ins.logkey() << ":" << has_duration << ":" << vertical_type << ":" << ubc_str << ":" << ubc_pl_str << std::endl;
*/

        // if (has_duration == 0) continue;
 
        // filter end
        // thread_local std::vector<std::vector<uint64_t>> uint64_feasigns;
        // uint64_feasigns.resize(uint64_slot_num_);
        // for (auto &t : uint64_feasigns) {
        //     t.clear();
        // }
        for (size_t slot_idx = 0; slot_idx < uint64_feasigns.size();
             slot_idx++) {
          if (user_slot_set.find(slot_idx) == user_slot_set.end()) {
            uint64_feasigns[slot_idx].clear();
          }
        }
        // thread_local std::vector<std::vector<float>> float_feasigns;
        // float_feasigns.resize(float_slot_num_);
        // for (auto &t : float_feasigns) {
        //     t.clear();
        // }
        int fea_num = user_fea_num;
        // slot会重复, 也就是slot对应多个feasign
        // 
        for (int j = 0; j < ins.slot_id_size(); j++) {
          int slot = ins.slot_id(j);
          if (slot_map.find(slot) == slot_map.end()) continue;
          auto& id = slot_map[slot];
          uint64_t sign = ins.sign(j);
          uint64_feasigns[id].emplace_back(sign);
          ++fea_num;
        }

        // int test_fea_num = fea_num;
        // std::vector<std::pair<int, uint64_t>>::iterator it;
        // for (it = user_feasigns.begin(); it != user_feasigns.end(); ++it) {
        //     uint64_feasigns[it->first].push_back(it->second);
        //     ++fea_num;
        // }
        // std::cout << "yxf no user num: " << test_fea_num << " user num: " <<
        // fea_num - test_fea_num << std::endl;

        // uint64_feasigns[show_pos].clear();
        uint64_feasigns[show_pos].push_back(show);

        // uint64_feasigns[click_pos].clear();
        uint64_feasigns[click_pos].push_back(click);

        // label_duration, has_duration, dnn_q, has_dnn_q, mt_q, has_mt_q

        // float_feasigns[duration_pos].clear();
        // float_feasigns[duration_pos].push_back(label_duration);
        float_feasigns[duration_pos][0] = label_duration;

        // uint64_feasigns[has_duration_pos].clear();
        uint64_feasigns[has_duration_pos].push_back(has_duration);

        // float_feasigns[dnn_q_pos].clear();
        // float_feasigns[dnn_q_pos].push_back(dnn_q);
        float_feasigns[dnn_q_pos][0] = dnn_q;

        // uint64_feasigns[has_dnn_q_pos].clear();
        uint64_feasigns[has_dnn_q_pos].push_back(has_dnn_q);

        // float_feasigns[mt_q_pos].clear();
        // float_feasigns[mt_q_pos].push_back(mt_q);
        float_feasigns[mt_q_pos][0] = mt_q;

        // uint64_feasigns[has_mt_q_pos].clear();
        uint64_feasigns[has_mt_q_pos].push_back(has_mt_q);

        SlotRecord* vec = NULL;
        func(vec, 1);
        SlotRecord rec = vec[0];
        rec->ins_id_ = ins.logkey();
        rec->slot_float_feasigns_.add_slot_feasigns(float_feasigns, 3);
        rec->slot_uint64_feasigns_.add_slot_feasigns(uint64_feasigns,
                                                     fea_num + 5);
      }
    }
  }
    
    int get_bodylen(char *buf) {
        int value = 0;
        for (int i = 3; i >= 0; --i) {
            *(((char*) &value) + i) = buf[3 - i];
        }
        return value;
    }

    std::unordered_map<int, int> slot_map;
    std::vector<AllSlotInfo> slot_info;


    // int show_pos;
    // int click_pos;
    // thread_local static std::vector<Sample> cur_feasign_list;
    // thread_local static std::string pre_request_id;

    int show_pos;
    int click_pos;
    int duration_pos;
    int has_duration_pos;
    int dnn_q_pos;
    int has_dnn_q_pos;
    int mt_q_pos;
    int has_mt_q_pos;
    int float_slot_num_ = 0;
    int uint64_slot_num_ = 0;
    
};
// thread_local std::vector<Sample> NLParser::cur_feasign_list = {};
// thread_local std::string NLParser::pre_request_id = "";
}
}

extern "C" {
paddle::framework::CustomParser *CreateParserObject() {
    return new paddle::framework::NLParser();
}
}
