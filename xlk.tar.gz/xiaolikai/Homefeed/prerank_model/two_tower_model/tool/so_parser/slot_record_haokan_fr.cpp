#include "custom_parser.h"
#include "feature_sign.pb.h"
#include <vector>
#include <string>
#include <assert.h>
#include <unordered_map>
#include <iostream>
#include <cmath>
#include <iostream>
#include <sstream>
#include <fstream>
namespace paddle {
namespace framework {

class HaokanFRParser : public CustomParser {
    static const int MAX_FETCH_NUM = 10000;
    static const int INT_BYTES = 4;
    typedef std::function<void(SlotRecord*&, int)> GetRecordFunc;
public:
    HaokanFRParser() {}
    virtual ~HaokanFRParser() {
      std::cout << "delete tieba parser" << std::endl;
    }
    void Init(const std::vector<SlotConf> &conf) {
    }
    bool Init(const std::vector<AllSlotInfo>& slots) {
        std::cout << "wxx init" << std::endl;
        slot_info = slots;
        for (size_t i = 0; i < slot_info.size(); ++i) {
          if (slot_info[i].slot == "show") {
            show_pos = slot_info[i].slot_value_idx;
          }
          if (slot_info[i].slot == "click") {
            click_pos = slot_info[i].slot_value_idx;
          }
          if (slot_info[i].slot == "realfr") {
            realfr_pos = slot_info[i].slot_value_idx;
          }
          if (slot_info[i].slot == "readlist") {
            readlist_pos = slot_info[i].slot_value_idx;
          }
          if (slot_info[i].slot == "ins_tag") {
            ins_tag_pos = slot_info[i].slot_value_idx;
          }
          if (slot_info[i].slot == "lowthred_label") {
            lowthred_label_pos = slot_info[i].slot_value_idx;
          }
          if (slot_info[i].slot == "highthred_label") {
            highthred_label_pos = slot_info[i].slot_value_idx;
          }
          if (slot_info[i].slot == "vi_tag") {
            vi_tag_pos = slot_info[i].slot_value_idx;
          }
          if (slot_info[i].slot == "inactive_tag") {
            inactive_tag_pos = slot_info[i].slot_value_idx;
          }
          if (slot_info[i].slot == "active_tag") {
            active_tag_pos = slot_info[i].slot_value_idx;
          }
          if (slot_info[i].slot == "va_tag") {
            va_tag_pos = slot_info[i].slot_value_idx;
          }
          if (slot_info[i].slot_value_idx == -1) {
            continue;
          }
          if (slot_info[i].type[0] == 'u') {
            ++uint64_slot_num_;
          } else if (slot_info[i].type[0] == 'f') {
            ++float_slot_num_;
          }
          int slot = atoi(slot_info[i].slot.c_str());
          slot_map[slot] = slot_info[i].slot_value_idx;
        }
        return true;
    }
    
    void ParseOneInstance(const char* str, Record* instance) {
        assert(0);
    }
    
    int ParseInstance(int read_len, const char* str, std::vector<Record>* instances) {
        //std::cout << "wxx parse instance" << std::endl;
        return read_len;
    }
    
    virtual bool ParseFileInstance(
            std::function<int(char *buf, int len)> ReadBuffFunc,
            std::function<void(std::vector<SlotRecord>&, int, int)> PullRecordsFunc,
            int &ret_lines) {
        int offset = 0;
        thread_local std::vector<SlotRecord> records_vec;
        records_vec.clear();
 
        GetRecordFunc func = [this, &offset, &PullRecordsFunc](SlotRecord *&arr,
                int len) {
            if (static_cast<size_t>(offset + len) > records_vec.size()) {
                PullRecordsFunc(records_vec, MAX_FETCH_NUM, offset);
                offset = 0;
            }
            arr = &records_vec[offset];
            offset += len;
        };
 
        int ret = 0;
        int skip_lines = ret_lines;
        int lines = 0;
        bool is_error = false;
 
        thread_local std::string sbuff;
        size_t max_buff_len = 8 * 1024 * 1024; // 8M
        sbuff.resize(max_buff_len);
        char *ptr = &sbuff[0];
 
        size_t body_len = 0;
        size_t left_len = 0;
        size_t need_len = 0;
 
        while ((ret = ReadBuffFunc(ptr, max_buff_len - left_len)) > 0) {
            left_len += ret;
            ptr = &sbuff[0];
            body_len = get_bodylen(ptr);
            need_len = body_len + INT_BYTES;
            if (need_len > max_buff_len) {
                fprintf(stderr, "need_len[%ld] > max_buff_len[%ld]\n", need_len, max_buff_len);
                break;
            }
            while (left_len >= need_len) {
                ++lines;
                if (lines > skip_lines) {
                    if (!parser_one_pb(&ptr[INT_BYTES], body_len, func)) {
                        is_error = true;
                        fprintf(stderr, "[%d] pb lines data error\n", lines);
                    }
                }
                ptr += need_len;
                left_len -= need_len;
                if (left_len < INT_BYTES) {
                    break;
                }
                body_len = get_bodylen(ptr);
                need_len = body_len + INT_BYTES;
            }
            if (left_len > 0) {
                memmove(&sbuff[0], ptr, left_len);
                ptr = &sbuff[0] + left_len;
            } else {
                ptr = &sbuff[0];
            }
        }
 
        // free all
        PullRecordsFunc(records_vec, 0, offset);
        ret_lines = lines;
 
        return (!is_error);
    }
private:
    bool parser_one_pb(const char *line, const int len, GetRecordFunc func) {
        if (len <= 0) {
            fprintf(stderr, "data len error, len: %d\n", len);
            return false;
        }
 
        thread_local baidu::feed::mlarch::FeatureSign feasign;
        feasign.Clear();
 
        if (!feasign.ParseFromArray(line, len)) {
            fprintf(stderr, "paser pb error, len: %d\n", len);
            return false;
        }
 
        if (feasign.instance_size() <= 0) {
            fprintf(stderr, "feasign.instance is empty\n");
            return false;
        }
 
        // user
        thread_local std::vector<std::pair<int, uint64_t>> user_feasigns;
        user_feasigns.clear();
        const ::baidu::feed::mlarch::Instance &user_ins = feasign.user_instance();
        for (int i = 0; i < user_ins.slot_id_size(); ++i) {
            uint16_t slot = user_ins.slot_id(i);
            auto it = slot_map.find(slot);
            if (it == slot_map.end()) {
                continue;
            }
            auto id = it->second;
            if (id == -1) {
                continue;
            }
            uint64_t sign = user_ins.sign(i);
            user_feasigns.push_back({id, sign});
        }
        for (int i = 0; i < feasign.instance_size(); i++) {
            parser_one_ins(feasign.instance(i), user_ins, user_feasigns, func);
        }
        return true;
    }
    
    bool parser_one_ins(const ::baidu::feed::mlarch::Instance &ins,
            const ::baidu::feed::mlarch::Instance& user_ins,
            std::vector<std::pair<int, uint64_t>> &user_feasigns,
            GetRecordFunc func) {
        std::string label_str = ins.label();
        std::string tags = ins.tag();
        int flag = 0;
        for (auto& label : labels) {
            if (label_str.find(label) != label_str.npos) {
                flag = 1;
                break;
            }
        }
        if (!flag) return true;
        
        thread_local std::vector<float> dense_vec_fea;
        thread_local std::vector<std::string> t_l;
        thread_local std::vector<std::string> label_item;
        dense_vec_fea.clear();
        t_l.clear();
        label_item.clear();
        int fea_num = 0;
        
        for (auto& ebd : ins.ebd_slot()) {
            if (ebd.slot_id() == 10000) {
                for (auto value : ebd.value()) {
                    dense_vec_fea.push_back(value);
                }
            }
        }
        for (auto& ebd : user_ins.ebd_slot()) {
            if (ebd.slot_id() == 10000) {
                for (auto value : ebd.value()) {
                    dense_vec_fea.push_back(value);
                }
            }
        }
        int read_cnt = dense_vec_fea[1];
        if (dense_vec_fea.size() != 9) {
            dense_vec_fea.clear();
            dense_vec_fea.resize(9);
            for (int i = 0; i < 9; i++) {
                dense_vec_fea[i] = 0;
            }
        }
        int show = 0;
        int clk = 0;
        int ua = -1;
        int du = 0;
        int pl = 0;
        int u_7d_pl = 0;
        int u_7d_freq = 0;

        split_string(label_str, ' ', t_l);
        for (auto& label : t_l) {
            split_string(label, ':', label_item);
            std::string trim_label = trim_space(label_item[1]);
            if (label.find("sv_duration:") != label.npos)
                du = std::stoi(trim_label);
            else if (label.find("duration_v2:") != label.npos)
                pl = std::stoi(trim_label);
            else if (label.find("ua:") != label.npos)
                ua = std::stoi(trim_label);
            else if (label.find("7d_pl:") != label.npos)
                u_7d_pl = std::stoi(trim_label);
            else if (label.find("7d_freq:") != label.npos)
                u_7d_freq = std::stoi(trim_label);
            else if (label.find("show_count:") != label.npos) {
                show = std::stoi(trim_label);
                if (show > 1) show = 1;
            }
            else if (label.find("click_count:") != label.npos) {
                clk = std::stoi(trim_label);
                if (clk > 1) clk = 1;
            }
        }
        if (pl > 0) clk = 1;
        if (clk > show) show = clk;
        if (du == 0) return true;
        if (ua == 6 || ua == 15 || ua == 16) {
            if (clk == 0) return true;
        }
        if (pl > du) pl = du;
        double fr = (double) pl / (double) du;
        if (fr >= 1.0) 
            fr = 0.99999;
        else if (fr <= 0.0) 
            fr = 0.00001;
        
        int pos = clk;
        int neg = show - clk;
        int lowthred = 0;
        int highthred = 0;
        int inactive_tag = 0;
        int active_tag = 0;
        int va_tag = 0;
        int vi_tag = 0;

        if (ua == 107) {
            if (clk >= 1) lowthred = 1;
        }
        else if (ua == 6 || ua == 15 || ua == 16) {
            if (pl >= 5) lowthred = 1;
        }

        if (fr >= 0.95) highthred = 1;

        if (read_cnt <= 20 && clk >= 1) 
            vi_tag = 2;
        else if (read_cnt <= 200 && clk >=1)
            inactive_tag = 3;
        else if (read_cnt <= 999 and clk >=1)
            active_tag = 4;
        else if (read_cnt <= 1000 and clk >=1)
            va_tag = 5;
        
        int mode = 0;
        if (tags.find("MASTER") == tags.npos) {
            show = 0;
            clk = 0;
            fr = 0.0;
            ua = 0;
            mode = 1;
        }

        if (mode == 1) {
            dense_vec_fea.clear();
            dense_vec_fea.resize(9);
            for (int i = 0; i < 9; i++) {
                dense_vec_fea[i] = 0;
            }
        }


        // clear temp vector
        thread_local std::vector<std::vector<uint64_t>> uint64_feasigns;
        uint64_feasigns.resize(uint64_slot_num_);
        for (auto &t : uint64_feasigns) {
            t.clear();
        }
 
        thread_local std::vector<std::vector<float>> float_feasigns;
        float_feasigns.resize(float_slot_num_);
        for (auto &t : float_feasigns) {
            t.clear();
        }
 
        //int click = ins.click() ? 1 : 0;
        //uint64_feasigns[click_pos].push_back(click);
        //解析doc侧sparse特征
        // 40257 newid
        for (int j = 0; j < ins.slot_id_size(); ++j) {
            //不在slot列表中过滤掉
            uint16_t slot = ins.slot_id(j);

            auto it = slot_map.find(slot);
            if (it == slot_map.end()) {
                continue;
            }
            auto id = it->second;
            if (id == -1) {
                continue;
            }
            uint64_t sign = ins.sign(j);
            uint64_feasigns[id].push_back(sign);
            ++fea_num;
        }
        //将user侧sparse特征合并到doc侧
        std::vector<std::pair<int, uint64_t>>::iterator it;
        for (it = user_feasigns.begin(); it != user_feasigns.end(); ++it) {
            uint64_feasigns[it->first].clear();
        }
        for (it = user_feasigns.begin(); it != user_feasigns.end(); ++it) {
            uint64_feasigns[it->first].push_back(it->second);
            ++fea_num;
        }
        for (int j = 0; j < dense_vec_fea.size(); j++) {
            float_feasigns[readlist_pos].push_back(dense_vec_fea[j]);
        }
        
        
        uint64_feasigns[lowthred_label_pos].push_back(lowthred);
        uint64_feasigns[highthred_label_pos].push_back(highthred);
        uint64_feasigns[vi_tag_pos].push_back(vi_tag);
        uint64_feasigns[inactive_tag_pos].push_back(inactive_tag);
        uint64_feasigns[active_tag_pos].push_back(active_tag);
        uint64_feasigns[va_tag_pos].push_back(va_tag);
        uint64_feasigns[click_pos].push_back(clk);
        uint64_feasigns[ins_tag_pos].push_back(ua);
        fea_num += 8;
        
        float_feasigns[realfr_pos].push_back(fr);
        std::string ins_id = ins.logkey();
        
        int ins_num = neg + pos;
        int cur = 0;
        SlotRecord *vec = NULL;
        func(vec, ins_num);
        
        for (int j = 0; j < neg; j++) {
            std::string line_id = ins_id;
            line_id.append("-neg-");
            line_id.append(std::to_string(j));
            int show = 1;
            int click = 0;
            if (tags.find("MASTER") == tags.npos) {
                show = 0;
                click = 0;
            }
            uint64_feasigns[show_pos].clear();
            uint64_feasigns[click_pos].clear();
            uint64_feasigns[show_pos].push_back(show);
            uint64_feasigns[click_pos].push_back(click);
            
            SlotRecord rec = vec[cur++];
            rec->ins_id_ = ins_id;
            rec->slot_float_feasigns_.add_slot_feasigns(float_feasigns, dense_vec_fea.size() + 1);
            rec->slot_uint64_feasigns_.add_slot_feasigns(uint64_feasigns, fea_num + 2);
        }

        for (int j = 0; j < pos; j++) {
            std::string line_id = ins_id;
            line_id.append("-pos-");
            line_id.append(std::to_string(j));
            int show = 1;
            int click = 1;
            
            if (tags.find("MASTER") == tags.npos) {
                show = 0;
                click = 0;
            }
            uint64_feasigns[show_pos].clear();
            uint64_feasigns[click_pos].clear();
            uint64_feasigns[show_pos].push_back(show);
            uint64_feasigns[click_pos].push_back(click);
            
            SlotRecord rec = vec[cur++];
            rec->ins_id_ = ins_id;
            rec->slot_float_feasigns_.add_slot_feasigns(float_feasigns, dense_vec_fea.size() + 1);
            rec->slot_uint64_feasigns_.add_slot_feasigns(uint64_feasigns, fea_num + 2);
        }
        return true;
    }

    int get_bodylen(char *buf) {
        int value = 0;
        for (int i = 3; i >= 0; --i) {
            *(((char*) &value) + i) = buf[3 - i];
        }
        return value;
    }
    
    std::vector<std::string> labels = {"ua:6", "ua:15", "ua:16", "ua:107"};
    std::unordered_map<int, int> slot_map;
    std::vector<AllSlotInfo> slot_info;
    int show_pos;
    int click_pos;
    int realfr_pos;
    int readlist_pos;
    int ins_tag_pos;
    int lowthred_label_pos;
    int highthred_label_pos;
    int vi_tag_pos;
    int inactive_tag_pos;
    int active_tag_pos;
    int va_tag_pos;
    int uint64_slot_num_ = 0;
    int float_slot_num_ = 0;
};

}
}

extern "C" {
paddle::framework::CustomParser *CreateParserObject() {
    return new paddle::framework::HaokanFRParser();
}
}
