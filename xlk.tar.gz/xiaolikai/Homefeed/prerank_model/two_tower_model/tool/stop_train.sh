ps aux|grep trainer_online|awk '{print $2}'| xargs kill -9
