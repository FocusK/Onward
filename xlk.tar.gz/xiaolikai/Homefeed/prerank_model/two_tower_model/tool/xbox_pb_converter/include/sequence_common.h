#ifndef BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_SEQUENCE_COMMON_H
#define BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_SEQUENCE_COMMON_H

namespace abacus {
namespace xbox_pb_converter {
static const int MAX_HEADER_LEN = 10240;  // simple sequence file header size < 10240 bytes
static const int SYNC_HASH_SIZE = 16;
static const int VERSION_WITH_METADATA = 6;  // the maximum version of sequence file
static const int SYNC_INTERVAL = 100;  // sync every 100 bytes
static const int SYNC_ESCAPE = -1;  // the sync escape
extern char* SEQ_KEY_CLASS_NAME;
extern char* SEQ_VALUE_CLASS_NAME;
extern char* SEQ_VERSION;
}
}
#endif //BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_SEQUENCE_COMMON_H
