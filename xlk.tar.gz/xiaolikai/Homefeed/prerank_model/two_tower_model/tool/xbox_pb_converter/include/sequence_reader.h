#ifndef BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_SEQUENCE_READER_H
#define BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_SEQUENCE_READER_H

#include <stddef.h>
#include <string>

#include "sequence_common.h"

namespace abacus {
namespace xbox_pb_converter {
class SeqReader {
public:
    explicit SeqReader(FILE* fp);
    ~SeqReader();
    void init();
    // Read record, return false if no more record
    bool read_record(std::string& key, std::string& value);

private:
    void read_head();
    void read_seq_file_version();
    void read_key_value_class_name();
    void read_compress_info();
    void read_meta_data();
    void read_sync();
    void read_head_sync();
    void read_string(int len, std::string& str);
    int read_vint();
    int decode_vint_size(char value);
    bool is_negative_vint(char value);
    bool read_int(int* n);

private:
    int _records_read_after_sync;
    char _sync_for_head[SYNC_HASH_SIZE];
    char _sync[SYNC_HASH_SIZE];
    FILE* _fp;  // the really local file
};

}
}
#endif //BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_SEQUENCE_READER_H
