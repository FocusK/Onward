#ifndef BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_SEQUENCE_WRITER_H
#define BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_SEQUENCE_WRITER_H

#include <stddef.h>
#include <string>

#include "sequence_common.h"

namespace abacus {
namespace xbox_pb_converter {
class SeqWriter {
public:
    explicit SeqWriter(FILE* fp);

    ~SeqWriter();

    // Init will write sequence file header
    void init();

    // Write record
    void write_record(const std::string& key, const std::string& value);

private:
    void generate_sync();

    void write_header();

    void write(const char* addr, int len);

    int write_seq_file_version(char* addr);

    int write_vlong(char* buf, int64_t i);

    int write_key_value_class_name(char* addr);

    int write_compress_info(char* addr);

    int write_meta_data(char* addr);

    int write_sync(char* addr);

    // used when write record
    int write_sync_to_buf(char* addr);

    int write_int(char* buf, int i);

private:
    static const int SYNC_HASH_SIZE = 16;
    char _sync[SYNC_HASH_SIZE];
    FILE* _fp;  // the really local file
    int _version;
    std::string _key_class_name;
    std::string _value_class_name;

    int64_t _records_written_after_sync;
};
}
}
#endif //BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_SEQUENCE_WRITER_H
