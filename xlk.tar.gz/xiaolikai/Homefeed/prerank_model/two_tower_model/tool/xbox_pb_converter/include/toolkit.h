#ifndef BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_TOOLKIT_H
#define BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_TOOLKIT_H
#include <stdint.h>

#include <vector>

namespace abacus {
namespace xbox_pb_converter {
bool cstr_to_int(const char* pc, int* pi_result);
bool cstr_to_int64(const char* pc, int64_t* pll_result);
void split_string(char* src, char chr, std::vector<char*>& split_result);
bool convert_num(const char* str, int32_t& n);
bool convert_num(const char* str, int64_t& n);
}
}
#endif //BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_TOOLKIT_H
