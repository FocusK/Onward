#ifndef BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_XBOX_PB_CONVERTER_H
#define BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_XBOX_PB_CONVERTER_H

#include <string>

#include "glog/logging.h"

#include "proto/miomf_result.pb.h"
#include "sequence_writer.h"

namespace abacus {
namespace xbox_pb_converter {

static const size_t MAX_LINE_SIZE = 2048;
class XboxPbConverter {
public:
    XboxPbConverter(FILE* fp_in, FILE* fp_out) {
        CHECK_NOTNULL(_fp_in = fp_in);
        CHECK_NOTNULL(fp_out);
        CHECK_NOTNULL(_seq_writer = new SeqWriter(fp_out));
        _seq_writer->init();
    }
    ~XboxPbConverter() {
        _fp_in = NULL;
        delete _seq_writer;
        _seq_writer = NULL;
    }
    void convert();

private:
    void convert_line(char* line_buf, std::string& key, abacus::xbox::MioMFResult& mio_pb);
private:

    FILE* _fp_in;
    SeqWriter* _seq_writer;
};
}
}
#endif //BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_XBOX_PB_CONVERTER_H 
