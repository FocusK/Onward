#ifndef BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_XBOX_PB_DECONVERTER_H
#define BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_XBOX_PB_DECONVERTER_H

#include <string>

#include "glog/logging.h"

#include "proto/miomf_result.pb.h"
#include "sequence_reader.h"

namespace abacus {
namespace xbox_pb_converter {

class XboxPbDeconverter {
public:
    XboxPbDeconverter(FILE* fp_in, FILE* fp_out) {
        CHECK_NOTNULL(fp_in);
        CHECK_NOTNULL(_fp_out = fp_out);
        CHECK_NOTNULL(_seq_reader = new SeqReader(fp_in));
        _seq_reader->init();
    }
    ~XboxPbDeconverter() {
        _fp_out = NULL;
        delete _seq_reader;
        _seq_reader = NULL;
    }
    void deconvert();

private:
    FILE* _fp_out;
    SeqReader* _seq_reader;
};

}
}
#endif //BAIDU_FCR_MODEL_ABACUS_CONVERTER_XBOX_PB_CONVERTER_INCLUDE_XBOX_PB_DECONVERTER_H
