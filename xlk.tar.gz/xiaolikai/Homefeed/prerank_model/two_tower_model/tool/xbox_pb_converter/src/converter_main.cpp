#include "xbox_pb_converter.h"

int main() {
    abacus::xbox_pb_converter::XboxPbConverter converter(stdin, stdout);
    converter.convert();

    return 0;
}
