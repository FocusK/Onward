#include "xbox_pb_deconverter.h"

int main() {
    abacus::xbox_pb_converter::XboxPbDeconverter deconverter(stdin, stdout);
    deconverter.deconvert();

    return 0;
}
