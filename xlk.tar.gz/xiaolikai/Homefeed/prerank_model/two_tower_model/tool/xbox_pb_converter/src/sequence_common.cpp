#include "sequence_common.h"
namespace abacus {
namespace xbox_pb_converter {
char* SEQ_KEY_CLASS_NAME = "org.apache.hadoop.io.BytesWritable";
char* SEQ_VALUE_CLASS_NAME = "org.apache.hadoop.io.BytesWritable";
char* SEQ_VERSION = "SEQ";
}
}
