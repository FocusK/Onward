#include <netinet/in.h>
#include <string.h>

#include "glog/logging.h"
#include "sequence_reader.h"
#include <boost/scoped_array.hpp> 

namespace abacus {
namespace xbox_pb_converter {
SeqReader::SeqReader(FILE* fp) : _records_read_after_sync(0), _fp(fp) {
    CHECK(_fp != NULL);
}

SeqReader::~SeqReader() {
    _fp = NULL;
}

void SeqReader::init() {
    read_head();
}

bool SeqReader::read_record(std::string& key, std::string& value) {
    if (_records_read_after_sync >= SYNC_INTERVAL) {
        int n = 0;
        if (!read_int(&n)) {
            return false;
        }
        CHECK(n == SYNC_ESCAPE);
        read_sync();
        _records_read_after_sync = 0;
    }
    int record_len = 0;
    int key_len = 0;
    if (!read_int(&record_len)) {
        return false;
    }
    CHECK(read_int(&key_len));
    int value_len = record_len - key_len;
    read_string(key_len, key);
    read_string(value_len, value);
    ++_records_read_after_sync;

    return true;
}

void SeqReader::read_head() {
    read_seq_file_version();
    read_key_value_class_name();
    read_compress_info();
    read_meta_data();
    read_head_sync();
}

void SeqReader::read_seq_file_version() {
    char buf[4];
    CHECK(fread(buf, 1, 4, _fp) == 4);
    CHECK(buf[0] == SEQ_VERSION[0] &&
            buf[1] == SEQ_VERSION[1] &&
            buf[2] == SEQ_VERSION[2] &&
            buf[3] == VERSION_WITH_METADATA);
}

void SeqReader::read_key_value_class_name() {
    int key_class_len = read_vint();
    std::string key_class_name;
    read_string(key_class_len, key_class_name);
    CHECK(key_class_name == SEQ_KEY_CLASS_NAME);
    int value_class_len = read_vint();
    std::string value_class_name;
    read_string(value_class_len, value_class_name);
    CHECK(value_class_name == SEQ_VALUE_CLASS_NAME);
}

void SeqReader::read_compress_info() {
    char bytes[2];
    CHECK(fread(bytes, 1, 2, _fp) == 2 &&
            bytes[0] == '\0' &&
            bytes[1] == '\0');
}

void SeqReader::read_meta_data() {
    int n = 0;
    CHECK(fread(&n, 1, sizeof(n), _fp) == sizeof(n) && n == 0);
}

void SeqReader::read_head_sync() {
    CHECK(fread(_sync_for_head, 1, sizeof(_sync), _fp) == sizeof(_sync_for_head));
}

void SeqReader::read_sync() {
    CHECK(fread(_sync, 1, sizeof(_sync), _fp) == sizeof(_sync));
    CHECK(memcmp(_sync, _sync_for_head, sizeof(_sync)) == 0);
}

void SeqReader::read_string(int len, std::string& str) {
    boost::scoped_array<char> data(new char[len]);
    char* ptr = data.get();
    CHECK(int(fread(ptr, 1, len, _fp)) == len);
    str.assign(ptr, len);
}

int SeqReader::read_vint() {
    char first_byte = '\0';
    CHECK(fread(&first_byte, 1, 1, _fp) == 1);
    int len = decode_vint_size(first_byte);
    if (len == 1) {
        return static_cast<int>(first_byte);
    }
    boost::scoped_array<char> data(new char[len - 1]);
    char* ptr = data.get();
    CHECK(int(fread(ptr, 1, len - 1, _fp)) == len - 1);
    int64_t n = 0;
    for (int i = 0; i < len - 1; ++i) {
        char b = data[i];
        n = n << 8;
        n = n | (b & 0xFF);
    }

    return static_cast<unsigned>((is_negative_vint(first_byte) ? (n ^ -1L) : n));
}

int SeqReader::decode_vint_size(char value) {
    if (value >= -112) {
        return 1;
    } else if (value < -120) {
        return -119 - value;
    }
    return -111 - value;
}

bool SeqReader::is_negative_vint(char value) {
    return value < -120 || (value >= -112 && value < 0);
}

bool SeqReader::read_int(int* n) {
    int net_int = 0;
    int readn = fread(&net_int, sizeof(net_int), 1, _fp);
    if (readn <= 0) {
        CHECK(feof(_fp));
        return false;
    }
    CHECK(readn == 1);
    *n = ntohl(net_int);
    return true;
}

}
}
