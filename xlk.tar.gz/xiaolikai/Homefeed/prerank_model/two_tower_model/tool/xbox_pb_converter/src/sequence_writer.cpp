#include <netinet/in.h>
#include <sys/time.h>
#include <string.h>

#include "glog/logging.h"
#include "sequence_writer.h"
#include <boost/scoped_array.hpp> 

namespace abacus {
namespace xbox_pb_converter {
int64_t get_timestamp_ms() {
    struct timeval tv; 
    CHECK(gettimeofday(&tv, NULL) == 0);
    int64_t result = tv.tv_sec;
    result *= 1000000;
    result += tv.tv_usec;
    return result / 1000;
}

SeqWriter::SeqWriter(FILE* fp)
    : _fp(fp),
    _records_written_after_sync(0) {
    CHECK(fp != NULL);
}

SeqWriter::~SeqWriter() {
    _fp = NULL;
}

void SeqWriter::init() {
    // generate sync first
    generate_sync();

    // write header: sequence file version, compression info, etc..
    write_header();
}

void SeqWriter::write_record(const std::string& key, const std::string& value) {
    int record_size = key.size() + value.size();
    int key_len = key.size();
    int int_len = sizeof(int);
    int size = 2 * int_len + record_size;
    int used_bytes = 0;
    boost::scoped_array<char> data(new char[size]);

    if (_records_written_after_sync >= SYNC_INTERVAL) {
        size += int_len + SYNC_HASH_SIZE;
        data.reset(new char[size]);
        used_bytes += write_sync_to_buf(data.get() + used_bytes);
        _records_written_after_sync = 0;
    }

    // format:
    // record_size|key_len|key|value

    used_bytes += write_int(data.get() + used_bytes, record_size);
    used_bytes += write_int(data.get() + used_bytes, key_len);

    memcpy(data.get() + used_bytes, key.data(), key_len);
    used_bytes += key_len;
    memcpy(data.get() + used_bytes, value.data(), value.size());
    used_bytes += value.size();

    CHECK(used_bytes == size);

    write(data.get(), used_bytes);

    ++_records_written_after_sync;
}

void SeqWriter::write(const char* addr, int len) {
    int writed_byted = fwrite(addr, 1, len, _fp);
    CHECK(writed_byted == len);

    CHECK(fflush(_fp) == 0);
}

int SeqWriter::write_sync_to_buf(char* buf) {
    int used_bytes = write_int(buf, SYNC_ESCAPE);
    used_bytes += write_sync(buf + used_bytes);
    return used_bytes;
}

int SeqWriter::write_int(char* buf, int i) {
    int net_int = htonl(i);
    memcpy(buf, reinterpret_cast<char*>(&net_int), sizeof(net_int));
    return sizeof(net_int);
}

void SeqWriter::generate_sync() {
    unsigned seed = get_timestamp_ms() + getpid();
    for (int i = 0; i < SYNC_HASH_SIZE; ++i) {
        _sync[i] = static_cast<char>(rand_r(&seed) % 256);
    }
}

void SeqWriter::write_header() {
    boost::scoped_array<char> header(new char[MAX_HEADER_LEN]);
    int used_bytes = 0;
    used_bytes += write_seq_file_version(header.get());
    used_bytes += write_key_value_class_name(header.get() + used_bytes);
    used_bytes += write_compress_info(header.get() + used_bytes);
    used_bytes += write_meta_data(header.get() + used_bytes);
    used_bytes += write_sync(header.get() + used_bytes);
    CHECK_LE(used_bytes, MAX_HEADER_LEN);
    write(header.get(), used_bytes);
}

int SeqWriter::write_seq_file_version(char* addr) {
    addr[0] = SEQ_VERSION[0];
    addr[1] = SEQ_VERSION[1];
    addr[2] = SEQ_VERSION[2];
    addr[3] = VERSION_WITH_METADATA;
    _version = VERSION_WITH_METADATA;
    return 4;
}

int SeqWriter::write_vlong(char* buf, int64_t i) {
    int used_bytes = 0;
    if (i >= -112 && i <= 127) {
        buf[used_bytes] = static_cast<char>(i);
        ++used_bytes;
        return used_bytes;
    }

    int len = -112;
    if (i < 0) {
        i ^= -1L; // take one's complement'
        len = -120;
    }

    int64_t tmp = i;
    while (tmp != 0) {
        tmp = tmp >> 8;
        len--;
    }

    buf[used_bytes] = static_cast<char>(len);
    ++used_bytes;

    len = (len < -120) ? -(len + 120) : -(len + 112);

    for (int idx = len; idx != 0; idx--) {
        int shiftbits = (idx - 1) * 8;
        int64_t mask = 0xFFL << shiftbits;
        char c = (static_cast<char>((i & mask) >> shiftbits));
        buf[used_bytes] = c;
        ++used_bytes;
    }
    return used_bytes;
}

int SeqWriter::write_key_value_class_name(char* addr) {
    int key_class_name_len = strlen(SEQ_KEY_CLASS_NAME);
    int value_class_name_len = strlen(SEQ_VALUE_CLASS_NAME);

    int used_bytes = write_vlong(addr, key_class_name_len);
    memcpy(addr + used_bytes, SEQ_KEY_CLASS_NAME, key_class_name_len);
    used_bytes += key_class_name_len;

    used_bytes += write_vlong(addr + used_bytes, value_class_name_len);
    memcpy(addr + used_bytes, SEQ_VALUE_CLASS_NAME, value_class_name_len);
    used_bytes += value_class_name_len;

    _key_class_name = std::string(SEQ_KEY_CLASS_NAME);
    _value_class_name = std::string(SEQ_VALUE_CLASS_NAME);
    return used_bytes;
}

int SeqWriter::write_compress_info(char* addr) {
    // no need decompress
    addr[0] = '\0';

    // no need block decompress
    addr[1] = '\0';

    return 2;
}

int SeqWriter::write_meta_data(char* addr) {
    // meta data num is 0
    *reinterpret_cast<int*>(addr) = 0;
    return 4;  // sizeof(int)
}

int SeqWriter::write_sync(char* addr) {
    memcpy(addr, _sync, SYNC_HASH_SIZE);
    return SYNC_HASH_SIZE;
}
}
}
