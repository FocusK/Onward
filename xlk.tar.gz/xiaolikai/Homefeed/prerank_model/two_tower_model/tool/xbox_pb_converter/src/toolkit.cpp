#include <errno.h>
#include <stdlib.h>
#include <string.h>

#include "glog/logging.h"

namespace abacus {
namespace xbox_pb_converter {

bool cstr_to_int(const char* pc, int* pi_result)
{
    if (pc == NULL || pi_result == NULL) {
        return false;
    }   

    if (*pc == '\0') {
        return false;
    }   

    char* pc_end = NULL;

    int i_tmp_errno = errno;
    *pi_result = strtol(pc, &pc_end, 10);
    if (*pc_end != '\0' || errno == ERANGE) {
        errno = i_tmp_errno;
        return false;
    }   

    return true;
}

bool cstr_to_int64(const char* pc, int64_t* pll_result)
{
    if (pc == NULL || pll_result == NULL) {
        return false;
    }

    if (*pc == '\0') {
        return false;
    }

    char* pc_end = NULL;

    int i_tmp_errno = errno;
    *pll_result = strtoll(pc, &pc_end, 10);
    if (*pc_end != '\0' || errno == ERANGE) {
        errno = i_tmp_errno;
        return false;
    }

    return true;
}

void convert_num(const char* str, int32_t& n) {
    if (*str == 0) {
        n = 0;
        return;
    }
    CHECK(cstr_to_int(str, &n));
};
void convert_num(const char* str, int64_t& n) {
    if (*str == 0) {
        n = 0;
        return;
    }
    CHECK(cstr_to_int64(str, &n));
};

void split_string(char* src, char chr, std::vector<char*>& split_result) {
    split_result.clear();
    if (src == NULL) {
        return;
    }
    char* ptab = src;
    if (*ptab != 0) {
        split_result.push_back(ptab);
    }   
    ptab = strchr(ptab, chr);
    while (ptab != NULL) {
        *ptab++ = '\0';
        split_result.push_back(ptab);
        ptab = strchr(ptab, chr);
    }
}
}
}

// vim: set ts=4 sw=4 sts=4 tw=100 
