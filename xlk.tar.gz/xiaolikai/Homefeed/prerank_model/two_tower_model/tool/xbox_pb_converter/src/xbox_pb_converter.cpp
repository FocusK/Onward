#include "toolkit.h"

#include "xbox_pb_converter.h"

namespace abacus {
namespace xbox_pb_converter {
void XboxPbConverter::convert() {
    size_t buf_len = MAX_LINE_SIZE;
    char* line_buf = NULL;
    CHECK_NOTNULL(line_buf = (char*)malloc(buf_len + 1));
    std::string key;
    std::string value;
    abacus::xbox::MioMFResult mio_pb;
    int read_count = 0;
    while ((read_count = getline(&line_buf, &buf_len, _fp_in)) > 0) {
        line_buf[read_count - 1] = '\0';
        convert_line(line_buf, key, mio_pb);
        mio_pb.SerializeToString(&value);
        _seq_writer->write_record(key, value);
    }
    free(line_buf);
}

void XboxPbConverter::convert_line(char* line_buf, std::string& key, 
        abacus::xbox::MioMFResult& mio_pb) {
    static std::vector<char*> split_ret;
    split_string(line_buf, '\t', split_ret);
    CHECK(split_ret.size() >= 7) << "[" << split_ret.size() << "][" 
        <<  split_ret[0] << "]";
    mio_pb.Clear();
    uint64_t nkey = strtoull(split_ret[0], NULL, 10);
    key.assign((char*)&nkey, sizeof(nkey));
    int32_t n32 = 0;
    int64_t n64 = 0;
    convert_num(split_ret[1], n64);
    if (n64 != 0) {
        mio_pb.set_show(n64);
    }

    convert_num(split_ret[2], n64);
    if (n64 != 0) {
        mio_pb.set_click(n64);
    }

    convert_num(split_ret[3], n32);
    if (n32 != 0) {
        mio_pb.set_pred(n32);
    }
    convert_num(split_ret[4], n32);
    if (n32 != 0) {
        mio_pb.set_weight_lr_person(n32);
    }
    if (*split_ret[5] != '[') {
        for (size_t i = 5; i < split_ret.size(); ++i) {
            convert_num(split_ret[i], n32);
            mio_pb.add_weight_mf(n32);
        }
    }
}

}
}
