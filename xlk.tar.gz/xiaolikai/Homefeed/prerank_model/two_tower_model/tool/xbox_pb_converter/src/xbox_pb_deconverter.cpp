#include "toolkit.h"

#include "xbox_pb_deconverter.h"

namespace abacus {
namespace xbox_pb_converter {
void XboxPbDeconverter::deconvert() {
    std::string key;
    std::string value;
    abacus::xbox::MioMFResult mio_pb;
    while (_seq_reader->read_record(key, value)) {
        mio_pb.ParseFromString(value);
        // uint64_t* nkey = reinterpret_cast<uint64_t*>(const_cast<char*>(key.c_str()));
        uint64_t* nkey = (uint64_t*)(key.c_str());
        CHECK(fprintf(_fp_out, "%llu\t", *nkey) > 0);
        if (mio_pb.has_show() && mio_pb.show() != 0) {
            CHECK(fprintf(_fp_out, "%lld", mio_pb.show()) > 0);
        }
        CHECK(fprintf(_fp_out, "\t") > 0);

        if (mio_pb.has_click() && mio_pb.click() != 0) {
            CHECK(fprintf(_fp_out, "%lld", mio_pb.click()) > 0);
        }
        CHECK(fprintf(_fp_out, "\t") > 0);

        if (mio_pb.has_pred() && mio_pb.pred() != 0) {
            CHECK(fprintf(_fp_out, "%d", mio_pb.pred()) > 0);
        }
        CHECK(fprintf(_fp_out, "\t") > 0);

        if (mio_pb.has_weight_lr_person() && mio_pb.weight_lr_person() != 0) {
            CHECK(fprintf(_fp_out, "%d", mio_pb.weight_lr_person()) > 0);
        }

        size_t mf_count = mio_pb.weight_mf_size();
        if (mf_count != 0) {
            for (size_t i = 0; i < mf_count; ++i) {
                CHECK(fprintf(_fp_out, "\t%d", mio_pb.weight_mf(i)) > 0);
            }
        } else {
            CHECK(fprintf(_fp_out, "\t[\t]") > 0);
        }
        CHECK(fprintf(_fp_out, "\n") > 0);
    }
    CHECK(fflush(_fp_out) == 0);
}

}
}
