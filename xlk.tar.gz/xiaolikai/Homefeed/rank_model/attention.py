
class Model(object):

    def __init__(self, all_slot, cross_slot_pair, cross_slot_set, comb_slot, use_cvm, step, scale_sparse_grad_with_batch=True):
        self._use_cvm = use_cvm
        self._step = step
        self._dict_dim = 10 # it's fake
        self._emb_dim = 9 + 2
        self._fc_layers_size = [1023, 255, 127, 127, 127, 1]
        self._init_range = 0.2
        self._batch_size = 32
        self._embedding_name = "embedding"
        self._embedding_comb_name = "embedding"
        self.need_rnn_slot = []
        self.slot_embed_name_suffix = "_embed"

        self._scale_sparse_grad_with_batch = scale_sparse_grad_with_batch

        self._train_program = fluid.Program()
        self._startup_program = fluid.Program()
        self.cross_slot_pair = cross_slot_pair
        self.cross_slot_set = cross_slot_set
        self.comb_slot = comb_slot

        # Atetntion settings
        self.attention_slot_file = "slot_at/attention_slot"
        self.attention_slots_name = []
        if self.attention_slot_file != '':
            for line in open(self.attention_slot_file, 'r'):
                self.attention_slots_name.append(line.strip())
        self.n_layer = 6
        self.n_head = 6
        self.d_key = 16
        self.d_value = 16
        self.d_model = 11
        self.d_inner_hid = 4096


        with fluid.program_guard(self._train_program, self._startup_program):
            with fluid.unique_name.guard():
                self.show = fluid.layers.data(name="show", shape=[-1, 1], dtype="int64", lod_level=0, append_batch_size=False)
                self.label = fluid.layers.data(name="click", shape=[-1, 1], dtype="int64", lod_level=0, append_batch_size=False)
                self.ins_weight = fluid.layers.data(
                         name="ins_weight",
                         shape=[-1, 1],
                         dtype="float32",
                         lod_level=1,
                         append_batch_size=False,
                         stop_gradient=True)
                self.cast_label = fluid.layers.cast(x=self.label, dtype='float32')
                self.cast_label.stop_gradient = True

                self.slots = []
                self.embs = {}
                self.slot_data = {}
                self.all_slots_name = all_slot
                for i_slot in all_slot:
                    self.slots.append(fluid.layers.data(name=i_slot, shape=[1], dtype="int64", lod_level=1))
                    emb = fluid.layers.embedding(input=self.slots[-1], size=[self._dict_dim, self._emb_dim], is_sparse = True, is_distributed=True, param_attr=fluid.ParamAttr(name=self._embedding_name)) 
                    self.embs[i_slot] = emb
                    self.slot_data[i_slot] = self.slots[-1]
                self._base_net()

    def deep_net(self, concat, slot_cnt, lr_x=1.0):
        slot_dim = self._emb_dim
        if not self._use_cvm:
            slot_dim = self._emb_dim - 2
        fc_layers_input = [concat]
        fc_layers_size = self._fc_layers_size
        fc_layers_act = ["relu"] * (len(fc_layers_size) - 1) + [None]
        scales_tmp = [concat.shape[1]] + fc_layers_size
        scales = []
        for i in range(len(scales_tmp)):
            scales.append(self._init_range / (scales_tmp[i] ** 0.5))


        for i in range(len(fc_layers_size)):
            fc = fluid.layers.fc(
                    input = fc_layers_input[-1],
                    size = fc_layers_size[i],
                    act = fc_layers_act[i],
                    param_attr = \
                        fluid.ParamAttr(learning_rate=lr_x, \
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=1.0 * scales[i])),
                    bias_attr = \
                        fluid.ParamAttr(learning_rate=lr_x, \
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=1.0 * scales[i])))


            fc_layers_input.append(fc)

        return fc_layers_input[-1]

    
    def multi_head_attention(self, emb_nid, emb):
        """
        Input:
            emb_nid: [-1, 9] 候选资源id
            emb: [-1, 9] 行为序列id
        """
        q = fluid.layers.fc(input=emb_nid, size=self.d_key * self.n_head, bias_attr=False) # (-1 16*6)
        k = fluid.layers.fc(input=emb, size=self.d_key * self.n_head, bias_attr=False) # (-1 16*6)
        v = fluid.layers.fc(input=emb, size=self.d_value * self.n_head, bias_attr=False) # (-1 16*6)
        reshaped_q = fluid.layers.reshape(x=q, shape=[0, self.n_head, self.d_key], inplace=True) #(-1, 6 16)
        q = fluid.layers.transpose(x=reshaped_q, perm=[1,0,2]) # (6 -1 16)
        reshaped_k = fluid.layers.reshape(x=k, shape=[0, self.n_head, self.d_key], inplace=True) # (-1 6 16)
        k = fluid.layers.transpose(x=reshaped_k, perm=[1,0,2]) # (6 -1 16)
        reshaped_v = fluid.layers.reshape(x=v, shape=[0, self.n_head, self.d_key], inplace=True)
        v = fluid.layers.transpose(x=reshaped_v, perm=[1,0,2]) # (6 -1 16)
        # product attention
        product = fluid.layers.matmul(x=q, y=k, transpose_y=True, alpha=self.d_model**-0.5) #(6 -1 -1), -1 = batchsize * max_seq_len
        product = fluid.layers.reshape(x=product, shape=[0,0,-1,10], inplace=False) # (6 -1 batch max_seq_len)
        weights = fluid.layers.softmax(product) 
        weights = fluid.layers.reshape(x=weights, shape=[0,0,-1], inplace=False) # (6 -1 batch*max_seq_len)
        attention_v = fluid.layers.matmul(weights, v) # (6 -1 -1) * (6 -1 16) = (6 -1 16)
        #fluid.layers.Print(attention_v)
        attention_v_1 = fluid.layers.transpose(attention_v, perm=[1,0,2])  # (-1 6 16)
        attention_v_2 = fluid.layers.reshape(x=attention_v_1, shape=[0, attention_v_1.shape[1]*attention_v_1.shape[2]]) # (-1 96)
        attention_final = fluid.layers.fc(input=attention_v_2, size=self._emb_dim)
        emb = fluid.layers.lod_reset(attention_final, emb_nid)
        #fluid.layers.Print(attention_final)
        return emb


    def create_user_net(self, lr_x=1.0):

        slot_dim = self._emb_dim
        input_data = []
        rnn_input = []
        bows = []
        cross_embs_dict = {}
        emb_nid = self.embs.get("5889", None)
        emb_nid = fluid.layers.continuous_value_model(emb_nid, self.show_clk, self._use_cvm)
        #fluid.layers.Print(emb_nid)
        #print(emb_nid)
        for i in self.all_slots_name:
            emb = self.embs[i]
            if i in self.attention_slots_name:
                #fluid.layers.Print(emb)
                bow = fluid.layers.continuous_value_model(emb, self.show_clk, self._use_cvm) 
                #fluid.layers.Print(bow)
                emb_with_cvm = self.multi_head_attention(emb_nid, bow) 
            else:
                bow = fluid.layers.sequence_pool(input=emb, pool_type='sum')
                emb_with_cvm = fluid.layers.continuous_value_model(bow, self.show_clk, self._use_cvm)
            bows.append(emb_with_cvm)
        #bows.append(comb)
        concat = fluid.layers.concat(bows, axis=1)
        bn = concat
        if self._use_cvm:
            bn = fluid.layers.data_norm(input=concat, name="bn", epsilon=1e-4,
                param_attr={
                    "batch_size":1e4,
                    "batch_sum_default":0.0,
                    "batch_square":1e4})

        user_fc = self.deep_net(bn, len(self.slots), lr_x)
        return user_fc

    def _base_net(self):
        """
        example net
        """
        ones = fluid.layers.fill_constant_batch_size_like(input=self.cast_label, shape=[-1, 1], dtype="float32", value=1)
        #fluid.layers.Print(ones)
        #ones_shape = fluid.layers.shape(ones)
        #fluid.layers.Print(ones_shape)
        #ones_1 = fluid.layers.fill_constant(shape=[ones_shape[0],ones.shape[1]],dtype="int64", value=1)
        #fluid.layers.Print(ones_1)
        self.show_clk = fluid.layers.cast(fluid.layers.concat([ones, self.cast_label], axis=1), dtype='float32')
        self.show_clk.stop_gradient = True
        self.usr_embedded = self.create_user_net()
        prob = fluid.layers.sigmoid(fluid.layers.clip(self.usr_embedded, min=-15.0, max=15.0), name="similarity_norm")
        cost = fluid.layers.log_loss(input=prob, label=fluid.layers.cast(x=self.cast_label, dtype='float32'))
        #cost = fluid.layers.elementwise_mul(cost, ins_weight)
        self.avg_cost = fluid.layers.mean(x=cost)
        binary_predict = fluid.layers.concat(
                input=[fluid.layers.elementwise_sub(fluid.layers.ceil(prob), prob), prob], axis=1)
        self.auc, self.batch_auc, self.auc_stat_list = \
            fluid.layers.auc(input=binary_predict, label=self.label,curve='ROC', num_thresholds=4096)
        self.metric_list = fluid.contrib.layers.ctr_metric_bundle(prob, fluid.layers.cast(x=self.label, dtype='float32'))
DIN attention
参考论文：https://dl.acm.org/doi/abs/10.1145/3219819.3219823
序列特征与当前nid以及做element-wise加和乘的结果concat到一起过MLP生成attention，作用到原始序列上
参考din_attention这个函数，输入为nid embedding和序列特征embeddings。join update阶段输入不同embedding维度。
组网示例
din attention组网示例
import paddle.fluid as fluid

class Model(object):

    def __init__(self, all_slot, cross_slot_pair, cross_slot_set, comb_slot, use_cvm, step, scale_sparse_grad_with_batch=True):
        self._use_cvm = use_cvm
        self._step = step
        self._dict_dim = 10 # it's fake
        self._emb_dim = 9 + 2
        self._fc_layers_size = [1023, 255, 127, 127, 127, 1]
        self._init_range = 0.2
        self._batch_size = 32
        self._embedding_name = "embedding"
        self._embedding_comb_name = "embedding"
        self.need_rnn_slot = []
        self.slot_embed_name_suffix = "_embed"

        self._scale_sparse_grad_with_batch = scale_sparse_grad_with_batch

        self._train_program = fluid.Program()
        self._startup_program = fluid.Program()
        self.cross_slot_pair = cross_slot_pair
        self.cross_slot_set = cross_slot_set
        self.comb_slot = comb_slot

        # Atetntion settings
        self.attention_slot_file = "slot_at/attention_slot"
        self.attention_slots_name = []
        if self.attention_slot_file != '':
            for line in open(self.attention_slot_file, 'r'):
                self.attention_slots_name.append(line.strip())
        self.n_layer = 6
        self.n_head = 6
        self.d_key = 16
        self.d_value = 16
        self.d_model = 11
        self.d_inner_hid = 4096


        with fluid.program_guard(self._train_program, self._startup_program):
            with fluid.unique_name.guard():
                self.show = fluid.layers.data(name="show", shape=[-1, 1], dtype="int64", lod_level=0, append_batch_size=False)
                self.label = fluid.layers.data(name="click", shape=[-1, 1], dtype="int64", lod_level=0, append_batch_size=False)
                self.ins_weight = fluid.layers.data(
                         name="ins_weight",
                         shape=[-1, 1],
                         dtype="float32",
                         lod_level=1,
                         append_batch_size=False,
                         stop_gradient=True)
                self.cast_label = fluid.layers.cast(x=self.label, dtype='float32')
                self.cast_label.stop_gradient = True

                self.slots = []
                self.embs = {}
                self.slot_data = {}
                self.all_slots_name = all_slot
                for i_slot in all_slot:
                    self.slots.append(fluid.layers.data(name=i_slot, shape=[1], dtype="int64", lod_level=1))
                    emb = fluid.layers.embedding(input=self.slots[-1], size=[self._dict_dim, self._emb_dim], is_sparse = True, is_distributed=True, param_attr=fluid.ParamAttr(name=self._embedding_name)) 
                    self.embs[i_slot] = emb
                    self.slot_data[i_slot] = self.slots[-1]
                self._base_net()

    def deep_net(self, concat, slot_cnt, lr_x=1.0):
        slot_dim = self._emb_dim
        if not self._use_cvm:
            slot_dim = self._emb_dim - 2
        fc_layers_input = [concat]
        fc_layers_size = self._fc_layers_size
        fc_layers_act = ["relu"] * (len(fc_layers_size) - 1) + [None]
        scales_tmp = [concat.shape[1]] + fc_layers_size
        scales = []
        for i in range(len(scales_tmp)):
            scales.append(self._init_range / (scales_tmp[i] ** 0.5))


        for i in range(len(fc_layers_size)):
            fc = fluid.layers.fc(
                    input = fc_layers_input[-1],
                    size = fc_layers_size[i],
                    act = fc_layers_act[i],
                    param_attr = \
                        fluid.ParamAttr(learning_rate=lr_x, \
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=1.0 * scales[i])),
                    bias_attr = \
                        fluid.ParamAttr(learning_rate=lr_x, \
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=1.0 * scales[i])))


            fc_layers_input.append(fc)

        return fc_layers_input[-1]

    
    def multi_head_attention(self, emb_nid, emb):
        q = fluid.layers.fc(input=emb_nid, size=self.d_key * self.n_head, bias_attr=False)
        #fluid.layers.Print(q)
        k = fluid.layers.fc(input=emb, size=self.d_key * self.n_head, bias_attr=False)
        v = fluid.layers.fc(input=emb, size=self.d_value * self.n_head, bias_attr=False)
        reshaped_q = fluid.layers.reshape(x=q, shape=[0, self.n_head, self.d_key], inplace=True)
        #fluid.layers.Print(reshaped_q)
        q = fluid.layers.transpose(x=reshaped_q, perm=[1,0,2])
        #fluid.layers.Print(q)
        reshaped_k = fluid.layers.reshape(x=k, shape=[0, self.n_head, self.d_key], inplace=True)
        #fluid.layers.Print(reshaped_k)
        k = fluid.layers.transpose(x=reshaped_k, perm=[1,0,2])
        reshaped_v = fluid.layers.reshape(x=v, shape=[0, self.n_head, self.d_key], inplace=True)
        #fluid.layers.Print(reshaped_v)
        v = fluid.layers.transpose(x=reshaped_v, perm=[1,0,2])
        # product attention
        product = fluid.layers.matmul(x=q, y=k, transpose_y=True, alpha=self.d_model**-0.5)
        product = fluid.layers.reshape(x=product, shape=[0,0,-1,10], inplace=False)
        weights = fluid.layers.softmax(product)
        weights = fluid.layers.reshape(x=weights, shape=[0,0,-1], inplace=False)
        attention_v = fluid.layers.matmul(weights, v)
        #fluid.layers.Print(attention_v)
        attention_v_1 = fluid.layers.transpose(attention_v, perm=[1,0,2])
        attention_v_2 = fluid.layers.reshape(x=attention_v_1, shape=[0, attention_v_1.shape[1]*attention_v_1.shape[2]])
        attention_final = fluid.layers.fc(input=attention_v_2, size=self._emb_dim)
        emb = fluid.layers.lod_reset(attention_final, emb_nid)
        #fluid.layers.Print(attention_final)
        return emb

    def din_attention(self, emb_nid, emb, len_emb):
        #fluid.layers.Print(emb_nid)
        re_emb_nid = fluid.layers.reshape(x=emb_nid, shape=[0,len_emb,1], inplace=False)
        #fluid.layers.Print(re_emb_nid)
        exp_emb_nid = fluid.layers.expand(re_emb_nid, [1,1,10])
        #fluid.layers.Print(exp_emb_nid) 
        exp_emb_nid = fluid.layers.transpose(x=exp_emb_nid, perm=[0,2,1])
        exp_emb_nid = fluid.layers.reshape(x=exp_emb_nid, shape=[-1,len_emb])
        #fluid.layers.Print(exp_emb_nid)
        exp_emb_nid = fluid.layers.lod_reset(exp_emb_nid, emb)
        #fluid.layers.Print(exp_emb_nid)
        din_all = fluid.layers.concat([exp_emb_nid, emb, exp_emb_nid - emb, exp_emb_nid * emb], axis=1)
        #fluid.layers.Print(din_all)
        din_1 = fluid.layers.fc(input=din_all, size=80, act="sigmoid")
        din_2 = fluid.layers.fc(input=din_1, size=40, act="sigmoid")
        din_3 = fluid.layers.fc(input=din_2, size=1)
        #fluid.layers.Print(din_3)
        product = fluid.layers.scale(x=din_3, scale=self.d_model**-0.5)
        product = fluid.layers.reshape(x=product, shape=[-1,10])
        weight = fluid.layers.softmax(product)
        weight = fluid.layers.reshape(x=weight, shape=[0,10,1])
        weight = fluid.layers.transpose(x=weight, perm=[0,2,1])
        re_emb = fluid.layers.reshape(x=emb, shape=[-1,10,len_emb])
        out = fluid.layers.matmul(weight, re_emb)
        out = fluid.layers.reshape(x=out, shape=[-1,len_emb])
        out = fluid.layers.lod_reset(out, emb_nid)
        #fluid.layers.Print(out)
        return out


    def create_user_net(self, lr_x=1.0):

        slot_dim = self._emb_dim
        input_data = []
        rnn_input = []
        bows = []
        cross_embs_dict = {}
        emb_nid = self.embs.get("5889", None)
        emb_nid = fluid.layers.continuous_value_model(emb_nid, self.show_clk, self._use_cvm)
        #fluid.layers.Print(emb_nid)
        #print(emb_nid)
        for i in self.all_slots_name:
            emb = self.embs[i]
            if i in self.attention_slots_name:
                #fluid.layers.Print(emb)
                if self._use_cvm:
                    bow = fluid.layers.continuous_value_model(emb, self.show_clk, self._use_cvm) 
                    emb_with_cvm = self.din_attention(emb_nid, bow, 11)
                else:
                    bow = fluid.layers.continuous_value_model(emb, self.show_clk, self._use_cvm) 
                    emb_with_cvm = self.din_attention(emb_nid, bow, 9) 
            else:
                bow = fluid.layers.sequence_pool(input=emb, pool_type='sum')
                emb_with_cvm = fluid.layers.continuous_value_model(bow, self.show_clk, self._use_cvm)
            bows.append(emb_with_cvm)
        #bows.append(comb)
        concat = fluid.layers.concat(bows, axis=1)
        bn = concat
        if self._use_cvm:
            bn = fluid.layers.data_norm(input=concat, name="bn", epsilon=1e-4,
                param_attr={
                    "batch_size":1e4,
                    "batch_sum_default":0.0,
                    "batch_square":1e4})

        user_fc = self.deep_net(bn, len(self.slots), lr_x)
        return user_fc

    def _base_net(self):
        """
        example net
        """
        ones = fluid.layers.fill_constant_batch_size_like(input=self.cast_label, shape=[-1, 1], dtype="float32", value=1)
        #fluid.layers.Print(ones)
        #ones_shape = fluid.layers.shape(ones)
        #fluid.layers.Print(ones_shape)
        #ones_1 = fluid.layers.fill_constant(shape=[ones_shape[0],ones.shape[1]],dtype="int64", value=1)
        #fluid.layers.Print(ones_1)
        self.show_clk = fluid.layers.cast(fluid.layers.concat([ones, self.cast_label], axis=1), dtype='float32')
        self.show_clk.stop_gradient = True
        self.usr_embedded = self.create_user_net()
        prob = fluid.layers.sigmoid(fluid.layers.clip(self.usr_embedded, min=-15.0, max=15.0), name="similarity_norm")
        cost = fluid.layers.log_loss(input=prob, label=fluid.layers.cast(x=self.cast_label, dtype='float32'))
        #cost = fluid.layers.elementwise_mul(cost, ins_weight)
        self.avg_cost = fluid.layers.mean(x=cost)
        binary_predict = fluid.layers.concat(
                input=[fluid.layers.elementwise_sub(fluid.layers.ceil(prob), prob), prob], axis=1)
        self.auc, self.batch_auc, self.auc_stat_list = \
            fluid.layers.auc(input=binary_predict, label=self.label,curve='ROC', num_thresholds=4096)
        self.metric_list = fluid.contrib.layers.ctr_metric_bundle(prob, fluid.layers.cast(x=self.label, dtype='float32'))
