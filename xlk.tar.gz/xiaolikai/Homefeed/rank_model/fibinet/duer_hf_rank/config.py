"""
    @module config
    @function
    @class
    @method
"""
only_update=True
use_dynamic_mf=True
dataset_type="InMemoryDataset"
batch_size=1024
thread_num=100
preload_thread=8
join_thread=8
update_thread=8
epoch_num=1
# output path afs config
fs_name="afs://pegasus.afs.baidu.com:9902"
fs_ugi="dumi_bot_rec,dumi_bot_rec_hello"
# ins_num afs config
ins_fs_name="afs://pegasus.afs.baidu.com:9902"
ins_fs_ugi="dumi_bot_rec,dumi_bot_rec_hello"
# hotstart afs config
load_model_fs_name=fs_name
load_model_fs_ugi=fs_ugi

train_data_path=["afs:/user/dumi/duer/dumi_bot_rec/homefeed_sample_dump/train_data_din"]
output_path="afs:/user/dumi/duer/dumi_bot_rec/xiaolikai/hf_models/fibinet_field_each"
slot_path="slot/all_slot.dict"

# is_hot_from_pslib=True
set_parse_ins_id=False
data_shuffle=True
use_cache=False

shrink_before_save=False
#half cold start config
half_cold_start_day=20201112
half_cold_start_pass=1
need_half_cold_start=False

init_model_path=""
hours="{0..23}"
split_interval=60
split_per_pass=1
inner_split_pass=1 # 1h/pass
is_data_hourly_placed=True

save_first_base=False

pipe_command="python3 my_data_generator.py config_homefeed.yaml"
# pipe_command="/bin/libslot_record_du_homefeed.so"

save_xbox_before_update=False
check_exist_seconds=30
pass_per_day=2
checkpoint_per_pass=24
save_delta_frequency=24
prefetch=False
download_command = "./bin/read_from_afs.nogz " + ins_fs_name + " " + ins_fs_ugi

multi_tag=False
all_ins_tags=[6, 15, 16, 107]
target_name=['realfr', 'vi', 'inactive', 'active', 'va', 'lowthred', 'highthred']
task_id = [1, 2, 3, 4, 5, 0, 1]

learning_rate=1e-4

# fine tune
fine_tune=True
fine_tune_hour=False

# test
load_infer_mode="checkpoint"

# days
days="{20230226..20230226}"
