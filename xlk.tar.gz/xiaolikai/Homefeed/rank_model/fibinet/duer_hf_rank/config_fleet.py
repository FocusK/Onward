"""
    @module config_fleet
    @function
    @class
    @method
"""
config = dict()

config['use_cvm'] = True
#config['scale_datanorm'] = 1e-4
config['dump_slot'] = True

config['trainer'] = "PSGPUTrainer"
config['worker_class'] = "PSGPUWorker"
config['use_ps_gpu'] = True

#sparse_table config
sparse_config = dict()
sparse_config['sparse_table_class'] = "DownpourSparseSSDTable"
sparse_config['sparse_accessor_class'] = "DownpourCtrDymfAccessor" # add for dynamic embedding
#sparse_config['sparse_compress_in_save'] = True
sparse_config['sparse_compress_in_save'] = False
sparse_config['sparse_shard_num'] = 37
#sparse_config['sparse_accessor_class'] = "DownpourCtrAccessor"

sparse_config['sparse_embedx_dim'] = 9 # need to be the biggest emb dim in dynamic mf 
sparse_config['sparse_embedx_threshold'] = 0
sparse_config['sparse_nonclk_coeff'] = 0.1
sparse_config['sparse_click_coeff'] = 1.0

sparse_config['sparse_base_threshold'] = 0
sparse_config['sparse_delta_threshold'] = 0.25
sparse_config['sparse_delta_keep_days'] = 16.0
sparse_config['sparse_show_click_decay_rate'] = 0.98
sparse_config['sparse_delete_threshold'] = 0
sparse_config['sparse_delete_after_unseen_days'] = 30

sparse_config['sparse_learning_rate'] = 0.05
sparse_config['sparse_initial_g2sum'] = 3.0
sparse_config['sparse_initial_range'] = 1e-4
sparse_config['sparse_weight_bounds'] = [-10.0, 10.0]
#sparse_config['sparse_converter'] = "(python3.7 scripts/xbox_compressor_mf.py | bin/xbox_pb_converter)"
sparse_config['sparse_converter'] = ""
#sparse_config['sparse_enable_revert'] = True
# embedding name as key name
config['pull_gpups_sparse_0.w_0'] = sparse_config

#dense_table config
dense_config = dict()
dense_config['dense_table_class'] = "DownpourDenseTable"
dense_config['dense_compress_in_save'] = True
dense_config['dense_accessor_class'] = "DownpourDenseValueAccessor"
dense_config['dense_learning_rate'] = 5e-6
dense_config['dense_optimizer'] = "adam"
dense_config['dense_avg_decay'] = 0.999993
dense_config['dense_ada_decay'] = 0.9999
dense_config['dense_ada_epsilon'] = 1e-8
dense_config['dense_mom_decay'] = 0.99
dense_config['dense_naive_lr'] = 0.0002
#dense_config['dense_enable_revert'] = True
# 'dense_table' as key name
config['dense_table'] = dense_config  
