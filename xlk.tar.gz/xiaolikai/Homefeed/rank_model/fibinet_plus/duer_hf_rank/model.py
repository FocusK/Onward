"""
    file: model.py
    desc: implemnetation of fibinet
    data: 2023-03-09 19:40
"""
#!/usr/bin/env python
#coding=utf-8

import pstats
import paddle
import paddle.fluid as fluid
import paddle.fluid.layers as layers
from paddle.fluid.incubate.fleet.parameter_server.pslib import fleet
from paddle.fluid.incubate.fleet.utils.fleet_util import FleetUtil
from paddle.fluid.layers.nn import _pull_gpups_sparse
import config
import itertools

class Model(object):
    """
    model
    """
    def __init__(self, all_slots, use_cvm):
        """
        init
        """
        self._train_program = fluid.Program()
        self._startup_program = fluid.Program()
        self._all_slots = all_slots
        self._emb_dim = 9 + 3
        self.emb_sizes = []
        self.mf_sizes = []
        self._init_range = 0.2
        self._use_cvm = use_cvm
        self._prefix = "join" if use_cvm is True else "update"
        self.lau_prefix = 'lau'
        self.fc_sizes = [128, 64, 32, 1]
        self.lau_fc_size = [80, 40, 1]
        self.use_bn = False
        self.weight_normalization = False
        self.batchsize = 1024
        self.comp_fc_size = 40
        self.reduction_ratio = 3 
        self.sub_group = 3

        self.max_seq_len = 10
        self.d_key = 16
        self.d_value = 16
        self.n_head = 6

        self.sparse_inputs_slots = ['3001', '3002', '3003', '1000', '1001', '1002', '1003', '1004', '1005', \
                '1006', '2001', '2002', '2005', '2007', '2008', '2009', '2010', '2011', '2012', '2000']  # 2000: target_item
        self.varlen_sparse_inputs_slots = ['1007', '2003', '2004', '2006', '2013', '2014'] # 2014: usr_his_item
        self.varlen_sparse_inputs_weight_slots = ['11007', '12003', '12004', '12006', '12013', '12014']
        
        self.sparse_slots = []
        self.sparse_weight_slots = []
        self.gpu_slot = []
        self.use_var_list = []

        self.auc_metrics = {}
        self._feed_var = []
        self.stat_var = []
        self._main_target_var = []

        with fluid.program_guard(self._train_program, self._startup_program):
            with fluid.unique_name.guard():
                # create_feeds
                self.click = layers.data(name="click", shape=[-1, 1], dtype="int64", 
                                                lod_level=1, append_batch_size=False)
                
                cast_label = layers.cast(self.click, dtype='float32')
                cast_label.stop_gradient = True
                ones = layers.fill_constant_batch_size_like(
                    input=self.click, shape=[-1, 1], dtype="float32", value=1)
                show_clk = layers.cast(layers.concat([ones, cast_label], axis=1), dtype='float32')
                show_clk.stop_gradient = True
                
                input_slots_data = []  # use_var_list
                for i in self._all_slots:
                    if i not in self.varlen_sparse_inputs_weight_slots:
                        l = layers.data(name=i, shape=[1], dtype="int64", lod_level=1)
                        self.emb_sizes.append(self._emb_dim)
                        self.mf_sizes.append(self._emb_dim - 3)
                        self.sparse_slots.append(l)
                    else:
                        l = layers.data(name=i, shape=[1], dtype="float32", lod_level=1)
                        self.sparse_weight_slots.append(l)
                    self.gpu_slot.append(int(i))
                    input_slots_data.append(l)

                # pull sparse embedding
                sparse_slots_embs = _pull_gpups_sparse(self.sparse_slots, size = self.emb_sizes,
                                                     is_distributed=True, is_sparse=True)
                assert len(self.sparse_slots) == len(sparse_slots_embs)
                sparse_embs = sparse_slots_embs[:len(self.sparse_inputs_slots)]
                varlen_sparse_embs = sparse_slots_embs[len(self.sparse_inputs_slots):]

                # create feed_var for online prediction
                self._feed_var = sparse_slots_embs + self.sparse_weight_slots

                weighted_varlen_sparse_embs = []
                for i in range(len(varlen_sparse_embs)):
                    weighted_varlen_sparse_embs.append(
                        layers.elementwise_mul(varlen_sparse_embs[i], self.sparse_weight_slots[i]))  #(B*T, 1) 

                new_sparse_input = sparse_embs + weighted_varlen_sparse_embs
                print('new_sparse_input size: ' + str(len(new_sparse_input)))   # 26
                
                cvms = fluid.contrib.layers.fused_seqpool_cvm(new_sparse_input, 'sum', show_clk, use_cvm=False)
                concat = fluid.layers.concat(cvms, axis=1)
                cvms_tensor = paddle.reshape(concat, [-1, len(self.sparse_slots), self._emb_dim - 2])
                print("cvms len: " + str(len(cvms)))  # 26
                print("cvms[0] shape: " + str(cvms[0].shape)) # (-1, 10)
                print("concat shape: " + str(concat.shape))  # (-1, 260)
                print("cvms_tensor shape: " + str(cvms_tensor.shape))  #(-1,26,10)
                feat_embeddings = fluid.layers.crop_tensor(
                    cvms_tensor, shape = [-1, len(self.sparse_slots), self._emb_dim - 3], offsets = [0, 0, 1]) #(-1,44,12)
                print("feat_embeddings shape:" + str(feat_embeddings.shape))  #(-1 26 9)

                ##################### SENET #####################
                senet_embs = self._senet_plus(feat_embeddings, self.reduction_ratio, self.sub_group)
                print("senet emb shape:" + str(senet_embs.shape))  #(-1 26 9)

                ##################### bilinear interaction layer plus #####################
                bi_layer_output = self._bilinear_interaction_layer_plus(feat_embeddings, mode="field_each")
                # 去除senet上的双线性模块
                # se_bi_layer_output = self._bilinear_interaction_layer_plus(senet_embs, mode="field_each")
                print("bi layer output shape is " + str(bi_layer_output.shape)) # (-1 325)

                ##################### compression layer #####################
                compression_output = self._compression_layer(bi_layer_output, self.comp_fc_size)
                print('compression_output shape is ' + str(compression_output.shape))

                ##################### DNN #####################
                dnn_input = paddle.reshape(senet_embs, [-1, len(self.sparse_slots) * (self._emb_dim - 3)])
                print("dnn input shape:" + str(dnn_input.shape))    #(-1, 26*9)
                dnn_input = layers.concat([dnn_input, compression_output], axis=-1)
                print("after concat dnn input shape:" + str(dnn_input.shape))    #(-1, 26*9)
                y_dnn = self._fc_layers(dnn_input, self.fc_sizes, self._prefix)
                print("y_dnn shape: " + str(y_dnn.shape))  #(-1, 1)

                # predict
                pred_q = layers.sigmoid(fluid.layers.clip(y_dnn, min=-15.0, max=15.0))
                
                self._main_target_var.append(pred_q)
                self.predict_score = pred_q
                cost = layers.log_loss(input=pred_q, label=cast_label)
                self.avg_cost = layers.mean(x=cost)

                # fluid.layers.Print(self.avg_cost, summarize=-1, print_tensor_name=False, print_tensor_lod=False, \
                #                 print_tensor_layout=False, print_tensor_type=False, print_tensor_shape=False, \
                #                 message="training loss")

                # auc
                binary_predict = layers.concat(
                    input=[layers.elementwise_sub(layers.ceil(pred_q), pred_q), pred_q], axis=1)
                auc, batch_auc, [batch_stat_pos, batch_stat_neg, stat_pos, stat_neg] = \
                    layers.auc(input=binary_predict, label=self.click, curve='ROC', 
                                        num_thresholds=4096)
                self.batch_auc = batch_auc
                sqrerr, abserr, prob, q, pos, total = \
                    fluid.contrib.layers.ctr_metric_bundle(pred_q, cast_label)
                ls = [stat_pos, stat_neg, sqrerr, abserr, prob, q, pos, total]
                self.stat_var.extend(ls)
                metric_list = [batch_stat_pos, batch_stat_neg, stat_pos, stat_neg, \
                                sqrerr, abserr, prob, q, pos, total]
                metric_types =  ["int64"] * 4 + ["float32"] * 6
                metric_all = [metric_list, metric_types]
                self.auc_metrics["click"] = metric_all
                # for input mapping
                self.use_var_list.append(self.click)
                self.use_var_list.extend(input_slots_data)
    

    def _senet(self, all_emb, reduction_ratio=3):
        """
        Func:
            implementation of senet
        Args:
            all_emb: a lod tensor, shape is (-1 slot_nums, embed_dim)
            reduction_ratio: integer, the ratio of fc
        Output:
            a lod tensor, shape is (-1 slot_nums, embed_dim)
        """
        slot_nums = all_emb.shape[1] # 获取特征个数
        fc_unit = max(1, slot_nums // reduction_ratio) # 计算FC层的神经元个数
        ################## squeeze ##################
        squeeze_emb = layers.reduce_mean(all_emb, dim=-1) # (-1, slot_nums, 1)
        falten_emb = layers.flatten(squeeze_emb) # (-1, slot_nums)   
        print('feature nums is ' + str(slot_nums)) # 26
        print('falten_emb shape is:' + str(falten_emb.shape)) # (-1 26)
        ################## excitation ##################
        weight = layers.fc(input=falten_emb, size=fc_unit, act='relu',
                param_attr =
                    fluid.ParamAttr(learning_rate=1.0,
                    initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (slot_nums ** 0.5)),
                        name="se_w_1"),
                bias_attr =
                    fluid.ParamAttr(learning_rate=1.0,
                    initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (slot_nums ** 0.5)),
                    name="se_b_1"))  # (-1, fc_unit)
        weight = layers.fc(input=weight, size=slot_nums, act='sigmoid',
                param_attr =
                    fluid.ParamAttr(learning_rate=1.0,
                    initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (fc_unit ** 0.5)),
                        name="se_w_2"),
                bias_attr =
                    fluid.ParamAttr(learning_rate=1.0,
                    initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (fc_unit ** 0.5)),
                    name="se_b_2")) # (-1, slot_nums)
        ################## re_weight ##################
        out = layers.elementwise_mul(all_emb, layers.unsqueeze(weight, axes=[2])) # (-1, slot_nums, embed_dim) * (-1, slot_nums, 1)
        print('senet out shape is: ' + str(out.shape)) # (-1 slot_nums embed_dim)
        return out

    
    def _senet_plus(self, all_emb, reduction_ratio=3, sub_group=1):
        """
        Func:
            implementation of senet+
        Args:
            all_emb: a lod tensor, shape is (-1 slot_nums, embed_dim)
            reduction_ratio: integer, the ratio of fc
            sub_group: integer, means split origin embedding into sub_group, which sub_emb's dimention is embed_dim/sub_group
        Output:
            a lod tensor, shape is (-1 slot_nums, embed_dim)
        """
        slot_nums = all_emb.shape[1] # 获取特征个数
        fc_unit = max(1, slot_nums // reduction_ratio) # 计算FC层的神经元个数
        assert all_emb.shape[-1] % sub_group == 0
        ################## squeeze plus ##################
        all_emb_group_list = layers.split(all_emb, sub_group, dim=-1)
        mean_features = [layers.reduce_mean(sub_emb, dim=-1, keep_dim=True) for sub_emb in all_emb_group_list]
        max_features = [layers.reduce_max(sub_emb, dim=-1, keep_dim=True) for sub_emb in all_emb_group_list]
        print('len mean_features ' + str(len(mean_features)) + ' , eg shape is ' + str(mean_features[0].shape))
        print('len max_features ' + str(len(max_features)) + ' , eg shape is ' + str(max_features[0].shape))
        summary_features = []
        for fea_idx in range(len(mean_features)):
            summary_features.append(mean_features[fea_idx])
            summary_features.append(max_features[fea_idx])
        concated_summary_features = layers.concat(summary_features, axis=-1)
        print('concated_summary_features shape is ' + str(concated_summary_features.shape)) # (-1 slot_nums 2*sub_group)
        flatten_summary_features = layers.flatten(concated_summary_features)
        print('flatten_summary_features shape is:' + str(flatten_summary_features.shape)) # (-1 slot_num*2*sub_group)
        ################## excitation ##################
        weight = layers.fc(input=flatten_summary_features, size=fc_unit, act='relu',
                param_attr =
                    fluid.ParamAttr(learning_rate=1.0,
                    initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (slot_nums ** 0.5)),
                        name="se_w_1"),
                bias_attr =
                    fluid.ParamAttr(learning_rate=1.0,
                    initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (slot_nums ** 0.5)),
                    name="se_b_1"))  # (-1, fc_unit)
        weight = layers.fc(input=weight, size=slot_nums, act='sigmoid',
                param_attr =
                    fluid.ParamAttr(learning_rate=1.0,
                    initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (fc_unit ** 0.5)),
                        name="se_w_2"),
                bias_attr =
                    fluid.ParamAttr(learning_rate=1.0,
                    initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (fc_unit ** 0.5)),
                    name="se_b_2")) # (-1, slot_nums)
        ################## re_weight ##################
        out = layers.elementwise_mul(all_emb, layers.unsqueeze(weight, axes=[2])) # (-1, slot_nums, embed_dim) * (-1, slot_nums, 1)
        ################## fuse ##################
        out = layers.elementwise_add(all_emb, out)
        print('senet out shape is: ' + str(out.shape)) # (-1 slot_nums embed_dim)
        return out
    
    def _bilinear_interaction_layer_plus(self, all_emb, mode):
        """
        Func:
            implementation of bilinear interaction layer+
        Input:
            all_emb: an embedding which has concated all embed , shape is (-1, slot_nums, embed_dim)
            mode: "field_all"、"field_each"、 "field_interaction"
        Output:
            an embedding which has concated all bi-linear+ interaction embed, shape is (-1, slot_nums*(slot_nums-1)/2)
        """
        slot_nums = all_emb.shape[1]
        embed_dim = all_emb.shape[2]
        emb_list = layers.split(all_emb, num_or_sections=slot_nums, dim=1)
        emb_list = [layers.squeeze(emb, axes=[1]) for emb in emb_list] # list, ele shape is (-1 embed_dim)
        print('emb shape is ' + str(emb_list[0].shape)) # (-1 embed_dim)
        if mode == "field_all":
            # 构建一个共享的参数矩阵
            W = layers.create_parameter(
                shape=[embed_dim, embed_dim], dtype='float32')
            # 先计算v_i和W的结果
            vidots = [layers.matmul(emb, W) for emb in emb_list]  # (-1 embed_dim)
            print('vidot shape is ' + str(vidots[0].shape))
            # 计算inner product
            p_ij = [
                layers.reduce_sum(layers.elementwise_mul(vidots[i], emb_list[j]), dim=1, keep_dim=True)
                for i, j in itertools.combinations(range(slot_nums), 2)
            ] # (-1 1)
            print('p_ij shape is ' + str(p_ij[0].shape))
            output = layers.concat(p_ij, axis=-1) # (-1 slot_nums*(slot_nums-1)/2)
            return output
            
        elif mode == "field_each":
            # 构建参数矩阵，数量与slot_nums保持一致
            W_list = [
                layers.create_parameter(shape=[embed_dim, embed_dim], dtype='float32') for _ in range(slot_nums)
            ]
            # 先计算v_i和W的结果
            vidots = [layers.matmul(emb_list[i], W_list[i]) for i in range(slot_nums)]
            # 计算inner product
            p_ij = [
                layers.reduce_sum(layers.elementwise_mul(vidots[i], emb_list[j]), dim=1, keep_dim=True)
                for i, j in itertools.combinations(range(slot_nums), 2)
            ] # (-1 1)
            print('p_ij shape is ' + str(p_ij[0].shape))
            output = layers.concat(p_ij, axis=-1) # (-1 slot_nums*(slot_nums-1)/2)
            return output

        elif mode == "field_interaction":
            W_list = [layers.create_parameter(shape=[embed_dim, embed_dim], dtype='float32') 
                        for _, _ in itertools.combinations(range(slot_nums), 2)]
            p_ij = [
                layers.reduce_sum(layers.elementwise_mul(layers.matmul(v[0], w), v[1]), dim=1, keep_dim=True)
                for v, w in zip(itertools.combinations(emb_list, 2), self.W_list)
            ]
            output = layers.concat(p_ij, axis=-1) # (-1 slot_nums*(slot_nums-1)/2)
        else:
            raise NotImplementedError

    def _bilinear_interaction_layer(self, all_emb, mode):
        """
        Func:
            implementation of bilinear interaction layer
        Input:
            all_emb: an embedding which has concated all embed , shape is (-1, slot_nums, embed_dim)
            mode: "field_all"、"field_each"、 "field_interaction"
        Output:
        an embedding which has concated all bi-linear+ interaction embed, shape is (-1 embed_dim * slot_nums*(slot_nums-1)/2)
        """
        slot_nums = all_emb.shape[1]
        embed_dim = all_emb.shape[2]
        emb_list = layers.split(all_emb, num_or_sections=slot_nums, dim=1)
        emb_list = [layers.squeeze(emb, axes=[1]) for emb in emb_list] # list, ele shape is (-1 embed_dim)
        if mode == "field_all":
            # 构建一个共享的参数矩阵
            W = layers.create_parameter(
                shape=[embed_dim, embed_dim], dtype='float32')
            # 先计算点积
            vidots = [layers.matmul(emb, W) for emb in emb_list]  # (-1 embed_dim)
            # 计算Hadamard Product
            p_ij = [
                fluid.layers.elementwise_mul(vidots[i], emb_list[j])
                    for i, j in itertools.combinations(range(slot_nums), 2)
            ] # (-1 embed_dim)
            output = layers.concat(p_ij, axis=-1) # (-1 embed_dim * slot_nums*(slot_nums-1)/2)
            return output
            
        elif mode == "field_each":
            # 构建参数矩阵，数量与slot_nums保持一致
            W_list = [
                layers.create_parameter(shape=[embed_dim, embed_dim], dtype='float32') for _ in range(slot_nums)
            ]
            # 计算点积
            vidots = [layers.matmul(emb_list[i], W_list[i]) for i in range(slot_nums)]
            # 计算 Hadamard product
            p_ij = [layers.elementwise_mul(vidots[i], emb_list[j])
                    for i, j in itertools.combinations(range(slot_nums), 2)] # (-1 embed_dim)
            output = layers.concat(p_ij, axis=-1)
            return output

        elif mode == "field_interaction":
            W_list = [layers.create_parameter(shape=[embed_dim, embed_dim], dtype='float32') 
                        for _, _ in itertools.combinations(range(slot_nums), 2)]
            p_ij = [layers.elementwise_mul(layers.matmul(v[0], w), v[1])
                for v, w in zip(itertools.combinations(emb_list, 2), self.W_list)
            ]
            output = layers.concat(p_ij, axis=-1)
            return output
        else:
            raise NotImplementedError

    def _compression_layer(self, bi_linear_out_emb, comp_fc_size, lr_x=1.0):
        """
        Func:
            to reduce model parameters, add compression layer after bi-linear layer
        Input:
            bi_linear_out_emb: the output of bi-linear layer
            comp_fc_size: size of fc in compress layer
        """
        output = layers.fc(
                    input = bi_linear_out_emb,
                    size = comp_fc_size,
                    act = None,
                    param_attr =
                        fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=1.0 * bi_linear_out_emb.shape[-1]),
                            name='compre_fc_w'),
                    bias_attr =
                        fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=1.0 * bi_linear_out_emb.shape[-1]),
                        name='compre_fc_b'))
        print('in compression layer, output shape is ' + str(output.shape))
        return output

    def _fc_layers(self, input, layers, prefix, lr_x=1.0):
        """
        _fc_layers
        """
        fc_layers_input = [input]
        fc_layers_size = layers
        fc_layers_act = ["relu"] * (len(fc_layers_size) - 1) + [None]
        scales_tmp = [input.shape[1]] + fc_layers_size
        scales = []
        for i in range(len(scales_tmp)):
            scales.append(self._init_range / (scales_tmp[i] ** 0.5))

        params_name = []
        for i in range(len(fc_layers_size)):
            w_name = '{}_{}.w_0'.format(prefix, i)
            b_name = '{}_{}.b_0'.format(prefix, i)

            fc = fluid.layers.fc(
                    input = fc_layers_input[-1],
                    size = fc_layers_size[i],
                    act = fc_layers_act[i],
                    param_attr =
                        fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=1.0 * scales[i]),
                            name=w_name),
                    bias_attr =
                        fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=1.0 * scales[i]),
                        name=b_name))
            fc_layers_input.append(fc)
            params_name.append(w_name)
            params_name.append(b_name)
        return fc_layers_input[-1]

    def get_stat_var_names(self):
        """
        get_stat_var_names
        """
        return [ v.name for v in self.stat_var]
    
    def get_save_params(self):
        """
        get_save_params
        return list
        """
        save_vars = self._train_program.global_block().vars
        save_params = []
        for var in save_vars:
            if save_vars[var].persistable:
                if not var.startswith("_") and not var.startswith("embedding"):
                    save_params.append(var)
        return save_params
    
    def get_auc_metric_dict(self):
        """
        get_auc_metric_dict
        eg.{"wanbo": [auc_stat_list_wanbo, auc_stat_types_wanbo]}
        """
        return self.auc_metrics