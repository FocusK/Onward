# !/usr/bin/env python3
"""
    @module infer 
    @function
    @class
    @method
"""
import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)
import numpy as np
import datetime
import paddle
import paddle.fluid as fluid
import threading
import time
import config
import config_fleet
from util import *
from paddle.fluid.incubate.fleet.parameter_server.pslib import fleet
from paddle.distributed.fleet.utils.fs import AFSClient
from paddle.fluid.incubate.fleet.base.role_maker import GeneralRoleMaker
from model import Model
import paddle.fluid.core as core
paddle.enable_static()
ins_ready_sem = threading.Semaphore(0)
could_load_sem = threading.Semaphore(2)

hdfs_client = AFSClient()
hdfs_client.init(config.fs_name, config.fs_ugi.split(",")[0],
                            config.fs_ugi.split(",")[1], "./conf/client.conf")
load_hdfs_client = AFSClient()
load_hdfs_client.init(config.load_model_fs_name, config.load_model_fs_ugi.split(",")[0],
                            config.load_model_fs_ugi.split(",")[1], "./conf/client.conf")
ins_hdfs_client = AFSClient()
ins_hdfs_client.init(config.ins_fs_name, config.ins_fs_ugi.split(",")[0],
                            config.ins_fs_ugi.split(",")[1], "./conf/client.conf")

fleet_util.set_fsclient(load_hdfs_client)

INS = 0
MODEL = 1
LOAD_MODEL = 2

def fs(ins_or_model):
    """
    ins_or_model: INS or MODEL
    """
    global hdfs_client
    global load_hdfs_client
    global ins_hdfs_client

    if ins_or_model == MODEL:
        return hdfs_client
    if ins_or_model == LOAD_MODEL:
        return load_hdfs_client

    return ins_hdfs_client


def create_model(all_slot):
    """
    create_model
    """
    join_model = Model(all_slot, True)
    update_model = Model(all_slot, False)
    return join_model, update_model


def create_dataset(psgpu, use_var_list, my_filelist, day):
    """
    create_dataset
    """
    dataset = fluid.DatasetFactory().create_dataset(config.dataset_type)
    dataset.set_feed_type("SlotRecordInMemoryDataFeed")
    dataset.set_batch_size(config.batch_size)
    dataset.set_thread(config.thread_num)
    dataset.set_hdfs_config(config.ins_fs_name, config.ins_fs_ugi)
    dataset.set_download_cmd(config.download_command)
    dataset.set_pipe_command(config.pipe_command)
    dataset._set_use_ps_gpu(psgpu)
    dataset.set_date(day)
    dataset.set_filelist(my_filelist)
    dataset.set_use_var(use_var_list)
    if "set_parse_ins_id" in dir(config) and config.set_parse_ins_id is True:
        dataset.set_parse_ins_id(True)
    if "merge_by_lineid" in dir(config) and config.merge_by_lineid is True:
        dataset.set_merge_by_lineid(merge_size=2)
    return dataset


def preload_thread(dataset_list, model, data_path_list, day, last_day, last_pass, psgpu):
    """
    preload_thread
    """
    try:
        preload_thread_func(dataset_list, model, data_path_list, day, last_day, last_pass, psgpu)
    except Exception as e:
        could_load_sem.release()
        ins_ready_sem.release()
        fleet_util.rank0_error('preload_thread exception :%s' % (e))


def preload_thread_func(dataset_list, model, data_path_list, day, last_day, last_pass, psgpu):
    """
    preload_thread_func
    """
    for pass_index in range(1, len(data_path_list)+ 1):
        dataset = None
        if (last_day != -1 and int(day) == last_day) and (last_pass != -1 and int(pass_index) < last_pass):
            fleet_util.rank0_info("preload_thread_func skip day/pass %s/%s " % (day, pass_index))
            dataset_list.append(None)
            continue
        could_load_sem.acquire()
        if dataset is not None:
            begin = time.time()
            dataset.wait_preload_done()
            end = time.time()
            fleet_util.rank0_info("wait data preload done cost %s min" % ((end - begin) / 60.0))
        if dataset is None:
            cur_path = data_path_list[pass_index - 1]
            fleet_util.rank0_info("cur_pass: %s cur_path: %s" % (pass_index, cur_path))

            path_list = []
            for i in cur_path:
                cur_dir, cur_files = fs(INS).ls_dir(i)
                path_list += cur_files

            for i in range(len(path_list)):
                path_list[i] = 'afs:' + path_list[i]

            my_filelist = fleet.split_files(path_list)
            
            fleet_util.rank0_info("pass_id :" + str(pass_index) + "  filelist len:" \
                        + str(len(my_filelist)) + "   filelist: " \
                        + ",".join(my_filelist[:2]) + "..." + ",".join(my_filelist[-2:]))

            dataset = create_dataset(psgpu, model.use_var_list, my_filelist, day)
            fleet_util.rank0_info("going to load into memory")
            begin = time.time()
            dataset.load_into_memory(is_shuffle=False)
            end = time.time()
            fleet_util.rank0_info("load into memory + shuffle done, cost %s min" % ((end - begin) / 60.0))
            fleet_util.rank0_info("get_memory_data_size: %d" % (dataset.get_memory_data_size()))
            dataset_list.append(dataset)
            ins_ready_sem.release()
    fleet_util.rank0_info("thread finished, exit")


if __name__ == "__main__":
    place = fluid.CUDAPlace(0)
    exe = fluid.Executor(place)
    # for paddlecloud
    # if you want to run in local, please comment out the lines below.
    paddle_trainer_endpoints = os.getenv("PADDLE_TRAINER_ENDPOINTS")
    rank0_ip_port = paddle_trainer_endpoints.split(",")[0].split(":")
    rank0_ip = rank0_ip_port[0]
    rank0_port = rank0_ip_port[1]
    rank0_port = str(int(rank0_port) + 3)
    http_ip_port = rank0_ip + ":" + rank0_port
    print("cur ip_port: {}".format(http_ip_port))
    role_maker = GeneralRoleMaker(use_ps_gpu=True, http_ip_port=http_ip_port)
    
    fleet.init(role_maker)
    all_slot = create_slots_name(config.slot_path)
    join_model, update_model = create_model(all_slot)

    join_save_params = join_model.get_save_params()
    fleet_util.rank0_info("join_save_params:%s" % join_save_params)
    update_save_params = update_model.get_save_params()
    fleet_util.rank0_info("update_save_params:%s" % update_save_params)

    if not ("only_update" in dir(config) and config.only_update == True):
        assert join_model is not None, "join_model should not be None when only_update=False"
        join_save_params = join_model.get_save_params()
        fleet_util.rank0_info("join_save_params:%s" % join_save_params)

    thread_stat_var_names = update_model.get_stat_var_names()
    if not ("only_update" in dir(config) and config.only_update == True):
        thread_stat_var_names += join_model.get_stat_var_names()

    thread_stat_var_names = list(set(thread_stat_var_names))
    config_fleet.config['stat_var_names'] = thread_stat_var_names

    scope1 = fluid.Scope()
    scope2 = fluid.Scope()

    para_without_datanorm = []
    if not ("only_update" in dir(config) and config.only_update == True):
        para_without_datanorm = []
        all_para = join_model._train_program.global_block().all_parameters()
        for e in all_para:
            if e.name.endswith(".batch_size") \
                    or e.name.endswith(".batch_sum") \
                    or e.name.endswith(".batch_square_sum"):
                continue
            para_without_datanorm.append(e.name)

    para_without_datanorm_update = []
    all_para_update = update_model._train_program.global_block().all_parameters()
    for e in all_para_update:
        if e.name.endswith(".batch_size") \
                or e.name.endswith(".batch_sum") \
                or e.name.endswith(".batch_square_sum"):
            continue
        para_without_datanorm_update.append(e.name)

    adam = fluid.optimizer.Adam(learning_rate=config.learning_rate, beta1=0.99, beta2=0.9999, epsilon=1e-8)
    adam = fleet.distributed_optimizer(adam, strategy=config_fleet.config)
    if "only_update" in dir(config) and config.only_update == True:
        scope1 = None
        adam.minimize([update_model.avg_cost], 
                  [scope2],
                  [update_model._startup_program],
                  parameter_list=[para_without_datanorm_update],
                  program_mode="fuse_all_reduce")
    else:
        adam.minimize([join_model.avg_cost, update_model.avg_cost],
                [scope1, scope2],
                [join_model._startup_program, update_model._startup_program],
                parameter_list=[para_without_datanorm, para_without_datanorm_update],
                program_mode="fuse_all_reduce")

        # join phase: remove push sparse
        remove_op(join_model._train_program, "push_box_sparse")
        remove_backword(join_model._train_program)

        with open("join_main_program.pbtxt", "w") as fout:
            fout.write(str(join_model._train_program))
        with open("join_startup_program.pbtxt", "w") as fout:
            fout.write(str(join_model._startup_program))

        with open("join_main_program.bin", "wb") as f:
            f.write(join_model._train_program.desc.serialize_to_string())
        with open("join_startup_program.bin", "wb") as f:
            f.write(join_model._startup_program.desc.serialize_to_string())

    with open("update_main_program.pbtxt", "w") as fout:
        fout.write(str(update_model._train_program))
    with open("update_startup_program.pbtxt", "w") as fout:
        fout.write(str(update_model._startup_program))

    with open("update_main_program.bin", "wb") as f:
        f.write(update_model._train_program.desc.serialize_to_string())
    with open("update_startup_program.bin", "wb") as f:
        f.write(update_model._startup_program.desc.serialize_to_string())
    
    opt_info = fleet._opt_info
    opt_info["fleet_desc"].fs_client_param.uri = config.fs_name
    opt_info["fleet_desc"].fs_client_param.user = config.fs_ugi.split(",")[0]
    opt_info["fleet_desc"].fs_client_param.passwd = config.fs_ugi.split(",")[1]
    opt_info["fleet_desc"].fs_client_param.hadoop_bin= "$HADOOP_HOME/bin/hadoop"
    opt_info["fleet_desc"].server_param.downpour_server_param.service_param.server_class = "DownpourLocalPsServer"
    opt_info["fleet_desc"].server_param.downpour_server_param.service_param.client_class = "DownpourLocalPsClient"
    
    if fleet.is_server():
        fleet.run_server()
    elif fleet.is_worker():
        with fluid.scope_guard(scope2):
            exe.run(update_model._startup_program)
        if scope1:
            with fluid.scope_guard(scope1):
                exe.run(join_model._startup_program)

        fleet.init_worker()
        
        gpus_env = os.getenv("FLAGS_selected_gpus")
        print("gpus_env:", gpus_env)
        PSGPU = core.PSGPU()
        PSGPU.set_slot_vector(update_model.gpu_slot)
        PSGPU.init_gpu_ps([int(s) for s in gpus_env.split(",")])
        PSGPU.init_afs_api(config.ins_fs_name, config.ins_fs_ugi.split(",")[0],
                    config.ins_fs_ugi.split(",")[1], "./conf/client.conf")

        if "use_dynamic_mf" in dir(config) and config.use_dynamic_mf is True:
            PSGPU.set_slot_dim_vector(update_model.mf_sizes)

        # save_first_base = config.save_first_base
        path = config.train_data_path
        # 小数据量infer时
        # pass_per_day = 1
        # 全量infer
        pass_per_day = config.pass_per_day
        last_day, last_pass, last_path, xbox_base_key = fleet_util.get_last_save_model(config.output_path)
        fleet_util.rank0_info("last_day:%s, last_pass:%s , last_path: %s" % (last_day, last_pass, last_path))

        base_path="/".join(last_path.split("/")[:-3]) + '/'
        if "load_infer_base_path" in dir(config) and "load_infer_day" in dir(config):
            fleet_util.rank0_info("modify load model path")
            base_path = config.load_infer_base_path
            last_day = config.load_infer_day
            lass_pass=-1
        reqi = True if last_day != -1 else False
        if reqi:
            begin = time.time()
            if "load_infer_mode" in dir(config) and config.load_infer_mode == "checkpoint":
                last_path= base_path + str(last_day) + "/0/"
            else:
                last_path= base_path + str(last_day) + "/base/"

            fleet_util.rank0_info("going to load model %s" % last_path)
            fleet.set_date(0, last_day)
            load_model(fs(LOAD_MODEL), last_path, exe, None, None,
                          update_model._train_program, scope2, place, join_save_params,
                          update_save_params, 0)
            end = time.time()
            fleet_util.rank0_info("load model cost %s min" % ((end - begin) / 60.0))
            fleet.print_table_stat(0)

        dataset, next_dataset, cur_path, next_path, start_train = [None] * 5
        dataset_index = 0
        days = []
        train_day_start, train_day_end = config.days.strip('{}').split("..")
        begin_date = datetime.datetime.strptime(train_day_start, "%Y%m%d")
        end_date = datetime.datetime.strptime(train_day_end, "%Y%m%d")
        while begin_date <= end_date:
            date_str = begin_date.strftime("%Y%m%d")
            days.append(date_str)
            begin_date += datetime.timedelta(days=1)
        hours = os.popen("echo -n " + config.hours).read().split(" ")
        for day_index in range(len(days)):
            day = days[day_index]
            all_time = time.time()
            dataset_list = []

            # 小数据量infer时
            # cur_path_list = [[config.train_data_path[0] + "/event_day=" + day]]
            # print("cur_path_list:", cur_path_list)
            
            # 全量数据，分pass读取
            cur_path_list = []
            for cur_path_id in range(pass_per_day):
                if cur_path_id < 10:
                    cur_path_list.append([config.train_data_path[0] + "/event_day=" + day + "/pass=00" + str(cur_path_id)])
                else:
                    cur_path_list.append([config.train_data_path[0] + "/event_day=" + day + "/pass=0" + str(cur_path_id)])
            t = threading.Thread(target = preload_thread,
                    args = (dataset_list, update_model, cur_path_list, day, last_day, last_pass, PSGPU))
            t.setDaemon(True)
            t.start()

            fleet_util.rank0_info("======== BEGIN DAY:%s ========" % day)
            for pass_index in range(1, pass_per_day * config.inner_split_pass + 1):
                dataset = next_dataset
                next_dataset = None
                cur_path = next_path
                next_path = None
                if (last_day != -1 and int(day) == last_day) and (last_pass != -1 and int(pass_index) < last_pass):
                    dataset_index += 1
                    fleet_util.rank0_info("skip day/pass %s/%s " % (day, pass_index))
                    continue
                fleet_util.rank0_info("===========going to test day/pass %s/%s===========" % (day, pass_index))
                start_train = True
                if "load_infer_mode" in dir(config) and config.load_infer_mode == "xbox":
                    # load delta model 
                    delta_model_path = base_path + str(day) + "/delta-" + str(pass_index)
                    fleet_util.rank0_info("going to load delta model %s" % delta_model_path)
                    load_model(fs(LOAD_MODEL), delta_model_path, exe, join_model._train_program, 
                                scope1, update_model._train_program, scope2, place, 
                                join_save_params, update_save_params, 1)
                    end = time.time()
                    fleet_util.rank0_info("load delta model cost %s min" % ((end - begin) / 60.0))
    
                train_begin = time.time()
                ins_ready_sem.acquire()
                dataset = dataset_list[pass_index - 1]
                if dataset is None:
                    could_load_sem.release()
                    continue
                cur_path = cur_path_list[pass_index - 1]
                join_cost = 0
                update_cost = 0
                epochs = config.epoch_num
                PSGPU.begin_pass()
                for i in range(epochs):
                    join_epochs = 1
                    for ep in range(join_epochs):
                        fleet_util.rank0_info("join_epochs:%s" % ep)
                        fleet_util.rank0_info("run join default_main_program")
                        with fluid.scope_guard(scope2):
                            begin = time.time()
                            update_model._train_program._fleet_opt["dump_param"] = [update_model.predict_score.name]
                            update_model._train_program._fleet_opt["dump_fields_path"] = "%s/infer_result/" % (config.output_path)
                            exe.infer_from_dataset(update_model._train_program,
                                                   dataset,
                                                   scope2,
                                                   debug=False)
                            end = time.time()
                            fleet_util.rank0_info("join train cost %s s" % (end - begin))
                            join_cost += (end - begin) / 60.0
                            begin = time.time()

                            # AUC 
                            metric_dict = update_model.get_auc_metric_dict()
                            # {"wanbo": [auc_stat_list_wanbo, auc_stat_types_wanbo]}
                            for key, value in metric_dict.items():
                                if key == "predict_score":
                                    print("candidate predict_score is: ", value)
                                update_metric_str = get_global_metrics_str(scope2, 
                                                    value[0], "update " + key + " pass:")
                                fleet_util.rank0_info(update_metric_str)
                                clear_metrics(scope2, value[0], value[1])

                            end = time.time()
                            fleet_util.rank0_info("print join auc cost %s s" % (end - begin))

                PSGPU.end_pass()
                begin = time.time()
                dataset.release_memory()
                fleet.print_table_stat(0)
                end = time.time()
                fleet_util.rank0_info("release_memory cost %s min" % ((end - begin) / 60.0))
                dataset_index += 1
                train_end = time.time()
                train_cost = (train_end - train_begin) / 60.0
                other_cost = train_cost - join_cost - update_cost
                fleet_util.rank0_info(\
                    "finished test day %s pass %s time cost:%s min job time cost"
                    ":[join:%s min][update:%s min][other:%s min]" \
                    % (day, pass_index, train_cost, join_cost, update_cost, other_cost))
                could_load_sem.release()
            
            fleet_util.rank0_info(\
                    "finished test day %s  all cost time:%s min " \
                    % (day, (time.time() - all_time)/60.0))
            fleet.print_table_stat(0)
            t.join()
        PSGPU.finalize()
    fleet.stop_worker()
