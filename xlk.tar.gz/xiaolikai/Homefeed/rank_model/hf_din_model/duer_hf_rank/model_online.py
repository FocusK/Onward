"""
    @module model
    @function
    @class
    @method
"""
#!/usr/bin/env python
#coding=utf-8

import paddle
import paddle.fluid as fluid
from paddle.fluid.incubate.fleet.parameter_server.pslib import fleet
from paddle.fluid.incubate.fleet.utils.fleet_util import FleetUtil
from paddle.fluid.layers.nn import _pull_gpups_sparse
import config

class Model(object):
    """
    model
    """
    def __init__(self, all_slots, use_cvm):
        """
        init
        """
        self._train_program = fluid.Program()
        self._startup_program = fluid.Program()
        self._all_slots = all_slots
        self._emb_dim = 16 + 3
        self.emb_sizes = []
        self.mf_sizes = []
        self._init_range = 0.2
        self._use_cvm = use_cvm
        self._prefix = "join" if use_cvm is True else "update"
        self.lau_prefix = 'lau'
        self.fc_sizes = [128, 64, 32, 1]
        self.lau_fc_size = [80, 40, 1]
        self.use_bn = False
        self.weight_normalization = False

        self.sparse_inputs_slots = ['3001', '3002', '3003', '1000', '1001', '1002', '1003', '1004', '1005', \
                '1006', '2001', '2002', '2005', '2007', '2008', '2009', '2010', '2011', '2012', '2000']
        self.varlen_sparse_inputs_slots = ['1007', '2003', '2004', '2006', '2013', '2014']
        self.varlen_sparse_inputs_weight_slots = ['11007', '12003', '12004', '12006', '12013', '12014']
        
        self.sparse_slots = []
        self.sparse_weight_slots = []
        self.gpu_slot = []
        self.use_var_list = []

        self.auc_metrics = {}
        self._feed_var = []
        self.stat_var = []
        self._main_target_var = []

        with fluid.program_guard(self._train_program, self._startup_program):
            with fluid.unique_name.guard():
                # create_feeds
                self.click = fluid.layers.data(name="click", shape=[-1, 1], dtype="int64", 
                                                lod_level=1, append_batch_size=False)
                
                input_slots_data = []  # use_var_list
                for i in self._all_slots:
                    if i not in self.varlen_sparse_inputs_weight_slots:
                        l = fluid.layers.data(name=i, shape=[1], dtype="int64", lod_level=1)
                        self.emb_sizes.append(self._emb_dim)
                        self.mf_sizes.append(self._emb_dim - 3)
                        self.sparse_slots.append(l)
                    else:
                        l = fluid.layers.data(name=i, shape=[1], dtype="float32", lod_level=1)
                        self.sparse_weight_slots.append(l)
                    self.gpu_slot.append(int(i))
                    input_slots_data.append(l)

                # pull sparse embedding
                sparse_slots_embs = _pull_gpups_sparse(self.sparse_slots, size = self.emb_sizes,
                                                     is_distributed=True, is_sparse=True)
                assert len(self.sparse_slots) == len(sparse_slots_embs)
                sparse_embs = sparse_slots_embs[:len(self.sparse_inputs_slots)]
                varlen_sparse_embs = sparse_slots_embs[len(self.sparse_inputs_slots):]

                # create feed_var for online prediction
                self._feed_var = sparse_slots_embs + self.sparse_weight_slots

                weighted_varlen_sparse_embs = []
                for i in range(len(varlen_sparse_embs) - 1): # 不处理用户历史特征
                    weighted_varlen_sparse_embs.append(
                        fluid.layers.elementwise_mul(varlen_sparse_embs[i], self.sparse_weight_slots[i]))  #(B*T, 1) 

                cast_label = fluid.layers.cast(self.click, dtype='float32')
                cast_label.stop_gradient = True
                ones = fluid.layers.fill_constant_batch_size_like(
                    input=self.click, shape=[-1, 1], dtype="float32", value=1)
                show_clk = fluid.layers.cast(fluid.layers.concat([ones, cast_label], axis=1), dtype='float32')
                show_clk.stop_gradient = True

                ##################### 注意力模块计算用户兴趣向量 #####################
                his_fea_data_embs = varlen_sparse_embs[-1] # (-1, 19)
                his_fea_data_embs = fluid.layers.continuous_value_model(his_fea_data_embs, show_clk, use_cvm=False) # (-1, 17)
                print('after cvm, user shape is' + str(his_fea_data_embs.shape))
                his_fea_data_embs = paddle.reshape(his_fea_data_embs, [-1, 10, self._emb_dim-2]) # (-1, 10, 17)
                
                
                item_emb = sparse_embs[-1] #(-1, 19)
                item_emb = fluid.layers.continuous_value_model(item_emb, show_clk, use_cvm=False) # (-1, 17)
                print('after cvm, item shape is' + str(item_emb.shape))
                item_emb = paddle.reshape(item_emb, [-1, 1, self._emb_dim-2]) # (-1, 1, 17)
                
                mask = self.sparse_weight_slots[-1] #(B*10,)
                print('mask shape is' + str(mask.shape))
                mask = paddle.reshape(mask, [-1, 1, 10]) # (B, 1, 10)

                att_output = self._attention_layer(his_fea_data_embs, item_emb, mask) # (B, 1, 17)
                
                ##################### 其他特征进行fused_seqpool_cvm #####################
                new_sparse_input = sparse_embs + weighted_varlen_sparse_embs
                print('new_sparse_input size: ' + str(len(new_sparse_input)))   # 25
                cvms = []
                for index in range(len(new_sparse_input)):
                    emb = new_sparse_input[index]
                    bow = fluid.layers.sequence_pool(input=emb, pool_type='sum')
                    cvm = fluid.layers.continuous_value_model(bow, show_clk, use_cvm=False)
                    cvms.append(cvm)

                cvms = cvms + [att_output]  # 加入attention 输出
                concat = fluid.layers.concat(cvms, axis=1) # (B, 17*25)
                cvms_tensor = paddle.reshape(concat, [-1, len(cvms), self._emb_dim - 2]) # (B, 25, 17)
                print("cvms len: " + str(len(cvms)))   # 25
                print("cvms[0] shape: " + str(cvms[0].shape)) # (B, 17)
                print("concat shape: " + str(concat.shape))  # (B, 425)
                print("cvms_tensor shape: " + str(cvms_tensor.shape)) # (B, 25, 17)

                feat_embeddings = fluid.layers.crop_tensor(
                    cvms_tensor, shape = [-1, len(cvms), self._emb_dim - 3], offsets = [0, 0, 1]) # (B, 25, 16)
                print("feat_embeddings shape:" + str(feat_embeddings.shape))

                ##################### DNN #####################
                feat_embeddings = paddle.reshape(feat_embeddings, [-1, len(self.sparse_slots) * (self._emb_dim - 3)]) # (B, 26*16)
                print("feat_embeddings shape:" + str(feat_embeddings.shape))    #(-1, 416)
                
                y_dnn = self._fc_layers(feat_embeddings, self.fc_sizes, self._prefix)
                print("y_dnn shape: " + str(y_dnn.shape))  #(-1, 1)

                # predict
                pred_q = fluid.layers.sigmoid(fluid.layers.clip(y_dnn, min=-15.0, max=15.0))
                
                self._main_target_var.append(pred_q)
                self.predict_score = pred_q
                cost = fluid.layers.log_loss(input=pred_q, label=cast_label)
                self.avg_cost = fluid.layers.mean(x=cost)

                # auc
                binary_predict = fluid.layers.concat(
                    input=[fluid.layers.elementwise_sub(fluid.layers.ceil(pred_q), pred_q), pred_q], axis=1)
                auc, batch_auc, [batch_stat_pos, batch_stat_neg, stat_pos, stat_neg] = \
                    fluid.layers.auc(input=binary_predict, label=self.click, curve='ROC', 
                                        num_thresholds=4096)
                self.batch_auc = batch_auc
                sqrerr, abserr, prob, q, pos, total = \
                    fluid.contrib.layers.ctr_metric_bundle(pred_q, cast_label)
                ls = [stat_pos, stat_neg, sqrerr, abserr, prob, q, pos, total]
                self.stat_var.extend(ls)
                metric_list = [batch_stat_pos, batch_stat_neg, stat_pos, stat_neg, \
                                sqrerr, abserr, prob, q, pos, total]
                metric_types =  ["int64"] * 4 + ["float32"] * 6
                metric_all = [metric_list, metric_types]
                self.auc_metrics["click"] = metric_all
                # for input mapping
                self.use_var_list.append(self.click)
                self.use_var_list.extend(input_slots_data)
    
    def _attention_layer(self, u_emb, i_emb, mask, lr_x=1.0):
        """
        Args:
            u_emb: user history items's emb, shape is [B, T, D]. T is the num of user history items, D is real emb dim
            i_emb: candidate item emb, shape is [B, 1, D]
            mask: flag invalid features, shape is [B, 1, T]
            hidden_units: FC units, a list
            prefix: string, for name fc layer
        """
        i_emb = paddle.tile(i_emb, repeat_times = [1, 10, 1]) # (-1, T, 16)
        att_input = fluid.layers.concat([u_emb, i_emb, u_emb-i_emb, u_emb*i_emb], axis=-1) # (-1, T, 16*4)
        att_input = paddle.reshape(att_input, [-1, (self._emb_dim - 2) * 4]) #(-1*T, 64)
        att_output = fluid.layers.fc(
                    input = att_input, size = 80, act = 'relu',
                    param_attr = fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (att_input.shape[1] ** 0.5)),
                        name='att1_w'),
                    bias_attr =
                        fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (att_input.shape[1] ** 0.5)),
                        name='att1_b'))
        att_output = fluid.layers.fc(
                    input = att_output, size = 40, act = 'relu',
                    param_attr = fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (80 ** 0.5)),
                        name='att2_w'),
                    bias_attr =
                        fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (80 ** 0.5)),
                        name='att2_b'))
        att_output = fluid.layers.fc(
                    input = att_output, size = 1, act = None,
                    param_attr = fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (40 ** 0.5)),
                        name='att3_w'),
                    bias_attr =
                        fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (40 ** 0.5)),
                        name='att3_b')) #(B*T, 1)
        att_output = paddle.reshape(att_output, [-1, 1, 10])
        att_output += mask #(B, 1, T)

        att_output = att_output / ((self._emb_dim - 2) ** 0.5) # (B, 1, T)

        att_output = fluid.layers.softmax(att_output) # (B, 1, T)

        att_output = fluid.layers.matmul(att_output, u_emb) # (B, 1, D)

        att_output = paddle.reshape(att_output, [-1, (self._emb_dim - 2)]) # (B, D)
        
        att_smooth = fluid.layers.fc(
                    input = att_output, size = self._emb_dim - 2, act = None,
                    param_attr = fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (att_output.shape[1] ** 0.5)),
                        name='smooth_fc_w'),
                    bias_attr =
                        fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=self._init_range / (att_output.shape[1] ** 0.5)),
                        name='smooth_fc_b')) #(B, D)
        
        return att_smooth

    def _fc_layers(self, input, layers, prefix, lr_x=1.0):
        """
        _fc_layers
        """
        fc_layers_input = [input]
        fc_layers_size = layers
        fc_layers_act = ["relu"] * (len(fc_layers_size) - 1) + [None]
        scales_tmp = [input.shape[1]] + fc_layers_size
        scales = []
        for i in range(len(scales_tmp)):
            scales.append(self._init_range / (scales_tmp[i] ** 0.5))

        params_name = []
        for i in range(len(fc_layers_size)):
            w_name = '{}_{}.w_0'.format(prefix, i)
            b_name = '{}_{}.b_0'.format(prefix, i)

            fc = fluid.layers.fc(
                    input = fc_layers_input[-1],
                    size = fc_layers_size[i],
                    act = fc_layers_act[i],
                    param_attr =
                        fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=1.0 * scales[i]),
                            name=w_name),
                    bias_attr =
                        fluid.ParamAttr(learning_rate=lr_x,
                        initializer=fluid.initializer.NormalInitializer(loc=0.0, scale=1.0 * scales[i]),
                        name=b_name))
            fc_layers_input.append(fc)
            params_name.append(w_name)
            params_name.append(b_name)
        return fc_layers_input[-1]

    def get_stat_var_names(self):
        """
        get_stat_var_names
        """
        return [ v.name for v in self.stat_var]
    
    def get_save_params(self):
        """
        get_save_params
        return list
        """
        save_vars = self._train_program.global_block().vars
        save_params = []
        for var in save_vars:
            if save_vars[var].persistable:
                if not var.startswith("_") and not var.startswith("embedding"):
                    save_params.append(var)
        return save_params
    
    def get_auc_metric_dict(self):
        """
        get_auc_metric_dict
        eg.{"wanbo": [auc_stat_list_wanbo, auc_stat_types_wanbo]}
        """
        return self.auc_metrics