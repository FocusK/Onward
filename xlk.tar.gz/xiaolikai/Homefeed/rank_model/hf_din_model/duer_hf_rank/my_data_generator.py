"""
my_data_generator for homefeed_rank
"""

import sys
import yaml
import six
import os
import copy
import paddle.distributed.fleet as fleet
import logging
import numpy as np

hash_dim_ = 9223372036854775807

logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

def hash_int64_pos(sign_str):
    """
    哈希到int64
    """
    return int(sign_str) % hash_dim_

class YamlHelper(object):
    def load_yaml(self, yaml_file, other_part=None):
        part_list = ["runner", "hyper_parameters"]
        if other_part:
            part_list += other_part
        running_config = self.get_all_inters_from_yaml(yaml_file, part_list)
        running_config = self.workspace_adapter(running_config)
        return running_config

    def print_yaml(self, config):
        print(self.pretty_print_envs(config))

    def parse_yaml(self, config):
        vs = [int(i) for i in yaml.__version__.split(".")]
        if vs[0] < 5:
            use_full_loader = False
        elif vs[0] > 5:
            use_full_loader = True
        else:
            if vs[1] >= 1:
                use_full_loader = True
            else:
                use_full_loader = False

        if os.path.isfile(config):
            if six.PY2:
                with open(config, 'r') as rb:
                    if use_full_loader:
                        _config = yaml.load(rb.read(), Loader=yaml.FullLoader)
                    else:
                        _config = yaml.load(rb.read())
                    return _config
            else:
                with open(config, 'r', encoding="utf-8") as rb:
                    if use_full_loader:
                        _config = yaml.load(rb.read(), Loader=yaml.FullLoader)
                    else:
                        _config = yaml.load(rb.read())
                    return _config
        else:
            raise ValueError("config {} can not be supported".format(config))

    def get_all_inters_from_yaml(self, file, filters):
        _envs = self.parse_yaml(file)
        all_flattens = {}

        def fatten_env_namespace(namespace_nests, local_envs):
            for k, v in local_envs.items():
                if isinstance(v, dict):
                    nests = copy.deepcopy(namespace_nests)
                    nests.append(k)
                    fatten_env_namespace(nests, v)
                else:
                    global_k = ".".join(namespace_nests + [k])
                    all_flattens[global_k] = v

        fatten_env_namespace([], _envs)
        ret = {}
        for k, v in all_flattens.items():
            for f in filters:
                if k.startswith(f):
                    ret[k] = v
        return ret

    def workspace_adapter(self, config):
        workspace = config.get("workspace")
        for k, v in config.items():
            if isinstance(v, str) and "{workspace}" in v:
                config[k] = v.replace("{workspace}", workspace)
        return config

    def pretty_print_envs(self, envs, header=None):
        spacing = 2
        max_k = 40
        max_v = 45

        for k, v in envs.items():
            max_k = max(max_k, len(k))

        h_format = "    " + "|{{:>{}s}}{}{{:^{}s}}|\n".format(max_k, " " *
                                                              spacing, max_v)
        l_format = "    " + "|{{:>{}s}}{{}}{{:^{}s}}|\n".format(max_k, max_v)
        length = max_k + max_v + spacing

        border = "    +" + "".join(["="] * length) + "+"
        line = "    +" + "".join(["-"] * length) + "+"

        draws = ""
        draws += border + "\n"

        if header:
            draws += h_format.format(header[0], header[1])
        else:
            draws += h_format.format("PaddleRec Benchmark Envs", "Value")

        draws += line + "\n"

        for k, v in sorted(envs.items()):
            if isinstance(v, str) and len(v) >= max_v:
                str_v = "... " + v[-41:]
            else:
                str_v = v

            draws += l_format.format(k, " " * spacing, str(str_v))

        draws += border

        _str = "\n{}\n".format(draws)
        return _str



class Reader(fleet.MultiSlotStringDataGenerator):
    """
    自定义读取器
    """
    def init_reader(self, config):
        self.config = config

        self.sparse_inputs_slots = self.config.get("hyper_parameters.sparse_inputs_slots")
        self.varlen_sparse_inputs_slots = self.config.get("hyper_parameters.varlen_sparse_inputs_slots")
        # self.dense_inputs_slots = self.config.get("hyper_parameters.dense_inputs_slots")
        self.varlen_sparse_inputs_weight_slots = self.config.get("hyper_parameters.varlen_sparse_inputs_weight_slots")

        self.sample_list = []
        self.sample_list.append('click')
        self.sample_list.extend(self.sparse_inputs_slots)
        self.sample_list.extend(self.varlen_sparse_inputs_slots)
        self.sample_list.extend(self.varlen_sparse_inputs_weight_slots)
        # self.sample_list.append("dense_input")

    def generate_sample(self, line):
        """
        generate_sample
        """

        def data_iter():
            """
            data_iter
            """
            show_click_info, sparse_feature_info, dense_feature_info, \
                label_info, tag_info = line.strip('\r\n').split('\t')
            _, _, label, weight = show_click_info.split()
            feature = {
                "click": [label]
            }

            for extract_feature in dense_feature_info.split():
                fea_slot, fea_val = extract_feature.split(':', 1)
                # if fea_slot in self.dense_inputs_slots:
                #     feature[fea_slot] = [str(fea_val)]
                # elif fea_slot in self.varlen_sparse_inputs_weight_slots:
                if fea_slot in self.varlen_sparse_inputs_weight_slots:
                    if fea_slot not in feature:
                        feature[fea_slot] = fea_val.split(':')

            for extract_feature in sparse_feature_info.split():
                fea_sign, fea_slot = extract_feature.split(':')
                if fea_slot in self.sparse_inputs_slots:
                    feature[fea_slot] = [fea_sign]
                elif fea_slot in self.varlen_sparse_inputs_slots:
                    if fea_slot not in feature:
                        feature[fea_slot] = [fea_sign]
                    else:
                        feature[fea_slot].append(fea_sign)

            res = []
            # dense_input = []
            # for s in self.dense_inputs_slots:
            #     if s in feature:
            #         dense_input.extend(feature[s])
            #     else:
            #         dense_input.append('0.0')
            # feature['dense_input'] = dense_input
            
            for fn in self.sample_list:
                res.append(feature[fn])
                    
            yield list(zip(self.sample_list, res))
        return data_iter

if __name__ == "__main__":
    yaml_path = sys.argv[1]
    yaml_helper = YamlHelper()
    config = yaml_helper.load_yaml(yaml_path)
    reader = Reader()
    reader.init_reader(config)
    reader.run_from_stdin()
