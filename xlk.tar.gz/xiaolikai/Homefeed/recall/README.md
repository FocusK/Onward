# 四大主垂资源基于图的i2i召回

-recall
--graph_i2i  # 保存数据预处理、建图的代码
--data_ana  # 用于分析各垂类资源的分布情况
--recall_ctr # 根据dump数据, 分析每一路召回的点展比等数据
