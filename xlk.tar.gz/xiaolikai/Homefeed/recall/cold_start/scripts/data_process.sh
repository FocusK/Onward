#!bin/bash
source ~/.bashrc

######## common header ########
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
logPath=${workPath}/logs;
sqlPath=${workPath}/sqls;

######### 接收必备参数 ########
dst_day=$1
if [ ! -n "$1" ];then
    echo "dst_day is not given!!!"
    dst_day=$(date -d "last day" +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)

data=${workPath}/data;

# rm -rf $data
# if [ ! -d $data ]; then
#     mkdir -p $data
# fi

if [ ! -d $logPath  ];then
  mkdir -p $logPath
fi
log="${logPath}/cold_start.log"

voc_dict="${data}/voc.dict"
embed_dict="${data}/embed.dict"
ann_dict="${data}/ann_new.dict"
old_id2sign_dict="${data}/id2sign_old.dict"
new_id2sign_dict="${data}/id2sign_new.dict"

run_ann(){
    cd $sqlPath
    echo $(date +%T)
    # 处理原始embedding
    qexlk -f deal_embedding.sql --hivevar currentDate=${curDate} dst_day=${dst_day}
    # 下载数据
    base_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/cold_start"
    hk -cat "${base_path}/sign_embed/event_day=${dst_day}/*" | python3 ./embed_process.py "voc" > $voc_dict
    hk -cat "${base_path}/sign_embed/event_day=${dst_day}/*" | python3 ./embed_process.py "embedding" > $embed_dict
    echo "Success to get embed and voc !!!"
    # # id2sign
    hk -getmerge "${base_path}/id2sign/event_day=${dst_day}" $id2sign_dict
    echo "Success to get id2sign !!!"


    # 处理bilibili原始embedding
    # qexlk -f deal_emb_bili.sql --hivevar currentDate=${curDate} dst_day=${dst_day}
    # # 下载数据
    # base_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/cold_start"
    # hk -cat "${base_path}/bili_sign_embed/event_day=${dst_day}/*" | python3 ./embed_process.py "voc" > $voc_dict
    # hk -cat "${base_path}/bili_sign_embed/event_day=${dst_day}/*" | python3 ./embed_process.py "embedding" > $embed_dict
    # echo "Success to get embed and voc !!!"
    # # # id2sign
    # hk -getmerge "${base_path}/bili_id2sign/event_day=${dst_day}" $id2sign_dict
    # echo "Success to get id2sign !!!"
    echo $(date +%T)
    # 调用faiss
    echo "Run ann ..."
    python3 ./run_ann_cold_start.py $embed_dict $voc_dict $ann_dict $old_id2sign_dict $new_id2sign_dict
    echo $(date +%T)
}

{
    run_ann
} > $log 2>&1


