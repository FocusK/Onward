#!bin/bash
source ~/.bashrc
utils_scripts="/home/work/xiaolikai/baidu/personal-code/xiaolikai/utils.sh"
source ${utils_scripts}

######## common header ########
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
logPath=${workPath}/logs;
sqlPath=${workPath}/sqls;
pbdictPath="/home/work/xiaolikai/baidu/personal-code/xiaolikai/common_tools/pb_dict";
finalI2IPath=${workPath}/data;
protoPath="/home/work/xiaolikai/baidu/personal-code/xiaolikai/common_tools/protos";

pb_dict_max=100000000

if [ ! -d $logPath  ];then
  mkdir -p $logPath
fi

######## 确定时间范围 ########
endDate=$1;
if [ ! -n "$1" ];then
    endDate=$(date -d "last day" +%Y%m%d)
fi
endDate=$(date -d "$endDate" +%Y%m%d)

######## merge_data rename get_pbdict ########
log=${logPath}/get_pb_dict_${endDate}.log;
{
  echo $(date +%T)
  "${pbdictPath}/create_binary_pbdict" -p "${finalI2IPath}" -P "${finalI2IPath}" -B "${protoPath}/histroy_i2i_recom.proto" -b "rus.PbHistoryI2IRecommend" -n "new_bilibili_faiss_dict" -m ${pb_dict_max}
  "${pbdictPath}/create_binary_pbdict" -p "${finalI2IPath}" -P "${finalI2IPath}" -B "${protoPath}/histroy_i2i_recom.proto" -b "rus.PbHistoryI2IRecommend" -n "new_bilibili_kmeans_dict" -m ${pb_dict_max}
  echo "success create pb"
  echo $(date +%T)
} > ${log} 2>&1