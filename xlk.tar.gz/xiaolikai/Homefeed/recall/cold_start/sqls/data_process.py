"""
    Date: 2022-11-16
"""
import os

def interest_nums(voc_file, file):
    with open(voc_file, 'w') as voc:
        with open(file, 'r') as f:
            for line in f:
                line = line.strip().split('\t')
                if len(line) != 2:
                    continue
                voc.writelines(line[0] + '\n')

if __name__ == '__main__':
    file = '/home/work/xiaolikai/baidu/personal-code/xiaolikai/Homefeed/recall/cold_start/data/history_final_id_emb_data.txt'
    voc_file = "/home/work/xiaolikai/baidu/personal-code/xiaolikai/Homefeed/recall/cold_start/data/voc.txt"
    interest_nums(voc_file, file)

