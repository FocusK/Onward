udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_deal_emb_bili_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';
create TEMPORARY FUNCTION row_number_by_sort as 'org.apache.hadoop.hive.ql.udf.UDFRowNumberByPreSort';

ADD FILE ./id2sign.py;

drop table if exists raw_emb_data_bili;
create external table if not exists raw_emb_data_bili
(
    resource_id string,
    embedding string
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/cold_start/new_bili";

alter table raw_emb_data_bili add partition(event_day='${hivevar:dst_day}')
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/cold_start/new_bili/event_day=${hivevar:dst_day}";


-- 转换sign值
drop table if exists bili_sign_embed_table;
create external table if not exists bili_sign_embed_table
(
    sign string,
    embedding string
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/cold_start/bili_sign_embed";

insert overwrite table bili_sign_embed_table partition (event_day='${hivevar:dst_day}')
select
    transform(ta.*)
using 'python id2sign.py gene_sign'
as (sign, embedding)
from(
    select
        resource_id, embedding
    from raw_emb_data_bili
    where event_day="${hivevar:dst_day}"
)ta;

-- 基于原始边信息，生成id2sign的映射
drop table if exists bili_id2sign_table;
create external table if not exists bili_id2sign_table
(
    id string, 
    sign string
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/cold_start/bili_id2sign";

insert overwrite table bili_id2sign_table partition (event_day='${hivevar:dst_day}')
select
    transform(b.*)
using 'python id2sign.py id2sign'
as (id, sign)
from(
    select
        resource_id
    from raw_emb_data_bili
    where event_day="${hivevar:dst_day}"
)b;