"""
    Author: Likai Xiao
    File:   embed_process.py
    Date:   2022-09-06 14:23
    Desc:   图召回任务中,对模型产出的embedding文件进行预处理, 拆分得到voc.dict和embedding.dict
"""
# -*- coding: utf-8 -*-

import os
import sys

def main(mode):
    """
        处理模型训练生成的embedding
        mode=voc: 生成词表文件
        mode=embedding: 生成embedding文件
    """
    for line in sys.stdin:
        eles = line.strip('\n').split('\t')
        if len(eles) != 2:
            continue
        voc, embedding = eles[0], eles[1]
        if mode == "voc":
            print(voc)
        elif mode == "embedding":
            print(embedding)

if __name__ == '__main__':
    run_mode = sys.argv[1]
    main(run_mode)