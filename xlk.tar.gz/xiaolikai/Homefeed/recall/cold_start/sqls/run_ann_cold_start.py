"""
    Author: Likai Xiao
    File:   run_ann.py
    Date:   2022-09-07 14:12
    Desc:   执行faiss, 进行ann
"""
# -*- coding: utf-8 -*-
import os
import sys, importlib
importlib.reload(sys)
sys.path.append(os.path.abspath(__file__).rsplit('/', 5)[0])

from common_tools.ann.faiss.faiss_ivfpq_cold_start import Faiss

def main(embed_file, voc_file, ann_file, old_id2sign_file, new_id2sign_file):
    embedding_path = embed_file
    voc_path = voc_file
    ann_path = ann_file
    faiss_config = {"embed_dim": 64, "embed_path": embedding_path,
                "voc_path": voc_path, "ann_file_local_path": ann_path, 
                "old_id2sign_path": old_id2sign_file, "new_id2sign_path": new_id2sign_file,
                "nprobe": 100, "top_k": 501}
    myFaiss = Faiss(faiss_config)
    myFaiss.embed_recall()

if __name__ == "__main__":
    embed_file = sys.argv[1]
    voc_file = sys.argv[2]
    ann_file = sys.argv[3]
    old_id2sign_file = sys.argv[4]
    new_id2sign_file = sys.argv[5]
    main(embed_file, voc_file, ann_file, old_id2sign_file, new_id2sign_file)
    
    
