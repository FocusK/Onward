# -*- coding: utf-8 -*-

"""
File: distribution_ana.py
Author: xiaolikai
Date: 2022/10/12 11:28:30
Desc: 统计数据分布
"""
import io
import os
import sys
import json
from operator import itemgetter
from itertools import groupby


def parse_stdin(stdin):
    """
        验证输入是否合理
    """
    for line in stdin:
        message = line.strip().split('\t')
        if len(message) != 2:
            continue
        yield message


def resource_nums_per_session():
    """
        查看每个session下完播资源的数量
    """ 
    for _, session in groupby(parse_stdin(sys.stdin), itemgetter(0)):
        session = list(session)
        rids = set()
        for idx in range(len(session)):
            _, resource_id = session[idx]
            rids.add(resource_id)
        nums = len(rids)
        if nums == 1:
            print('1')
        elif nums <= 3:
            print('le_3')
        elif nums <= 5:
            print('le_5')
        elif nums <= 10:
            print('le_10')
        else:
            print('gt_10')


if __name__ == "__main__":
    status = sys.argv[1]
    if status == "rnps":
        resource_nums_per_session()