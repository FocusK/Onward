udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_distribution_ana_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';
create TEMPORARY FUNCTION row_number_by_sort as 'org.apache.hadoop.hive.ql.udf.UDFRowNumberByPreSort';

ADD FILE ./distribution_ana.py;

-- 统计短视频所有场景下每个session中包含的完播资源数量
select
    tc.resource_nums_per_session as resource_nums_per_session,
    count(*) as freqence
from(
    select
        transform(tb.*)
    using 'python distribution_ana.py rnps'
    as (resource_nums_per_session)
    from(
        select ta.*
        from(
            select
                logid_trigger,
                resource_id
            from udw_ns.default.duer_idw_bot_detail
            where event_day>="${hivevar:start_day}" and event_day<="${hivevar:dst_day}"
                and source_type = "ai.dueros.bot.short_video"
                and logid_trigger <> "" and resource_id <> ""
                and resource_id not like "%[a-zA-Z]%"
                and start_time <> "" and play_num <> ""
                and play_seconds <> "" and cast(play_seconds as int) >= 60
        )ta
        distribute by ta.logid_trigger
        sort by ta.logid_trigger
    )tb
)tc
group by tc.resource_nums_per_session;


-- 统计长视频资源每个session中包含的完播资源数量
select
    tc.resource_nums_per_session as resource_nums_per_session,
    count(*) as freqence
from(
    select
        transform(tb.*)
    using 'python distribution_ana.py rnps'
    as (resource_nums_per_session)
    from(
        select ta.*
        from(
            select
                logid_trigger,
                resource_id
            from udw_ns.default.duer_idw_bot_detail
            where event_day>="${hivevar:start_day}" and event_day<="${hivevar:dst_day}"
                and source_type = "ai.dueros.bot.video_on_demand"
                and logid_trigger <> "" and resource_id <> ""
                and resource_id not like "%[a-zA-Z]%"
                and start_time <> "" and play_num <> ""
                and userid <> "" and userid is not NULL
                and play_seconds <> "" and cast(play_seconds as int) >= 240
        )ta
        distribute by ta.logid_trigger
        sort by ta.logid_trigger
    )tb
)tc
group by tc.resource_nums_per_session;

-- 统计有声资源每个session中包含的完播资源数量
select
    tc.resource_nums_per_session as resource_nums_per_session,
    count(*) as freqence
from(
    select
        transform(tb.*)
    using 'python distribution_ana.py rnps'
    as (resource_nums_per_session)
    from(
        select ta.*
        from(
            select
                logid_trigger,
                resource_id
            from udw_ns.default.duer_idw_bot_detail
            where event_day>="${hivevar:start_day}" and event_day<="${hivevar:dst_day}"
                and source_type = "audio_unicast"
                and logid_trigger <> "" and resource_id <> ""
                and start_time <> "" and play_num <> ""
                and userid <> "" and userid is not NULL
                and play_seconds <> "" and cast(play_seconds as int) >= 120
        )ta
        distribute by ta.logid_trigger
        sort by ta.logid_trigger
    )tb
)tc
group by tc.resource_nums_per_session;