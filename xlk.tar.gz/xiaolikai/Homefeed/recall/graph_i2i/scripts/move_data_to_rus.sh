#!bin/bash
source ~/.bashrc
utils_scripts="/home/work/xiaolikai/baidu/personal-code/xiaolikai/utils.sh"
source ${utils_scripts}

######## graph i2i common header ########
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
logPath=${workPath}/logs;
finalI2IPath=${workPath}/global_i2i_with_score;

if [ ! -d $logPath  ];then
  mkdir -p $logPath
fi

######## 确定时间范围 ########
endDate=$1;
if [ ! -n "$1" ];then
    endDate=$(date -d "last day" +%Y%m%d)
fi
endDate=$(date -d "$endDate" +%Y%m%d)

cur_dateTime=`date +%Y%m%d_%H%M%S`
echo $cur_dateTime

######## merge_data rename get_pbdict ########
log=${logPath}/move_data_to_rus_${endDate}.log;
{
    echo $(date +%T)
    HT_FILE_MIN_SIZE=300
    PBD_FILE_MIN_SIZE=3000
    cd $finalI2IPath
    if [ ! -f ./global_i2i_recom_dict_with_score.ht ];then
        echo "global_i2i_recom_dict_with_score.ht not exist!"
        exit 12    
    fi
  
    if [ ! -f ./global_i2i_recom_dict_with_score.pbd ];then
        echo "global_i2i_recom_dict_with_score.pbd not exist!"
        exit 12    
    fi
    ht_file="./global_i2i_recom_dict_with_score.ht"
    pbd_file="./global_i2i_recom_dict_with_score.pbd"
    ht_size=$(du -sm $ht_file | awk -F ' ' '{print $1}')
    pbd_size=$(du -sm $pbd_file | awk -F ' ' '{print $1}')

    echo $ht_size
    echo $pbd_size
    if [[ $ht_size -lt $HT_FILE_MIN_SIZE ]];then
        echo "global_i2i_recom_dict_with_score.ht is invalid"
        exit 13
    fi
    if [[ $pbd_size -lt $PBD_FILE_MIN_SIZE ]];then
        echo "global_i2i_recom_dict_with_score.pbd is invalid"
        exit 13
    fi

    echo "start move data"
    DEST_BASE_PATH="/home/disk1/rus/offline-pipeline-routine/baidu/oxygen/rus-pipeline/pipeline-migrate/GlobalEmbeddingTrainingPipeline/data/${endDate}/global_mining_dict/global_i2i_with_score"
    echo $DEST_BASE_PATH
    scp_file_to_rus ./global_i2i_recom_dict_with_score.ht $DEST_BASE_PATH
    scp_file_to_rus ./global_i2i_recom_dict_with_score.pbd $DEST_BASE_PATH
    echo "success move data"
    echo $(date +%T)
    cd ${logPath}
} > ${log} 2>&1