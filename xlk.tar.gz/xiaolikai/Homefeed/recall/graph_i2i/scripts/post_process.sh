"""
    对生成的i2i数据进行后处理
"""
#!bin/bash
source ~/.bashrc

cd `dirname $0`/..
workPath=`pwd`
curDate=`date +"%Y%m%d"`
logPath=${workPath}/logs;
finalI2IPath=${workPath}/global_i2i_with_score;
sqlsPath=${workPath}/sqls;

endDate=$1;
if [ ! -n "$1" ];then
    endDate=$(date -d "last day" +%Y%m%d)
fi
endDate=$(date -d "$endDate" +%Y%m%d)

log=${logPath}/post_process_${endDate}.log;

{
    cd $sqlsPath
    python3 ./post_process.py
} > ${log} 2>&1






