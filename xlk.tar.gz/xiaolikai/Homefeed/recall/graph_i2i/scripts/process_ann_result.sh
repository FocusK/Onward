#!bin/bash
source ~/.bashrc
utils_scripts="/home/work/xiaolikai/baidu/personal-code/xiaolikai/utils.sh"
source ${utils_scripts}

######## common header ########
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
logPath=${workPath}/logs;
sqlPath=${workPath}/sqls;
pbdictPath="/home/work/xiaolikai/baidu/personal-code/xiaolikai/common_tools/pb_dict";
finalI2IPath=${workPath}/shortvideo_data;
protoPath="/home/work/xiaolikai/baidu/personal-code/xiaolikai/common_tools/protos";

mu_data=${workPath}/mu_data/mu_ann.dict;
au_data=${workPath}/au_data/au_ann.dict;
vod_data=${workPath}/vod_data/vod_ann.dict;
sv_data=${workPath}/shortvideo_data/shortvideo_ann.dict;
final_data=${workPath}/shortvideo_data/global_i2i_recom_dict_with_score;
final_path=${workPath}/global_i2i_with_score;

pb_dict_max=100000000

if [ ! -d $logPath  ];then
  mkdir -p $logPath
fi

######## 确定时间范围 ########
endDate=$1;
if [ ! -n "$1" ];then
    endDate=$(date -d "last day" +%Y%m%d)
fi
endDate=$(date -d "$endDate" +%Y%m%d)

######## merge_data rename get_pbdict ########
log=${logPath}/merge_ann_result_${endDate}.log;
{
  echo $(date +%T)
  cat ${mu_data} ${au_data} ${vod_data} >> ${sv_data}
  echo "success merge data"
  mv ${sv_data} ${final_data}
  echo "rename final file"

  "${pbdictPath}/create_binary_pbdict" -p "${finalI2IPath}" -P "${finalI2IPath}" -B "${protoPath}/histroy_i2i_recom.proto" -b "rus.PbHistoryI2IRecommend" -n "global_i2i_recom_dict_with_score" -m ${pb_dict_max}
  echo "success create pb"

  cd $finalI2IPath
  mv * $final_path
  echo "success move data to dest path"
  echo $(date +%T)
} > ${log} 2>&1