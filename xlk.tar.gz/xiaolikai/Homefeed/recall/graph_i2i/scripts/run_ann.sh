#!bin/bash
source ~/.bashrc

######## common header ########
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
logPath=${workPath}/logs;
sqlPath=${workPath}/sqls;

######### 接收必备参数 ########
algo=$1;
if [ ! -n $algo ];then
  echo "you should give algo name,exit !!!"
  exit -1
fi

dst_day=$2;
if [ ! -n "$2" ];then
    echo "dst_day is not given!!!"
    dst_day=$(date -d "last day" +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)

data=${workPath}/${algo}_data;

if [ ! -d $logPath  ];then
  mkdir -p $logPath
fi
log="${logPath}/${algo}_${dst_day}.log"

rm -rf $data
if [ ! -d $data ]; then
    mkdir -p $data
fi

voc_dict="${data}/${algo}_voc.dict"
embed_dict="${data}/${algo}_embed.dict"
id2sign_dict="${data}/${algo}_id2sign.dict"
ann_dict="${data}/${algo}_ann.dict"

run_ann(){
    ######## embedding处理 ########
    cd $sqlPath
    base_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall"
    hk -cat "${base_path}/model_output/embedding/*/*" | python3 ./embed_process.py "voc" > $voc_dict
    hk -cat "${base_path}/model_output/embedding*/*" | python3 ./embed_process.py "embedding" > $embed_dict
    echo "Success to get embed and voc !!!"
    # id2sign
    hk -getmerge "${base_path}/final_graph_id2sign/event_day=${dst_day}" $id2sign_dict
    echo "Success to get id2sign !!!"
    
    # 调用faiss
    echo "Run ann ..."
    python3 ./run_ann.py $embed_dict $voc_dict $ann_dict $id2sign_dict
} > $log 2>&1


