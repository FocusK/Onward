#!bin/bash
source ~/.bashrc

sleep 10s
