#!bin/bash
source ~/.bashrc

######## common header ########
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
logPath=${workPath}/logs;
sqlPath=${workPath}/sqls;

# rm -rf ${logPath}
if [ ! -d $logPath  ];then
  mkdir -p $logPath
fi

######## 确定时间范围 ########
endDate=$1;
if [ ! -n "$1" ];then
    endDate=$(date -d "last day" +%Y%m%d)
fi
endDate=$(date -d "$endDate" +%Y%m%d)
startDate=$(date -d "$endDate - 15 day" +%Y%m%d)
yestarday=$(date -d "$endDate - 1 day" +%Y%m%d)

####### 删除昨天产出的数据 ######
hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_edge/vod/event_day=$yestarday"
hk -rmr $hadoop_path
hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_node/vod/event_day=$yestarday"
hk -rmr $hadoop_path
hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_id2sign/vod/event_day=$yestarday"
hk -rmr $hadoop_path
hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/model/vod/event_day=$yestarday"
hk -rmr $hadoop_path
hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/raw_graph_data/vod/event_day=$yestarday"
hk -rmr $hadoop_path

######## 生成当天数据 ########
log=${logPath}/vod_data_process_${endDate}.log;

cd ${sqlPath}
qexlk -f vod_graph_data_process.sql --hivevar currentDate=${curDate} start_day=${startDate} dst_day=${endDate} > ${log} 2>&1

# ####### 删除昨天产出的数据 ######
# hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/vod_graph_data/event_day=$yestarday"
# hk -rmr $hadoop_path
