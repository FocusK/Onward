# -*- coding: utf-8 -*-

"""
File: data_process_au.py
Author: xiaolikai
Date: 2022/10/11 16:15:30
Desc: 图召回时处理有声数据
"""
import io
import os
import sys
import json
import time
from operator import itemgetter
from itertools import groupby

def parse_stdin(stdin):
    """
        验证输入是否合理
    """
    for line in stdin:
        message = line.strip().split('\t')
        if len(message) != 3:
            continue
        yield message


def generate_edge():
    """
        针对有声场景,生成边数据
    """
    for _, session in groupby(parse_stdin(sys.stdin), itemgetter(0)):
        session = list(session)
        edges = []
        for idx in range(len(session) - 1):
            _, node_s, _ = session[idx]
            _, node_e, _ = session[idx + 1]
            node_s = "AU_" + node_s
            node_e = "AU_" + node_e
            if node_s != node_e:
                edges.append([node_s, node_e, '1'])
        for edge in edges:
            print('\t'.join(edge))


if __name__ == '__main__':
    generate_edge()