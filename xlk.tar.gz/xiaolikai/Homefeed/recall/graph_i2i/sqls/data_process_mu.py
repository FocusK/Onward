# -*- coding: utf-8 -*-

"""
File: data_process.py
Author: xiaolikai
Date: 2022/10/09 16:27:30
Desc: 图召回时处理音乐数据
"""
import io
import os
import sys
import json
import time
from operator import itemgetter
from itertools import groupby

class Config(object):
    def __init__(self):
        pass

    feature_size = 21
    song_prefix = 's_'
    voice_prefix = 'v_'
    userid_prefix = 'u_'
    hour_of_day_prefix = 'hod_'
    day_of_week_prefix = 'dow_'
    user_singer_prefix = 'usgr_'
    user_search_prefix = 'ss_'
    tag_prefix = 't_'
    singer_prefix = 'sgr_'
    language_prefix = 'lan_'
    reason_prefix = 'reason_'
    user_tag_affinity_prefix = 'uta_'
    SONG_FINISH_3_DAY = 0.5047669694943988
    SONG_FINISH_7_DAY = 0.507953890418449
    SONG_FINISH_15_DAY = 0.5123508932426735
    SONG_FINISH_30_DAY = 0.5239183895975538
    SONG_FINISH_ALPHA = 50.0
    
    user_feature_size = 5
    song_feature_size = 7
    user_action_data_size = 13

    show_appid = '''
        dmDC7C388CAE1EF843
        dmE33D6D48A0E0E3EF
        dm57CE54274DBC961B
        dm98E73155C22E60AF
        dmB6A9270EC01C552E
        dm24994249754B0E21
        dm2617D9290B5EE728
        dm6E310B749E4D80D8
        dmD4E55228A95E42E1
        dmA537FA4D59ACDF7C
        dm0E66BDF305125292
        dm12DBB98B4CABFC08
        dmF4DB86392284AA0D
        dm5A0246CCBDF3DE50
        dmAC6F4F8A2CCEBEC6
        dm979DF997AFEA3455
        dmE3A1062B0A0035B5
        dm2E947E22868EDDFB
        dm55030D40C1E10BF2
        dmA371C7B24DD87352
        dm48FA49B253649FF1
        dm54E553BFD65C0C6C
        dm319D5348D735F67E
        dmD71360A86E472E1C
        dm1D126A3D51ABD54C
        dm02545174A79B65F7
        dm1D9CF0FAC7548254
        dm10147F6BCD05BEE6
        dm7D36A28A6A6CC2FF
        dm10D7C6BC9A064E93
        dmF6E29EB9C07C6682
        dm69B6CB42B9748B49
        dm685EDE9FA8119978
        dm4E04276D3D6B0E17
        dm113EC22CAF9A6E14
        dm8C4FCD49AACBF3E1
        dmD122534CFA265441
        dm7AC0EB471EFBDB19
        dm1684B09E65141422
        dmBE671FFBA8EE0F6E
        dm7C2FB2AC570921A3
        dm2A7DEBCE78EF24A8
        dm08A24E39B5CC9BA0
        dmE7F17F7EADD86CCA
        dm38B8483F6B317D9B
        dm1512B2CF2078EF6E
        dm100496A9D23125EA
        dm2F9DC0CB5C6CE7C8
        dmADFA69A88E01E9D9
        dmD740A443D80F2C31
        dmB31AAADFA923DC08
    '''

    speaker_appid = '''
        dmC983500B0350C3AC
        dm6191A02F6E33CEF5
        dm697C6FAC8496A8F6
        dmC934369F7158BBE4
        dm418F72A6DBF3667A
        dm20C33BB8106E11BA
        dmAB6299C9325AB02E
        dmCED4855B8449A354
        dm17016374F4EBF852
        dm93BD1EADC358D8BB
        dmB79A182C1292DD44
        dmE43B489A53FCA4C3
        dmA1D4BA0CB0A19BED
        dm6B0E2F0EB119859B
        dm0875C6A49D76C2AB
        dm48BB0F88EA95AB70
        dm82A220FA8FD12ED6
        dmF12415D0F85323CB
        dm009547DA9C0AC9AD
        dm528571E56463808C
        dm74285F4C33E1F0FD
        dmE8586C556A8064BA
        dm3F66BA3157AFD5D1
        dm175EA4C583DCD253
        dmF791F123F9012547
        dm6F4C1FE8D6418302
        dmAE481649FA26A90C
        dm58083E5C5F01B5B2
        dm49F48EC114DC4CF3
        dm2DC65862316E928B
        dm9A51A83F53B356B2
        dm6E2BBE5784A024C6
        dmDE07C450FB961B72
        dm28A782CBFB84EBF0
        dm639B71F08F7627A8
        dm8AC4B565DF8DD252
        dm12E2D2D499355366
    '''
    appid_set = set()
    for appid in show_appid.split():
        appid_set.add(appid.strip())
    for appid in speaker_appid.split():
        appid_set.add(appid.strip())

conf = Config()

def get_yyyy_mm_dd_HH_MM_SS(time_str):
    if len(time_str.split(':')) == 4:
        idx = time_str.rfind(':')
        time_str = time_str[:idx]
    return time_str

def rec_type_transformer(rec_type):
    if rec_type == "tag":
        rec_type = "25"
    elif rec_type == "common":
        rec_type = "20"
    elif rec_type == "daily_recommendation":
        rec_type = "21"
    elif rec_type == "singer":
        rec_type = "28"
    elif rec_type == "song":
        rec_type = "2"
    return rec_type

def get_elapse_second(song_info):
    units = song_info.split('@')
    if len(units) < 11:
        return None, None, None
    md5id, entity_id, start_time, end_time, total_seconds, \
            is_finished, is_active_switch, duration, song_retrieve_type, entity_rank, \
            recall_reason = units
    played_seconds = -1
    try:
        start_time = get_yyyy_mm_dd_HH_MM_SS(start_time)
        end_time = get_yyyy_mm_dd_HH_MM_SS(end_time)
        start_ts = int(time.mktime(time.strptime(start_time, "%Y-%m-%d %H:%M:%S")))
        end_ts = int(time.mktime(time.strptime(end_time, "%Y-%m-%d %H:%M:%S")))
        played_seconds = end_ts - start_ts
    except ValueError:
        played_seconds = int(total_seconds)
    return played_seconds, md5id, is_finished


def mapper_handler(userid, query_time, rec_type, song_infos, N):
    """
        不同场景下, 返回前N条首播歌曲
    """
    song_info_list = song_infos.split('||')
    wanbo_songs = []
    for song_info in song_info_list:
        elapse_second, md5id, is_finished = get_elapse_second(song_info)
        if is_finished != '1':
            continue
        if md5id is None:
            continue
        if len(md5id) == 0:
            continue
        if is_finished == '1' or elapse_second >= 60:
            wanbo_songs.append("MU_" + md5id)
            if len(wanbo_songs) >= N:
                break
    if len(wanbo_songs) > 0:
        if rec_type == '2':
            print(userid + '\t' + query_time + '\t' + rec_type + '\t' + wanbo_songs[0])
        else:  
            if len(wanbo_songs) > 1:
                wanbo_song_list = ' '.join(wanbo_songs)
                print(userid + '\t' + query_time + '\t' + rec_type + '\t' + wanbo_song_list)


def mapper():
    """
    选取播放列表中纯泛场景-20/21前三首、点播场景-2第一首、tag-25和歌手-28场景前五首完播的歌曲
    """
    voice_dict = {0:"female", 2: "male", 4:"child"}
    for line in sys.stdin:
        elems = line.strip().split('\t')
        if len(elems) != 15:
            continue
        logid, appid, _, userid, query, _, _, slot, rec_type, _, query_time, song_infos, _, voice_info, _ = elems
        if appid not in conf.appid_set:
            continue
        if userid in ["", "\N"]:
            continue
        if query_time in ["", "\N"]:
            continue
        try:
            voice_info = eval(voice_info)
        except:
            continue
        if "voice_type" in voice_info:
            voice_int = voice_info["voice_type"] 
            if voice_int in voice_dict:
                voice_type = voice_dict[voice_int]
            else:
                voice_type = ""
        else:
            voice_type = ""
        rec_type = rec_type_transformer(rec_type)
        if rec_type == '2':
            mapper_handler(userid, query_time, rec_type, song_infos, 1)
        if rec_type == '20' or rec_type == '21':
            mapper_handler(userid, query_time, rec_type, song_infos, 3)
        if rec_type == '25' or rec_type == '28':
            mapper_handler(userid, query_time, rec_type, song_infos, 5)


def generate_edge():
    """
        针对非点播场景的数据,生成边数据
    """
    for line in sys.stdin:
        songs = line.strip().split(' ')
        if len(songs) < 2:
            continue
        edges = []
        for idx in range(len(songs) - 1):
            node_s = songs[idx]
            node_e = songs[idx + 1]
            if node_s != node_e:
                edges.append([node_s, node_e, '1'])
        for edge in edges:
            print('\t'.join(edge))


def parse_stdin(stdin):
    """
        验证输入是否合理
    """
    for line in stdin:
        message = line.strip().split('\t')
        if len(message) != 3:
            continue
        yield message

def generate_edge_dianbo():
    """
        针对点播场景的数据,生成边数据
    """
    for _, session in groupby(parse_stdin(sys.stdin), itemgetter(0)):
        session = list(session)
        edges = []
        for idx in range(len(session) - 1):
            _, _, node_s = session[idx]
            _, _, node_e = session[idx + 1]
            if node_s != node_e:
                edges.append([node_s, node_e, '1'])
        for edge in edges:
            print('\t'.join(edge))


if __name__ == '__main__':
    status = sys.argv[1]
    if status == "preprocess":
        mapper()
    elif status == "gene_edge":
        generate_edge()
    else:
        generate_edge_dianbo()