# -*- coding: utf-8 -*-

"""
File: data_process_sv.py
Author: xiaolikai
Date: 2022/08/15 16:01:30
Desc: 图召回时处理短视频数据
"""
import io
import os
import sys
import json
from operator import itemgetter
from itertools import groupby


def parse_stdin(stdin):
    """
        验证输入是否合理
    """
    for line in stdin:
        message = line.strip().split('\t')
        if len(message) != 6:
            continue
        yield message

def parse_input(path):
    """
        接受本地输入，验证脚本有效性
    """
    with open(path, 'r') as fr:
        for line in fr:
            line = line.strip().split('\t')
            if len(line) != 6:
                print("error  ", len(line))
                continue
            yield line


def main():
    """
        主函数将一个session中的resource id按照时间顺序排序 生成 edge信息
    """ 
    for _, session in groupby(parse_stdin(sys.stdin), itemgetter(0)):
        session = list(session)
        edges = []
        for idx in range(len(session) - 1):
            _, edge_s, _, _, _, _ = session[idx]
            _, edge_e, _, _, _, _ = session[idx + 1]
            edge_start = "SV_" + edge_s
            edge_end = "SV_" + edge_e
            if edge_start != edge_end and "IDEA" not in edge_start and "IDEA" not in edge_end:
                edges.append([edge_start, edge_end, '1'])
        for edge in edges:
            print('\t'.join(edge))


if __name__ == "__main__":
    main()