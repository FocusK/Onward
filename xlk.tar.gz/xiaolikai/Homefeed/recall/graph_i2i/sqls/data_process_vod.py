# -*- coding: utf-8 -*-

"""
File: data_process_vod.py
Author: xiaolikai
Date: 2022/10/10 20:37:30
Desc: 图召回时处理长视频数据
"""
import io
import os
import sys
import json
import time
from operator import itemgetter
from itertools import groupby

def parse_stdin(stdin):
    """
        验证输入是否合理
    """
    for line in stdin:
        message = line.strip().split('\t')
        if len(message) != 3:
            continue
        yield message


def generate_edge():
    """
        针对长视频场景,生成边数据
    """
    for _, session in groupby(parse_stdin(sys.stdin), itemgetter(0)):
        session = list(session)
        edges = []
        for idx in range(len(session) - 1):
            _, node_s, _ = session[idx]
            _, node_e, _ = session[idx + 1]
            node_s = "VD_" + node_s
            node_e = "VD_" + node_e
            if node_s != node_e:
                edges.append([node_s, node_e, '1'])
        for edge in edges:
            print('\t'.join(edge))


if __name__ == '__main__':
    generate_edge()