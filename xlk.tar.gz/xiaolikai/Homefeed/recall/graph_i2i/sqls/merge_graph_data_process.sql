udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_merge_graph_data_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';

add file ./id2sign.py;

-- 合并各场景数据,并转换成sign值
create external table if not exists graph_edge_table
(
    edge_s string,  -- 边的起点
    edge_e string,  -- 边的终点
    edge_w string -- 边的权重
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_edge";

insert overwrite table graph_edge_table partition (event_day='${hivevar:dst_day}')
select
    transform(ta.*)
using 'python id2sign.py gene_sign_edge'
as (edge_s, edge_e, edge_w)
from(
    select
        edge_s, edge_e, edge_w
    from raw_sv_graph_edge
    where event_day="${hivevar:dst_day}"
    union all
    select
        edge_s, edge_e, edge_w
    from raw_mu_graph_edge
    where event_day="${hivevar:dst_day}"
    union all 
    select
        edge_s, edge_e, edge_w
    from raw_vod_graph_edge
    where event_day="${hivevar:dst_day}"
    union all 
    select
        edge_s, edge_e, edge_w
    from raw_au_graph_edge
    where event_day="${hivevar:dst_day}"
)ta;

-- 生成最终的结点信息(sign值形式)
create external table if not exists graph_node_table
(
    node_type string,  -- 结点类型
    node_id string
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_node";

insert overwrite table graph_node_table partition (event_day='${hivevar:dst_day}')
select
    distinct t.node_type, t.node_id
from(
    select
        'i' as node_type,
        edge_s as node_id
    from graph_edge_table
    where event_day="${hivevar:dst_day}"
    union all
    select
        'i' as node_type,
        edge_e as node_id
    from graph_edge_table
    where event_day="${hivevar:dst_day}"
)t;

-- 基于原始边信息，生成id2sign的映射
create external table if not exists graph_id2sign_table
(
    id string, 
    sign string
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_id2sign";

insert overwrite table graph_id2sign_table partition (event_day='${hivevar:dst_day}')
select
    transform(b.*)
using 'python id2sign.py id2sign'
as (id, sign)
from(
    select
        distinct a.node_id as node
    from(
            select edge_s as node_id
            from raw_sv_graph_edge
            where event_day="${hivevar:dst_day}"
            union all
            select edge_s as node_id
            from raw_mu_graph_edge
            where event_day="${hivevar:dst_day}"
            union all 
            select edge_s as node_id
            from raw_vod_graph_edge
            where event_day="${hivevar:dst_day}"
            union all 
            select edge_s as node_id
            from raw_au_graph_edge
            where event_day="${hivevar:dst_day}"
            union all 
            select  edge_e as node_id
            from raw_sv_graph_edge
            where event_day="${hivevar:dst_day}"
            union all
            select edge_e as node_id
            from raw_mu_graph_edge
            where event_day="${hivevar:dst_day}"
            union all 
            select edge_e as node_id
            from raw_vod_graph_edge
            where event_day="${hivevar:dst_day}"
            union all 
            select edge_e as node_id
            from raw_au_graph_edge
            where event_day="${hivevar:dst_day}"
    )a   
)b;




-- create external table if not exists raw_sv_graph_edge
-- (
--     edge_s string,  -- 边的起点
--     edge_e string,  -- 边的终点
--     edge_w string -- 边的权重
-- ) partitioned BY (event_day string)
-- row format delimited fields terminated by '\t'
-- location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/shortvideo/raw_edge";

-- -- 生成原始边数据
-- insert overwrite table raw_sv_graph_edge partition (event_day='${hivevar:endDate}')
-- select
--     transform(tb.*)
-- using 'python data_process.py'
-- as (edge_s, edge_e, edge_w)
-- from(
--     select ta.*
--     from(
--         select
--             logid_trigger,
--             resource_id,
--             start_time,
--             play_seconds,
--             is_finished,
--             play_num
--         from udw_ns.default.duer_idw_bot_detail
--         where event_day>="${hivevar:startDate}" and event_day <= "${hivevar:endDate}"
--             and source_type = "ai.dueros.bot.short_video"
--             and logid_trigger <> "" and resource_id <> ""
--             and resource_id not like "%[a-zA-Z]%"
--             and (get_json_object(play_params,"$.recommend_type") in ("23", "15", "2", "7", "6") or query_demand_type = "intervene_by_as")
--             and start_time <> "" and play_num <> ""
--             and play_seconds <> "" and cast(play_seconds as int) >= 60
--     )ta
--     distribute by ta.logid_trigger
--     sort by ta.logid_trigger, ta.start_time
-- )tb;

-- -- 生成处理后的边数据
-- create external table if not exists sv_graph_edge
-- (
--     edge_s string,  -- 边的起点
--     edge_e string,  -- 边的终点
--     edge_w string -- 边的权重
-- ) partitioned BY (event_day string)
-- row format delimited fields terminated by '\t'
-- location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/shortvideo/edge";

-- insert overwrite table sv_graph_edge partition (event_day='${hivevar:endDate}')
-- select
--     transform(ta.*)
-- using 'python sign.py'
-- as (edge_s, edge_e, edge_w)
-- from(
--     select
--         edge_s, edge_e, edge_w
--     from raw_sv_graph_edge
--     where event_day="${hivevar:endDate}"
-- )ta;

-- -- 生成结点信息
-- create external table if not exists sv_graph_node
-- (
--     node_type string,  -- 结点类型
--     node_id string
-- ) partitioned BY (event_day string)
-- row format delimited fields terminated by '\t'
-- location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/shortvideo/node";

-- insert overwrite table sv_graph_node partition (event_day='${hivevar:endDate}')
-- select
--     distinct t.node_type, t.node_id
-- from(
--     select
--         'u' as node_type,
--         edge_s as node_id
--     from sv_graph_edge
--     where event_day="${hivevar:endDate}"
--     union all
--     select
--         'u' as node_type,
--         edge_e as node_id
--     from sv_graph_edge
--     where event_day="${hivevar:endDate}"
-- )t;

-- -- 基于原始边信息，生成id2sign的映射
-- drop table if exists sv_graph_id2sign;
-- create external table if not exists sv_graph_id2sign
-- (
--     id string, 
--     sign string
-- ) partitioned BY (event_day string)
-- row format delimited fields terminated by '\t'
-- location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/shortvideo/id2sign";

-- insert overwrite table sv_graph_id2sign partition (event_day='${hivevar:endDate}')
-- select
--     transform(b.*)
-- using 'python id2sign.py'
-- as (id, sign)
-- from(
--     select
--         distinct a.node_id
--     from(
--         select edge_s as node_id
--         from raw_sv_graph_edge
--         where event_day="${hivevar:endDate}"
--         union all
--         select edge_e as node_id
--         from raw_sv_graph_edge
--         where event_day="${hivevar:endDate}"
--     )a   
-- )b;