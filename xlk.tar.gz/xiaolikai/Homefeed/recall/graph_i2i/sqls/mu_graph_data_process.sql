udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_graph_mu_data_process_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';
create TEMPORARY FUNCTION row_number_by_sort as 'org.apache.hadoop.hive.ql.udf.UDFRowNumberByPreSort';

ADD FILE ./data_process_mu.py;
ADD FILE ./id2sign.py;

-- 加载原始数据
-- create external table if not exists music_detail_log_daily
-- (
--     logid string,
--     appid string,
--     cuid string,
--     userid string,
--     query string,
--     domain string,
--     intent string,
--     slot string,
--     rec_type string,
--     recommend_tag string,
--     query_time string,
--     song_info string,
--     rs_feature string,
--     voice_info string
-- ) partitioned BY (event_day string)
-- row format delimited fields terminated by '\t'
-- location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaofeng05/music_dat/daily_voice_info_adult";

-- 将xiaofeng数据读入hive表
alter table music_detail_log_daily add partition(event_day='${hivevar:dst_day}')
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaofeng05/music_dat/daily_voice_info_adult/${hivevar:dst_day}";

-- 进行数据预处理
create external table if not exists process_music_raw_data
(
    userid string,
    query_time string,
    rec_type string,
    wanbo_song string
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/mu_raw_data";

-- 数据预处理
insert overwrite table process_music_raw_data partition (event_day='${hivevar:dst_day}')
select
    transform(ta.*)
using 'python data_process_mu.py preprocess'
as (userid, query_time, rec_type, wanbo_song)
from music_detail_log_daily ta
where event_day>='${hivevar:start_day}' and event_day<='${hivevar:dst_day}';

-- 建图
drop table if exists raw_mu_graph_edge;
create external table if not exists raw_mu_graph_edge
(
    edge_s string,  -- 边的起点
    edge_e string,  -- 边的终点
    edge_w string -- 边的权重
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/raw_graph_data/mu";

insert overwrite table raw_mu_graph_edge partition (event_day='${hivevar:dst_day}')
select
    td.edge_s as edge_s,
    td.edge_e as edge_e,
    sum(cast(td.edge_w as int)) as edge_w
from(
    select
        transform(ta.wanbo_song)
    using 'python data_process_mu.py gene_edge'
    as (edge_s, edge_e, edge_w)
    from process_music_raw_data ta
    where event_day='${hivevar:dst_day}'
        and rec_type != "2"
    union all
    select
        transform(tc.*)
    using 'python data_process_mu.py gene_edge_dianbo'
    as (edge_s, edge_e, edge_w)
    from(
        select
            tb.userid, tb.query_time, tb.wanbo_song
        from process_music_raw_data tb
        where event_day<='${hivevar:dst_day}'
            and rec_type == "2"
            distribute by userid
            sort by userid, query_time
    )tc
)td
group by td.edge_s, td.edge_e;


-- 转换sign值
create external table if not exists mu_graph_edge_table
(
    edge_s string,  -- 边的起点
    edge_e string,  -- 边的终点
    edge_w string -- 边的权重
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_edge/mu";

insert overwrite table mu_graph_edge_table partition (event_day='${hivevar:dst_day}')
select
    transform(ta.*)
using 'python id2sign.py gene_sign_edge'
as (edge_s, edge_e, edge_w)
from(
    select
        edge_s, edge_e, edge_w
    from raw_mu_graph_edge
    where event_day="${hivevar:dst_day}"
)ta;

-- 生成最终的结点信息(sign值形式)
create external table if not exists mu_graph_node_table
(
    node_type string,  -- 结点类型
    node_id string
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_node/mu";

insert overwrite table mu_graph_node_table partition (event_day='${hivevar:dst_day}')
select
    distinct t.node_type, t.node_id
from(
    select
        'i' as node_type,
        edge_s as node_id
    from mu_graph_edge_table
    where event_day="${hivevar:dst_day}"
    union all
    select
        'i' as node_type,
        edge_e as node_id
    from mu_graph_edge_table
    where event_day="${hivevar:dst_day}"
)t;

-- 基于原始边信息，生成id2sign的映射
create external table if not exists mu_graph_id2sign_table
(
    id string, 
    sign string
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_id2sign/mu";

insert overwrite table mu_graph_id2sign_table partition (event_day='${hivevar:dst_day}')
select
    transform(b.*)
using 'python id2sign.py id2sign'
as (id, sign)
from(
    select
        distinct a.node_id as node
    from(
            select edge_s as node_id
            from raw_mu_graph_edge
            where event_day="${hivevar:dst_day}"
            union all 
            select edge_e as node_id
            from raw_mu_graph_edge
            where event_day="${hivevar:dst_day}"
    )a   
)b;
