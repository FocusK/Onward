"""
    Desc: 对global idi的数据进行后处理, 取出短视频资源的top k 相似资源
    Date: 2022-12-07 20:48
"""
# -*- coding: utf-8 -*-
import os
import sys
import json

def data_process(global_i2i_path, final_file_path):
    """
        数据处理函数
        arg: global_i2i_path: i2i文件的路径
            final_file_path: 生成文件的保存路径
    """
    with open(final_file_path, 'w') as final_file:
        with open(global_i2i_path, 'r') as i2i_file:
            for line in i2i_file:
                key, value = line.strip('\n').split('\t')
                v_json = json.loads(value)
                for ele in v_json["resource_ids"]:
                    sim_id, sim_score = ele.split(':')
                    if float(sim_score) >= 3.0:
                        final_file.writelines('\t'.join([key[3:], sim_id[3:]]) + '\n')

if __name__ == '__main__':
    path_prefix = '/home/work/xiaolikai/baidu/personal-code/xiaolikai/Homefeed/recall/'
    global_i2i_path = path_prefix + 'graph_i2i/global_i2i_with_score/global_i2i_recom_dict_with_score'
    final_file_path = path_prefix + 'post_process_data/post_data.data'
    data_process(global_i2i_path, final_file_path)


