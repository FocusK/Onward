udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_sv_graph_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';
create TEMPORARY FUNCTION row_number_by_sort as 'org.apache.hadoop.hive.ql.udf.UDFRowNumberByPreSort';

ADD FILE ./data_process_sv.py;
ADD FILE ./id2sign.py;

create external table if not exists raw_sv_graph_edge
(
    edge_s string,  -- 边的起点
    edge_e string,  -- 边的终点
    edge_w string -- 边的权重
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/raw_graph_data/shortvideo";

-- 生成原始边数据
insert overwrite table raw_sv_graph_edge partition (event_day='${hivevar:dst_day}')
select
    tc.edge_s as edge_s,
    tc.edge_e as edge_e,
    sum(cast(tc.edge_w as int)) as edge_w
from(
    select
        transform(tb.*)
    using 'python data_process_sv.py'
    as (edge_s, edge_e, edge_w)
    from(
        select ta.*
        from(
            select
                logid_trigger,
                resource_id,
                start_time,
                play_seconds,
                is_finished,
                play_num
            from udw_ns.default.duer_idw_bot_detail
            where event_day>="${hivevar:start_day}" and event_day<="${hivevar:dst_day}"
                and source_type = "ai.dueros.bot.short_video"
                and logid_trigger <> "" and resource_id <> ""
                and resource_id not like "%[a-zA-Z]%"
                and start_time <> "" and play_num <> ""
                and play_seconds <> "" and cast(play_seconds as int) >= 60
        )ta
        distribute by ta.logid_trigger
        sort by ta.logid_trigger, ta.start_time
    )tb
)tc
group by tc.edge_s, tc.edge_e;

-- 转换sign值
create external table if not exists sv_graph_edge_table
(
    edge_s string,  -- 边的起点
    edge_e string,  -- 边的终点
    edge_w string -- 边的权重
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_edge/shortvideo";

insert overwrite table sv_graph_edge_table partition (event_day='${hivevar:dst_day}')
select
    transform(ta.*)
using 'python id2sign.py gene_sign_edge'
as (edge_s, edge_e, edge_w)
from(
    select
        edge_s, edge_e, edge_w
    from raw_sv_graph_edge
    where event_day="${hivevar:dst_day}"
)ta;

-- 生成最终的结点信息(sign值形式)
create external table if not exists sv_graph_node_table
(
    node_type string,  -- 结点类型
    node_id string
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_node/shortvideo";

insert overwrite table sv_graph_node_table partition (event_day='${hivevar:dst_day}')
select
    distinct t.node_type, t.node_id
from(
    select
        'i' as node_type,
        edge_s as node_id
    from sv_graph_edge_table
    where event_day="${hivevar:dst_day}"
    union all
    select
        'i' as node_type,
        edge_e as node_id
    from sv_graph_edge_table
    where event_day="${hivevar:dst_day}"
)t;

-- 基于原始边信息，生成id2sign的映射
create external table if not exists sv_graph_id2sign_table
(
    id string, 
    sign string
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/final_graph_id2sign/shortvideo";

insert overwrite table sv_graph_id2sign_table partition (event_day='${hivevar:dst_day}')
select
    transform(b.*)
using 'python id2sign.py id2sign'
as (id, sign)
from(
    select
        distinct a.node_id as node
    from(
            select edge_s as node_id
            from raw_sv_graph_edge
            where event_day="${hivevar:dst_day}"
            union all 
            select edge_e as node_id
            from raw_sv_graph_edge
            where event_day="${hivevar:dst_day}"
    )a   
)b;