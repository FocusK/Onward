#coding:utf-8
import io
import os
import sys

def line_process(line):
    """
     func:  处理给定的明文信息
     input: {aaa}:{bbb}:slot
     output: substr(bbb)
    """
    lines = line.strip('\n').split(':')
    if lines[0][1:-1] == "item_id":
        return lines[1][1:3]
    else:
        return lines[1][1:-1]

def process_recaller(line):
    lines = line.strip('\n').split(':')
    recallers = set(lines[1][1:-1].split(","))

    return list(recallers)


def local_test():
    """
    func: 用于本地测试
    """
    file = sys.argv[1]
    with open(file, 'r') as f:
        for line in f:
            if line[:4] != "text":
                continue
            lines = line.strip('\n').split('\t')
            if (len(lines) != 2):
                continue
            # 仅保留有用的明文信息
            messages = lines[1].strip('\n').split(' ')
            if (len(messages) != 4):
                continue
            cate = line_process(messages[0])
            recaller = line_process(messages[1])
            play_second = line_process(messages[2])
            logid = line_process[messages[3]]
            print(cate + '\t' + recaller + '\t' + play_second + '\t' + logid)


def main():
    """
    func:配合Hadoop streaming处理数据
    """
    for line in sys.stdin:
        if line[:4] != "text":
            continue
        lines = line.strip('\n').split('\t')
        if len(lines) != 2:
            continue
        # 仅保留有用的明文信息
        messages = lines[1].strip('\n').split(' ')
        if len(messages) != 4:
            continue
        cate = line_process(messages[0])
        recallers = process_recaller(messages[1])
        play_second = line_process(messages[2])
        # logid = line_process(messages[3])
        for recaller in recallers:
            print(cate + '\t' + recaller + '\t' + play_second)

if __name__=="__main__":
    main()
        

