#!bin/bash
source ~/.bashrc

workPath=`pwd`;
logs_path="${workPath}/logs"
bin_path="/home/work/xiaolikai/baidu/personal-code/xiaolikai/Homefeed/recall/recall_ctr/bin";
fe_path="/home/work/xiaolikai/baidu/personal-code/xiaolikai/Homefeed/recall/recall_ctr/fe";
hf_file_name="/home/work/xiaolikai/baidu/personal-code/xiaolikai/Homefeed/recall/recall_ctr/src/example.data"
hf_sign="hf_train.data"
if [ ! -d "$logs_path" ]; then
    mkdir $logs_path
fi

log=${logs_path}/check_data.log
# # 指定 rec_type，生成json
cat ${hf_file_name} | ${bin_path}/adapter -format=b64_zstd -json -rec_type=hf > "./hf_sample.json"

# 生成 feasign
cat ${hf_file_name} | ${bin_path}/adapter -format=b64_zstd -pb -rec_type=hf | ${bin_path}/feature-extract -conf_dir=${fe_path} > ${hf_sign}
