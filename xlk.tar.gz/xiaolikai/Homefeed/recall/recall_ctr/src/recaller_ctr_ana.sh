#!bin/bash
source ~/.bashrc

##### common header #####
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
src_path=${workPath}/src;
extract_conf_path="${workPath}/fe/*";
adapter_bin_path="${workPath}/bin/adapter";
extract_bin_path="${workPath}/bin/feature-extract";
process_file="${workPath}/src/data_process.py";

trans_sample_to_pb="./adapter -format=b64_zstd -pb -rec_type=hf"
extract_pb_to_feature="./feature-extract -conf_dir=./"

python_env=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/music_rec_pipeline/update_tar/python3_tf.tar.gz

dst_day=$1
if [ ! -n "$1" ];then
    dst_day=$(date -d "last day" + %Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)
# begin_day=$(date -d "$dst_day - 11 day" +%Y%m%d)

# 创建当日log文件夹
dst_log_path="${workPath}/logs/${dst_day}"
if [ ! -d $dst_log_path  ];then
  mkdir -p $dst_log_path
fi

###### fe预处理原始dump数据 #####
input_sample_path="${input_sample_path} -input /user/dumi/duer/dumi_bot_rec/homefeed_sample_dump/feedback_data/homefeed_feedback_sample/event_day=$dst_day"
output_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recaller_sources_ana/event_day=$dst_day"

# hpxlk streaming \
#     -D stream.map.input.ignoreKey=true \
#     -D mapred.job.name=duer_hf_rec_recaller_ctr_ana_${dst_day}_by_xiaolikai \
#     -D mapred.map.tasks=500 \
#     -D mapred.map.priority=300 \
#     -D mapred.reduce.tasks=100 \
#     -D mapred.job.reduce.capacity=100 \
#     -D mapred.textoutputformat.ignoreseparator=true \
#     -cacheArchive ${python_env}\#lib \
#     -file $adapter_bin_path \
#     -file $extract_bin_path \
#     -file $extract_conf_path \
#     -file $process_file \
#     $input_sample_path \
#     -output $output_path \
#     -mapper "$trans_sample_to_pb | $extract_pb_to_feature" \
#     -reducer "lib/python3/bin/python3 data_process.py" > "${dst_log_path}/recaller_ana_${dst_day}.log" 2>&1

# # ###### 基于hive分析各路召回的ctr数据 ######
cd ${src_path}
# hive_log="${dst_log_path}/hive_process.log"
# qexlk -f recaller_ctr_ana.sql --hivevar currentDate=${curDate} beginDate=${dst_day} endDate=${dst_day} >$hive_log 2>&1

##### 下载数据到本地进行处理 #####
hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/recall_ctr_ana/event_day=$dst_day"
local_path="/home/work/xiaolikai/baidu/personal-code/xiaolikai/Homefeed/recall/recall_ctr/src/$dst_day.txt"
py_log="${dst_log_path}/py_post_process.log"
{
  hk -getmerge $hadoop_path $local_path
  py3 visualize.py $local_path
} > ${py_log} 2>&1





