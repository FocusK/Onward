udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

SET mapred.job.map.capacity=500;
SET mapred.job.reduce.capacity=500;
SET mapred.reduce.tasks=100;
SET mapred.job.priority=NORMAL;
SET mapred.job.name = duer_strategy_duer_hf_recaller_ctr_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;

SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;
add CACHEARCHIVE afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/tools/python3.tar.gz;

-- hadoop straming生成的原始数据
-- drop table if exists hf_origin_recaller_data;
create external table if not exists hf_origin_recaller_data
(
    category string,
    recaller_source string,
    play_seconds int
)partitioned by (event_day string)
row format delimited fields terminated by '\t'
location 'afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recaller_sources_ana';

alter table hf_origin_recaller_data add partition(event_day='${hivevar:endDate}')
location 'afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recaller_sources_ana/event_day=${hivevar:endDate}';

-- 处理后的召回评估表
create external table if not exists duer_hf_recaller_ctr_table
(
    recaller_source string,
    category string,
    show_times int,
    click_times int,
    ctr float
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location 'afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/recall_ctr_ana';

insert overwrite table duer_hf_recaller_ctr_table partition (event_day='${hivevar:endDate}')
select
    ta.recaller_source as recaller_source,
    ta.category as category,
    count(is_click) as show_times,
    sum(is_click) as click_times,
    sum(is_click) / count(is_click) as ctr
from(
    select
        recaller_source,
        category,
        case when play_seconds > 0 then 1 else 0 end as is_click
    from hf_origin_recaller_data
    where event_day<='${hivevar:endDate}' and event_day>='${hivevar:beginDate}'
) ta
group by recaller_source, category
order by recaller_source, category;

