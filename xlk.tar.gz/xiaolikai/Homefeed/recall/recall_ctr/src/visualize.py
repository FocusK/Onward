"""
可视化形式对比hf多路召回
"""
import os
import sys
import matplotlib.pyplot as plt


def draw_bar(data, title, xlabel, ylabel, filename):
    """
    绘制条状图
    """
    x_data = [ele[0] for ele in data]
    y_data = [ele[1] for ele in data]
    plt.figure(figsize=(20, 18), dpi=100)
    plt.bar(x_data, y_data, width=0.3, color=['red','green','blue','cyan','yellow','gray'])
    plt.xticks(x_data, rotation=90)
    plt.xlabel(xlabel, fontsize=16)
    plt.ylabel(ylabel, fontsize=20)

    for idx in range(len(y_data)):
        plt.text(idx, y_data[idx] + 0.5, "%s" % y_data[idx], va="center")
    plt.title(title, fontsize=20)
    plt.savefig(filename)


def read_file(file_path):
    """
    读取召回源数据文件, 统计出show click ctr 包括recaller粒度和category粒度
    """
    total_show, total_click, total_ctr = {}, {}, {}
    sv_show, sv_click = {}, {} # 各路召回对于sv的ctr
    mu_show, mu_click = {}, {} # 各路召回对于mu的ctr
    au_show, au_click = {}, {} # 各路召回对于au的ctr
    vd_show, vd_click = {}, {} # 各路召回对于vd的ctr
    with open(file_path, "r") as f:
        for line in f:
            recaller, cate, show, click, ctr = line.strip('\n').split('\t')
            # recaller粒度的ctr
            total_show[recaller] = total_show.get(recaller, 0) + int(show)
            total_click[recaller] = total_click.get(recaller, 0) + int(click)
            if cate == "SV":
                sv_show[recaller] = sv_show.get(recaller, 0) + int(show)
                sv_click[recaller] = sv_click.get(recaller, 0) + int(click)
            elif cate == "MU":
                mu_show[recaller] = mu_show.get(recaller, 0) + int(show)
                mu_click[recaller] = mu_click.get(recaller, 0) + int(click)
            elif cate == "VD":
                vd_show[recaller] = vd_show.get(recaller, 0) + int(show)
                vd_click[recaller] = vd_click.get(recaller, 0) + int(click)
            elif cate == "AU":
                au_show[recaller] = au_show.get(recaller, 0) + int(show)
                au_click[recaller] = au_click.get(recaller, 0) + int(click)
    
    print("#####  综合情况下 各路召回效果对比 #####")
    total_data = []
    for key, value in total_show.items():
        total_data.append([key, value, total_click.get(key), total_click.get(key, 0) / value])
    total_data = sorted(total_data, key=lambda x: x[3], reverse=True)
    print('%-35s\t%-12s\t%-12s\t%-12s' % ("recaller", "show", "click", "ctr"))
    for r, s, c, ctr in total_data:
        print('%-35s\t%-10s\t%-10s\t%-10s' % (r, s, c, ctr))
    
    print("\n")
    print("#####  仅考虑短视频资源 各路召回效果对比 #####")
    sv_data = []
    for key, value in sv_show.items():
        sv_data.append([key, value, sv_click.get(key), sv_click.get(key, 0) / value])
    sv_data = sorted(sv_data, key=lambda x: x[3], reverse=True)
    print('%-35s\t%-12s\t%-12s\t%-12s' % ("recaller", "show", "click", "ctr"))
    for r, s, c, ctr in sv_data:
        print('%-35s\t%-10s\t%-10s\t%-10s' % (r, s, c, ctr))
    
    print("\n")
    print("#####  仅考虑音乐资源 各路召回效果对比 #####")
    mu_data = []
    for key, value in mu_show.items():
        mu_data.append([key, value, mu_click.get(key), mu_click.get(key, 0) / value])
    mu_data = sorted(mu_data, key=lambda x: x[3], reverse=True)
    print('%-35s\t%-12s\t%-12s\t%-12s' % ("recaller", "show", "click", "ctr"))
    for r, s, c, ctr in mu_data:
        print('%-35s\t%-10s\t%-10s\t%-10s' % (r, s, c, ctr))
    
    print("\n")
    print("#####  仅考虑长视频资源 各路召回效果对比 #####")
    vd_data = []
    for key, value in vd_show.items():
        vd_data.append([key, value, vd_click.get(key), vd_click.get(key, 0) / value])
    vd_data = sorted(vd_data, key=lambda x: x[3], reverse=True)
    print('%-35s\t%-12s\t%-12s\t%-12s' % ("recaller", "show", "click", "ctr"))
    for r, s, c, ctr in vd_data:
        print('%-35s\t%-10s\t%-10s\t%-10s' % (r, s, c, ctr))
    
    print("\n")
    print("#####  仅考虑有声资源 各路召回效果对比 #####")
    au_data = []
    for key, value in au_show.items():
        au_data.append([key, value, au_click.get(key), au_click.get(key, 0) / value])
    au_data = sorted(au_data, key=lambda x: x[3], reverse=True)
    print('%-35s\t%-12s\t%-12s\t%-12s' % ("recaller", "show", "click", "ctr"))
    for r, s, c, ctr in au_data:
        print('%-35s\t%-10s\t%-10s\t%-10s' % (r, s, c, ctr))

    
if __name__ == "__main__":
    file_path = sys.argv[1]
    read_file(file_path)
    

    # draw_bar(total, "0408_recaller_ctr", "recaller name", "ctr", "0408_recaller_ctr.png")
    # draw_bar(sv, "0408_sv_recaller_ctr", "recaller name", "ctr", "0408_sv_recaller_ctr.png")
    # draw_bar(mu, "0408_mu_recaller_ctr", "recaller name", "ctr", "0408_mu_recaller_ctr.png")
    # draw_bar(au, "0408_au_recaller_ctr", "recaller name", "ctr", "0408_au_recaller_ctr.png")
    # draw_bar(vd, "0408_vd_recaller_ctr", "recaller name", "ctr", "0408_vd_recaller_ctr.png")
