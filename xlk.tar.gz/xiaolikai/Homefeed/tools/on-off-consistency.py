"""
模型离在线一致性分析脚本

离线: 通过GPUPS模型的infer 对候选资源进行打分
在线: 加载训练的模型 通过Predictor对候选资源打分
"""

# -*- coding:utf-8 -*-
import requests
import os
import sys
import json

url = "http://10.153.195.12:8299/RecommendPredictorService/predict_by_user_and_id/RecommendPredictorService/predict_by_user_and_id"
headers = {
  'Content-Type': 'application/json'
}

homefeed_predictor_json = {
    "user": {
        "cuid": "951305E85CD00001510F",
        "userid": "7054321384"
    },
    "itemids": [
        "VD_mg_mobile_448901",
        "SV_8377183284797915931",
        "SV_4602362670141121438",
        "SV_16892600144772057617",
        "MU_923996cf92d00ab823ae04f1b1d858ef",
        "AU_96041063544",
        "SV_1628116861207162726",
        "AU_95735117029",
        "AU_96040825484",
        "SV_9981497932397686903",
        "SV_8486400193486960055",
        "MU_82b73db6043fdb84398282f374d587ba",
        "AU_96040736689",
        "SV_13121741685576048804",
        "MU_5730acbc64721d2766f2bedb7c070efc",
        "AU_96040503170",
        "SV_2733180644490326328",
        "SV_10584752198422940399",
        "MU_03257fb71a967efc9f53b355a37273b1",
        "AU_96040369018",
        "SV_7908657242565700535",
        "SV_8214515863477106699",
        "SV_8682665038090327701",
        "AU_95761200016",
        "SV_1824007254096824487",
        "AU_96040280066",
        "AU_96046126224",
        "SV_2253398944928638698",
        "VD_iqiyi_mobile_7061967311070301",
        "MU_ac4013d820793151d8081638bf9b12e2",
        "SV_13578446036960666359"
    ],
    "request_feature": {
        "refresh_timestamp": 1671691065,
        "appid": "dm1684B09E65141422",
        "client_id": "gZG8taAoLmRhSReVNYG7AeLGzHPTbBRe"
    },
    "queue": "homefeed",
    "token": "homefeed",
    "log_id": "1d66ec91-6a5b-461e-a407-037f005af07b_DCS-10-153-245-11-2037-0323150221-460470_0#1_0",
    "model_name": "paddle_homefeed_din",
    "model_ver": "v1",
    "is_new_model_type": True,
    "feature_extractor": "homefeed_din",
    "return_debug_info": True,
    "return_sign": True
}

if __name__ == '__main__':
    writer = open("part-00001", "w")
    payload = json.dumps(homefeed_predictor_json)
    response = requests.request("POST", url, headers=headers, data=payload)
    response_json = json.loads(response.text)

    instance = response_json["debug_sign"]["instance"]
    print(len(instance))
    
    for ins in instance:
        # 拼接离散特征  feasign:slot
        fea_slots = []
        for mess in ins["slot"]:
            for sign in mess["sign"]:
                fea_slots.append(str(sign) + ":" + str(mess["slot_id"]))
        sparse_feature_info = ' '.join(fea_slots)
        
        # 拼接连续特征 slot:feasign
        slot_feas = []
        for mess in ins["ebd_slot"]:
            slot_fea = str(mess["slot_id"])
            for val in mess["value"]:
                if val == 1.0:
                    slot_fea = slot_fea + ":1"
                elif val == 0.0:
                    slot_fea = slot_fea + ":0" 
                else:   
                    slot_fea = slot_fea + ":" + str(val)
            slot_feas.append(slot_fea)
        dense_feature_info = ' '.join(slot_feas)
        
        # 拼接生成训练样本
        show_click_info = "125e72efcd000101a926eb72a0088a54 1 0 1.000000"
        label_info = ""
        tag_info = ""

        final_sample = '\t'.join([show_click_info, sparse_feature_info, dense_feature_info, label_info, tag_info])
        # # 写入数据到txt
        writer.write(final_sample + '\n')

    # infer_data_path=sys.argv[1]
    # predictor_res_path=sys.argv[2]
    # generate_infer_data(infer_data_path, predictor_res_path)



    
    

