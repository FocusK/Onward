
import tensorflow as tf
from tensorflow.keras.layers import Layer, Dropout, Dense, Input

class MeanAggragator(Layer):
    def __init__(self, units, input_dim):
        super(MeanAggragator, self).__init__()
        self.input_dim = input_dim
        self.units = units

    def build(self):
        self.w = self.add_weight(shape=(self.input_dim, self.units), name='neigh_w')

        if self.use_bias:
            self.bias = self.add_weight(shape=(self.units), name='neigh_bias')
    
    def call(self, inputs):

        feas, node, neighbors = inputs
        # 第一步 获取表示向量
        node_fea = tf.nn.embedding_lookup(feas, node)
        neigh_fea = tf.nn.embedding_lookup(feas, neighbors)

        # 拼接 & mean
        concat_fea = tf.concat([node_fea, neigh_fea], axis=1)
        concat_mean = tf.reduce_mean(concat_fea, axis=1, keep_dim=False)

        # 非线性变换
        output = tf.matmul(concat_mean, self.w)
        if self.use_bias:
            output += self.bias
        
        output = tf.nn.relu(output)
        
        return output


class PoolingAggragator(Layer):
    def __init__(self, input_dim, units):
        self.input_dim = input_dim
        self.units = units
    

    def call(self, inputs):
        feas, node, neighbors = inputs
        
        node_fea = tf.nn.embedding_lookup(feas, node)
        neigh_feas = tf.nn.embedding_lookup(feas, neighbors)  

        dims = tf.shape(neigh_feas)
        bs = dims[0]
        num_neighbors = dims[1]
        # embedding_lookup查出来的是三维，但是Dense的输入是二维
        neigh_feas = tf.reshape(neigh_feas, (bs * num_neighbors, self.input_dim))
        # 过dense
        neigh_feas = Dense(units=dims[2], activation='relu')(neigh_feas)

        #  mean操作
        neigh_feas = tf.reduce_mean(neigh_feas, axis=1, keep_dim=False)

        # 拼接当前结点的特征
        output = tf.concat([neigh_feas, node_fea], axis=-1)
        
        # 非线性变换
        output = tf.matmul(output, self.w)

        if self.use_bias:
            output += self.bias
        return tf.nn.relu(output)


def GarphSAGE(feas_dim, neighbor_num, units, use_bias=True, activation=tf.nn.relu, aggregator="mean"):
    feas = Input(shape=(feas_dim,))
    node_input = Input(shape=(1,), dtype=tf.int32)
    neighbor_input = [Input(shape=(l,), dtype=tf.int32) for l in neighbor_num] # 保存k阶邻居

    if aggregator == "mean":
        aggragator = MeanAggragator
    else:
        aggregator = PoolingAggragator
    
    h = feas
    for i in range(0, len(neighbor_num)):









