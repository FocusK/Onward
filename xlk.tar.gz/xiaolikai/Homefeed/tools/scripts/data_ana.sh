#!bin/bash
source ~/.bashrc

######## common header ########
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
logPath=${workPath}/logs;
sqlPath=${workPath}/sqls;

# rm -rf ${logPath}
if [ ! -d $logPath  ];then
  mkdir -p $logPath
fi

######## 确定时间范围 ########
endDate=$1;
if [ ! -n "$1" ];then
    endDate=$(date -d "last day" +%Y%m%d)
fi
endDate=$(date -d "$endDate" +%Y%m%d)

echo "$endDate"
######## 生成当天数据 ########
log=${logPath}/behavior_type_ana_${endDate}.log;

cd ${sqlPath}
qexlk -f data_ana.sql --hivevar currentDate=${curDate} > ${log} 2>&1