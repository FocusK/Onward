-- 分析用户反馈数据中各类型的比例
udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_hf_data_dis_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';
create TEMPORARY FUNCTION row_number_by_sort as 'org.apache.hadoop.hive.ql.udf.UDFRowNumberByPreSort';

select
    action,
    count(1) as freq
from duer_ns.homefeed_user_show_feedback_detail_data_1d
where event_day='20230610'
group by action; 