# -*- coding=utf-8 -*-
"""
 辅助进行正负样本分析
"""

import os
import sys

if __name__ == '__main__':
    for line in sys.stdin:
        line = line.strip().split(' ')
        if len(line) != 4:
            continue
        print(line[2])