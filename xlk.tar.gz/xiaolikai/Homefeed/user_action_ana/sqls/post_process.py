"""
    Date: 2022-11-05
    Desc: 从sql数据中进一步分析用户的兴趣分布
"""
import os

statistic = [0, 0, 0, 0, 0, 0]  # 1 3 5 7 10 10+
def interest_nums(file):
    with open(file, 'r') as f:
        for line in f:
            line = line.strip().split('\t')
            if len(line) != 3:
                continue
            if int(line[2]) == 1:
                statistic[0] = statistic[0] + 1
            elif int(line[2]) <= 3:
                statistic[1] = statistic[1] + 1
            elif int(line[2]) <= 5:
                statistic[2] = statistic[2] + 1
            elif int(line[2]) <= 7:
                statistic[3] = statistic[3] + 1
            elif int(line[2]) <= 10:
                statistic[4] = statistic[4] + 1
            else:
                statistic[5] = statistic[5] + 1

if __name__ == '__main__':
    file = './event_day=20221114'
    interest_nums(file)
    print(statistic)

