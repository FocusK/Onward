#coding:utf-8
import io
import os
import sys
import json
from operator import itemgetter
from itertools import groupby


reload(sys)
sys.setdefaultencoding('utf8')

def parse_input(path):
    with open(path, 'r') as fr:
        for line in fr:
            line = line.strip().split('\t')
            if len(line) != 2:
                continue
            yield line


def parse_stdin(stdin):
    for line in stdin:
        message = line.strip().split('\t')
        if len(message) != 2:
            continue
        yield message

def main():
    # 根据user_id进行分组，统计es_tag信息
    for user_id, session in groupby(parse_stdin(sys.stdin), itemgetter(0)):
        user_interest_cate = set()
        for message in session:
            uid, category = message
            if category == "":
                continue
            # 取出当前资源的tag
            cates = category[1:-1].split(',')
            cates = [cate[1:-1] for cate in cates]
            for cate in cates:
                if cate != "":
                    user_interest_cate.add(cate)
            
        if len(user_interest_cate) > 0:
            user_interest_cate_list = list(user_interest_cate)
            print(user_id + "\t" + '_'.join(user_interest_cate_list) + "\t" + str(len(user_interest_cate_list)))

if __name__ == '__main__':
    main()