udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_user_interest_dis_mu_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';
create TEMPORARY FUNCTION row_number_by_sort as 'org.apache.hadoop.hive.ql.udf.UDFRowNumberByPreSort';

add file ./process_cate.py;

create external table if not exists user_interest_in_mu
(
    user_id string,
    interest_cate string,
    interest_cate_nums int
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/data_ana/mu";

insert overwrite table user_interest_in_mu partition (event_day="${hivevar:dst_day}")
select
    transform(origin.*)
using 'python process_cate.py'
as (userid, interest_cate, interest_cate_nums)
from(
    select
        td.userid as userid,
        td.category as category
    from(
        select
            user_his_table.userid as userid,
            tc.category as category
        from(   -- 选取每个用户最近消费过的50个资源
            select
                tb.userid,
                tb.resource_id,
                tb.start_time
            from(
                select
                    ta.userid,
                    ta.resource_id,
                    ta.start_time,
                    row_number_by_sort(ta.userid) as rank
                from(
                    select
                        userid,
                        resource_id,
                        start_time
                    from homefeed_user_show_feedback_detail_data_1d
                    where event_day>="${hivevar:start_day}" and event_day<="${hivevar:dst_day}"
                        and source_type = "ai.dueros.bot.short_video"
                        and cast(play_seconds as int) >= 60
                        distribute by userid
                        sort by userid, start_time desc
                )ta
            )tb
            where tb.rank <= 50
        )user_his_table
        inner join
        (
            select id, category
            from udw_ns.default.duer_bot_video_es_info
            where event_day>=date_sub(concat(substr("${hivevar:dst_day}", 1, 4), '-', substr("${hivevar:dst_day}", 5, 2), '-', substr("${hivevar:dst_day}", 7, 2)), 7) 
                and event_day<="${hivevar:dst_day}"
                and id is not null 
                and category is not null
        )tc
        on user_his_table.resource_id = tc.id
    )td
    distribute by td.userid
    sort by td.userid
)origin;

