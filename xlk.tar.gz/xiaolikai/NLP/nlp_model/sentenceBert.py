# -*- coding:utf-8 -*-
"""
    Desc: using bert4keras doing text match
    version: tf1.4 + keras2.3.1 + ber4keras0.11
"""
import os
import tensorflow as tf
import csv
import numpy as np
from bert4keras.backend import keras, set_gelu
from bert4keras.tokenizers import Tokenizer
from bert4keras.models import build_transformer_model
from bert4keras.optimizers import Adam
from bert4keras.snippets import sequence_padding, DataGenerator
from keras.layers import Dropout, Dense, Activation, Input, Subtract, Concatenate

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "4,5,6,7"

set_gelu('tanh')

maxlen = 128
batch_size = 256
config_path = '/home/ssd4/xiaolikai/my_code/pretrain_bert/bert_config.json'
checkpoint_path = '/home/ssd4/xiaolikai/my_code/pretrain_bert/bert_model.ckpt'
dict_path = '/home/ssd4/xiaolikai/my_code/pretrain_bert/vocab.txt'

def read_my_data(file_path):
    all_samples = []
    with open(file_path, 'r', errors='ignore') as f:
        for line in f:
            line = line.strip('\n').split('\t')
            if len(line) != 3:
                print('error, ', len(line), '  ', line)
                continue
            text1, text2, label = line[0], line[1], int(line[2])
            all_samples.append((text1, text2, label))
    return all_samples

train_data = read_my_data('/home/ssd4/xiaolikai/data/shortvideo/train.data')
test_data = read_my_data('/home/ssd4/xiaolikai/data/shortvideo/test.data')
valid_data = read_my_data('/home/ssd4/xiaolikai/data/shortvideo/test.data')

print('train data size is: ', len(train_data))
print(train_data[0])

# 建立分词器
tokenizer = Tokenizer(dict_path, do_lower_case=True)
text1 = train_data[0][0]
text2 = train_data[0][1]

token_ids, segment_ids = tokenizer.encode(text1, maxlen=maxlen)

class data_generator(DataGenerator):

    def __iter__(self, random=False):
        batch_token_ids1, batch_segment_ids1, batch_token_ids2, batch_segment_ids2, batch_labels = [], [], [], [], []
        for is_end, (text1, text2, label) in self.sample(random):
            token_ids1, segment_ids1 = tokenizer.encode(
                text1, maxlen=maxlen
            )
            token_ids2, segment_ids2 = tokenizer.encode(
                    text2, maxlen=maxlen
            )
            batch_token_ids1.append(token_ids1)
            batch_segment_ids1.append(segment_ids1)
            batch_token_ids2.append(token_ids2)
            batch_segment_ids2.append(segment_ids2)
            batch_labels.append([label])
            if len(batch_token_ids1) == self.batch_size or is_end:
                batch_token_ids1 = sequence_padding(batch_token_ids1)
                batch_segment_ids1 = sequence_padding(batch_segment_ids1)
                batch_token_ids2 = sequence_padding(batch_token_ids2)
                batch_segment_ids2 = sequence_padding(batch_segment_ids2)
                batch_labels = sequence_padding(batch_labels)
                yield [batch_token_ids1, batch_segment_ids1, batch_token_ids2, batch_segment_ids2], batch_labels
                batch_token_ids1, batch_segment_ids1, batch_token_ids2, batch_segment_ids2, batch_labels = [], [], [], [], []

# 加载预训练模型
bert = build_transformer_model(
    config_path=config_path,
    checkpoint_path=checkpoint_path,
    with_pool=True,
    return_keras_model=False,
)
print('bert is ', bert)
# 冻结预训练模型参数
for layer in bert.model.layers:
    #print(layer, '  ', type(layer))
    layer_name = str(layer.name)
    if layer_name.startswith('Emb') or layer_name.startswith('Trans'):
        layer.trainable = False
    print(layer_name, '\t', layer.trainable)

bert.model.summary()
print('####### ', bert.model.output)

encoder_output = Activation('relu')(bert.model.output)
encoder_output = Dense(units=256, activation='relu', kernel_initializer=bert.initializer, name='dnn_256')(encoder_output)
encoder_output = Dense(units=128, activation='relu', kernel_initializer=bert.initializer, name='dnn_128')(encoder_output)
encoder_output = Dense(units=64, kernel_initializer=bert.initializer, name='dnn_64')(encoder_output)
encoder_network = keras.models.Model(bert.model.input, encoder_output)

class SentenceBert(keras.Model):
    """
        基于bert的双塔模型,用于文本匹配任务
    """
    def __init__(self, encoder, hidden_layer, num_class, dropout_rate):
        ###### 定义输入 ######
        input_token1 = keras.layers.Input(shape=(None, ), dtype=tf.int32, name='Input_Token1')
        input_segment1 = keras.layers.Input(shape=(None, ), dtype=tf.int32, name='Input_Segment1')
        input_token2 = keras.layers.Input(shape=(None, ), dtype=tf.int32, name='Input_Token2')
        input_segment2 = keras.layers.Input(shape=(None, ), dtype=tf.int32, name='Input_Segment2')

        ###### 执行 ######
        text1_embedding = encoder([input_token1, input_segment1]) # text1输入给encoder
        text2_embedding = encoder([input_token2, input_segment2]) # text2输入给encoder
        w = Subtract()([text1_embedding, text2_embedding])
        print('text embeding shape: ', text2_embedding.shape)
        print('text w shape: ', w.shape)
        print('type of w is: ', type(w))
        output = Concatenate(axis=1)([text1_embedding, text2_embedding, w])
        output = Dropout(dropout_rate)(output)
        output = Dense(hidden_layer, activation='relu', kernel_initializer=bert.initializer)(output)
        output = Dense(num_class, activation='softmax', kernel_initializer=bert.initializer)(output)
        print('final output shape: ', output.shape)

        super(SentenceBert, self).__init__([input_token1, input_segment1, input_token2, input_segment2], output)

myModel = SentenceBert(encoder_network, 64, 2, 0.1)

myModel.summary()

myModel.compile(
    loss='sparse_categorical_crossentropy',
    optimizer=Adam(5e-5),
    metrics=['accuracy'],
)

# 转换数据集
train_generator = data_generator(train_data, batch_size)
valid_generator = data_generator(valid_data, batch_size)
test_generator = data_generator(test_data, batch_size)

# 获取产生器
#real_train_gene = train_generator.__iter__()
#print(type(real_train_gene))
#print(real_train_gene.__next__())

#print('test forfit')
#forfit = train_generator.forfit()
#print(type(forfit))
#print(forfit.__next__())

def evaluate(data):
    total, right = 0., 0.
    for x_true, y_true in data:
        y_pred = myModel.predict(x_true).argmax(axis=1)
        y_true = y_true[:, 0]
        total += len(y_true)
        right += (y_true == y_pred).sum()
    return right / total


class Evaluator(keras.callbacks.Callback):
    def __init__(self):
        self.best_val_acc = 0.

    def on_epoch_end(self, epoch, logs=None):
        val_acc = evaluate(valid_generator)
        if val_acc > self.best_val_acc:
            self.best_val_acc = val_acc
            myModel.save_weights('best_sbert.weights')
        test_acc = evaluate(test_generator)
        print(
            u'val_acc: %.5f, best_val_acc: %.5f, test_acc: %.5f\n' %
            (val_acc, self.best_val_acc, test_acc)
        )


evaluator = Evaluator()

myModel.fit_generator(
    train_generator.forfit(),
    steps_per_epoch=len(train_generator),
    epochs=5,
    callbacks=[evaluator]
)


print(u'final test acc: %05f\n' % (evaluate(test_generator)))

myModel.load_weights('best_sbert.weights')

# 测试单条数据
student_answer = '需要判断市场震荡幅度 股票'
standard_answer = '奥特曼大电影 奥特曼'
lines = []
lines.append((student_answer, standard_answer, None))
test_D = data_generator(lines, batch_size)

results = myModel.predict_generator(test_D.__iter__(), steps=len(test_D), verbose=1)
print("mode predict result is")
print(results)
max_score = max(results[0])
print(max_score)
label = np.argwhere(results[0] == max_score)[0][0]
print(label)