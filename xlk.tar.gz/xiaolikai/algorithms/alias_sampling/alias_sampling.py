# -*- coding: utf-8 -*-

"""
author: xiaolikai
data: 20220711
desc: alias采样法的实现
"""
import networkx as nx

data = "./data/graph"
G = nx.read_edgelist(data, data=(("weight", int),), create_using = nx.Graph())

for vertex in G.nodes():
    print(vertex)
    neighbor_weight_tuple_list = [(neighbor, G[vertex][neighbor]["weight"]) for neighbor in G.neighbors(vertex)]
    multinomial_values, edge_weight_list = zip(*neighbor_weight_tuple_list)
    
