#include <iostream>
#include <vector>
#include <unordered_map>

using namespace std;

/*
实现deepwalk算法，拆分为两个阶段
一、随机游走生成训练数据

二、调用skip-gram算法生成embed
*/

int nextNodeId(unordered_map<int, float>& matrix) {
    unordered_map<int, float> :: iterator it;
    int ans = it->first;  // 记录下一条的顶点id
    // 随机生成0 1 之间的浮点数;
    double r = rand()/double(RAND_MAX)
    // 根据p来决定下一跳
    for(it = matrix.begin(); it != matrix.end(); it++) {
        if(it->second > p) {
            ans = it->first;
            break;
        }
        else {  //减去当前边的score
            p = p - it->second;
        }
    }
    return ans;
}


void random_walk(unordered_map<int, unordered_map<int, float>> & matrix, vector<int>& nodesId, int walk_length) {
    vector<vector<int>> allPath;  // 记录所有的路径
    for(int i = 0; i < nodesId.size(); i++) {
        // 选定起始顶点id
        int nodeid = nodesId[i];
        // 选择跳转的点
        vector<int> path; // 记录单条路径
        path.push_back(nodeid);
        for(int j = 0; j < walk_length; j++) {
            // 取出起始顶点的邻接点信息
            unordered_map<int, float> nextNode = matrix[nodeid];
            // 每一次选择概率最大的顶点作为下一跳
            int nextHop = nextNodeId(nextNode);
            // 更新nodeid
            nodeid = nextHop;
            // 将nextHop保存到路径里面
            path.push_back(nodeid);
        }
        // 将路径保存到allPath
        allPath.push_back(path);
    }
}
