import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import Dense, Layer, Input, Model

# 定义均值Pooling聚合
class PoolingAggregator(Layer):
    def __init__(self, in_dims, out_dims):
        self.in_dims = in_dims
        self.out_dims = out_dims
    
    def build(self):
        # 定义dense 用于对邻居特征进行非线性变换
        self.dense = Dense(self.in_dims, activation='relu', use_bias=True)
        
        # 定义权重用于对拼接后的特征进行非线性变化
        self.w = self.add_weight(shape=(self.in_dim * 2, self.out_dims), initializer="random normal")    # 注意权重参数输入维度是2*in_dims
        self.b = self.add_weight(shape=(self.out_dims,))

    
    def call(self, src_embs, neighbor_embs):
        """
        :param: inputs 输入数据 包括特征 目标结点 邻居结点
        :param: neighbor_nums 该层每个节点采样的邻居数
        """
        # step1 对邻居结点的特征向量进行非线性变换
        bs = neighbor_embs.shape[0]
        neighbor_nums = neighbor_embs.shape[1]
        neighbor_embs = tf.reshape(neighbor_embs, (bs * neighbor_nums, self.in_dims))  # (bs*neighbor_nums, emb_dim)
        neighbor_embs = self.dense(neighbor_embs)   # (bs*neighbor_nums, self.in_dims)

        # step2 对非线性变换处理后的邻居特征向量进行mean pooling
        neighbor_embs = tf.reshape(neighbor_embs, (bs, neighbor_nums, self.in_dims))
        neighbor_embs = tf.reduce_mean(neighbor_embs, axis=1, keep_dim=False) # (bs, self.in_dims)

        # step3 拼接处理后的邻居特征与目标结点特征
        concated_embs = tf.concat([neighbor_embs, tf.squeeze(src_embs)], axis=1)    #(bs, self.in_dim*2)

        # step4 对拼接后的特征进行非线性变换
        out = tf.matmul(concated_embs, self.w) + self.b

        return tf.nn.relu(out)



class SampleAndAggragator1():
    def __init__(self, features, adj_map, sampling_nums, in_dim, hidden_dim):
        super(SampleAndAggragator, self).__init__()
        self.features = features  # 结点特征
        self.adj_map = adj_map  # 邻接矩阵
        self.sampling_nums = sampling_nums  # 每一层采样的结点数目
        self.aggregators = []
        # 两个聚合器
        self.aggregators.append(PoolingAggregator(in_dim, hidden_dim[0]))
        self.aggregators.append(PoolingAggregator(hidden_dim[0], hidden_dim[1]))

    
    def sample(self, dst_nodes, sampling_num):
        """
        进行单层采样
        """
        sampled_nodes = []
        for node in dst_nodes:
            neighbor_nodes = self.adj_map[node]
            if len(neighbor_nodes) < sampling_num:
                sampled_nodes.append(np.random.choice(neighbor_nodes, sampling_num, replace=True))
            else:
                sampled_nodes.append(np.random.choice(neighbor_nodes, sampling_num, replace=False))
        return sampled_nodes.flatten()
    
    def multi_sample(self, dst_nodes):
        """
        进行多层采样
        :param: dst_nodes 目标结点
        """
        samples = [dst_nodes]   # 保存目标结点和采样的邻居结点
        for i, num in enumerate(self.sampling_nums):
            samples.append(self.sample(samples[i], num))
        
        return samples
            
    def aggregator(self, samples):
        """
            聚合
        """
        hidden = [tf.nn.embedding_lookup(self.features, sample) for sample in samples]
        for l in range(len(self.sampling_nums)):
            next_hidden = []
            gcn = self.aggregator[l]    # 取出对应的聚合器
            for hop in range(len(self.sampling_nums) - l):
                h = gcn(hidden[hop], hidden[hop+1])
                next_hidden.append(h)
            hidden = next_hidden
        
        model = Model(inputs=samples, output=hidden[0])
        return model


class SampleAndAggregator(Model):
    def __init__(self, features, adj_map, in_dim, hidden_dims, sampling_nums):
        super(SampleAndAggregator, self).__init__()
        self.features = features
        self.adj_map = adj_map
        self.in_dim = in_dim
        self.sampling_nums = sampling_nums
        self.aggregator = []
        self.aggregator.append(PoolingAggregator(in_dim, hidden_dims[0]))
        self.aggregator.append(PoolingAggregator(hidden_dims[0], hidden_dims[1]))
    
    def call(self, inputs):
        """
        :param: inputs [[目标结点] [一阶邻居结点] [二阶邻居结点]]
        """
        # 取出结点特征
        feats = [tf.embedding_lookup(self.features, nodes) for nodes in inputs]

        # 聚合
        hidden = feats
        for l in range(len(self.sampling_nums)):
            gcn = self.aggregator[l]
            next_hidden = []
            for hop in range(len(self.sampling_nums) - l):
                h = gcn(hidden[hop], hidden[hop+1])
                next_hidden.append(h)
            hidden = next_hidden
        return hidden[0]
            