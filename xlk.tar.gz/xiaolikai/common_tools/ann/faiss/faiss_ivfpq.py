#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
# 
# Copyright (c) 2022 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: faiss_ivfpq.py
Author: xiaolikai(xiaolikai@baidu.com)
Date: 2022/09/06 10:04:30
Desc: the implementation of ann algorithm
"""
import os
import json

import faiss
import numpy as np


class Faiss(object):
    """
     implementation of faiss
    """
    def __init__(self, config_dict):
        self.embed_dim = config_dict.get("embed_dim", "64")
        self.nprobe = config_dict.get("nprobe", 10)
        self.measure_id = config_dict.get("measure_id", 0)
        self.top_k = config_dict.get("top_k", 50)
        self.embed_path = config_dict.get("embed_path", "embedding.dict")
        self.voc_path = config_dict.get("voc_path", "voc.dict")
        self.ann_file_local_path = config_dict.get("ann_file_local_path", "ann.dict")
        self.id2sign_path = config_dict.get("id2sign_path", "id2sign.dict")
        self.sign2id = {}
        try:
            self.embed_data = np.loadtxt(self.embed_path, dtype=np.float32)
        except Exception as e:
            print(e)
        try:
            self.voc_data = np.loadtxt(self.voc_path, dtype=str)
        except Exception as e:
            print(e)
        try:
            self.id2sign = open(self.id2sign_path, "r")
        except Exception as e:
            print(e)
        else:
            lines = self.id2sign.readlines()
            for line in lines:
                eles = line.strip('\n').split('\t')
                if len(eles) != 2:
                    continue
                self.sign2id[str(eles[1])] = str(eles[0])

    def embed_recall(self):
        """
         run faiss-ivf and select top_k
        """
        print("Faiss Runing....")
        # measure = None
        # if self.measure_id == 0:
        #     measure = faiss.METRIC_L2
        # else:
        #     measure = faiss.METRIC_INNER_PRODUCT
        # 聚类中心为256 PQx中的x表示向量切分的段数
        # param = 'IVF256, PQ8'
        # index = faiss.index_factory(self.embed_dim, param, measure)
        quantizer = faiss.IndexFlatL2(self.embed_dim)
        index = faiss.IndexIVFPQ(quantizer, self.embed_dim, 256, 8, 8)
        index.train(self.embed_data)  # 索引训练
        # faiss.normalize_L2(self.embed_data)
        index.add(self.embed_data)    # 向量添加
        
        index.nprobe = self.nprobe
        distance, neighbor_ids = index.search(self.embed_data, self.top_k) #最近邻查找

        # 根据faiss训练结果保存最近邻到指定文件
        print("Save Ann....")
        with open(self.ann_file_local_path, 'w') as ann_file:
            for idx in range(len(neighbor_ids)):
                mess = neighbor_ids[idx]
                scores = [1.0 / float(ele) for ele in distance[idx]]
                key = str(self.voc_data[mess[0]])
                if key in self.sign2id:
                    key = self.sign2id[key]
                else:
                    continue
                item_list = [self.voc_data[idx] for idx in mess[1:]]
                # 不要score
                # item_list = [self.sign2id[str(item_list[index])] for index in range(len(item_list)) if str(item_list[index]) in self.sign2id]
                item_list = [self.sign2id[str(item_list[index])] + ":" + str(scores[index + 1])[:5] \
                        for index in range(len(item_list)) if str(item_list[index]) in self.sign2id]
                d = {"resource_ids": item_list}
                ann_file.writelines('\t'.join([key, json.dumps(d, ensure_ascii=False)]) + '\n')
            # for mess in neighbor_ids:
            #     key = str(self.voc_data[mess[0]])
            #     if key in self.sign2id:
            #         key = self.sign2id[key]
            #     else:
            #         print('MISS ', key)
            #         continue
            #     item_list = [self.voc_data[idx] for idx in mess[1:]]
            #     item_list = [self.sign2id[str(ele)] for ele in item_list if str(ele) in self.sign2id]
            #     d = {"resource_ids": item_list}
            #     ann_file.writelines('\t'.join([key, json.dumps(d, ensure_ascii=False)]) + '\n')
