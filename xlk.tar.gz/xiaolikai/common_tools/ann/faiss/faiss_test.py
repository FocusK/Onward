import numpy as np
import faiss

dim = 64
nb = 100000
nq = 10000   # 待检索query的数目
np.random.seed(1234)
xb = np.random.random((nb, dim)).astype('float32')
xb[:, 0] += np.arange(nb) / 1000.

xq = np.random.random((nq, dim)).astype('float32')
xq[:, 0] += np.arange(nq) / 1000.

############# 构建索引 ################
# index = faiss.IndexFlatL2(dim)
# print(type(index), '\t', index.is_trained)
# index.add(xb)
# print(index.ntotal) # 输出index中包含的响向量总数

# faiss.index_factory的使用
# measure = faiss.METRIC_L2
# param = 'Flat'
# index = faiss.index_factory(dim, "Flat")
# index.train(xb)
# index.add(xb)
# print(index.is_trained)
nlist = 100  # 聚类中心的数目
m = 8  # 向量压缩成8bit

quantizer = faiss.IndexFlatL2(dim)
index = faiss.IndexIVFPQ(quantizer, dim, nlist, m, 8)
index.nprobe = 10 # 查找聚类中心的个数
index.train(xb)
index.add(xb)
# D, I = index.search(xq, )

# TopK相似向量检索
k = 4
D, I = index.search(xq, k) # xq为待检索向量, I为每个待检索query最相似TopK的索引list, D为对应的距离
print(I[:5])
print(D[:5])