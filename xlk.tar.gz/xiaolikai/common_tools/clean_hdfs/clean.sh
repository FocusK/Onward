#!/bin/bash
source ~/.bashrc
BASEDIR=$(cd `dirname $0`; pwd)

dst_day=$1
if [ ! -n "$1" ];then
    dst_day=$(date -d "last day" +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)
log="/home/work/xiaolikai/baidu/personal-code/xiaolikai/common_tools/clean_hdfs/logs/$dst_day.log"

{
    overdue_day=`date -d"$dst_day - 3 day" +"%Y%m%d"`;
    hadoop_path="/user/dumi/duer/dumi_bot_rec/music_rec_pipeline/cache_dir/*$overdue_day*"
    hk -rmr ${hadoop_path}

    # 删除过期数据
    overdue_day=`date -d"$dst_day - 40 day" +"%Y%m%d"`;
    hadoop_path="/user/dumi/duer/dumi_bot_rec/homefeed_sample_dump/feedback_data/homefeed_user_show_feedback/event_day=$overdue_day"
    hk -rmr ${hadoop_path}

    hadoop_path="/user/dumi/duer/dumi_bot_rec/homefeed_sample_dump/feedback_data/homefeed_user_show_feedback_detail_data_1d/event_day=$overdue_day"
    hk -rmr ${hadoop_path}

    hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/hf_feature_depository/HomefeedRankFeatures/item_base_feature_7d/event_day=$overdue_day"
    hk -rmr ${hadoop_path}

    hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/hf_feature_depository/HomefeedRankFeatures/item_base_feature/event_day=$overdue_day"
    hk -rmr ${hadoop_path}

    hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/hf_feature_depository/HomefeedRankFeatures/item_base_feature_merged/event_day=$overdue_day"
    hk -rmr ${hadoop_path}

    hadoop_path="/user/dumi/duer/dumi_bot_rec/raoxiantuo/common/feature_dump_data/$overdue_day"
    hk -rmr ${hadoop_path}

    hadoop_path="/user/dumi/duer/dumi_bot_rec/raoxiantuo/short_video/short_video_user_profile/30_day/$overdue_day"
    hk -rmr ${hadoop_path}

    hadoop_path="/user/dumi/duer/dumi_bot_rec/luyan11/music/ufs_voice/up_proprecess_daily_voice/dt=$overdue_day"
    hk -rmr ${hadoop_path}

    hadoop_path="/user/dumi/duer/dumi_bot_rec/homefeed_sample_dump/train_data_mmoe/event_day=$overdue_day"
    hk -rmr ${hadoop_path}


    hk -rmr /trash/dumi_bot_rec/*
} > ${log} 2>&1


