import matplotlib as mpl
import matplotlib.pyplot as plt

mpl.rcParams["font.sans-serif"]=["SimHei"]
mpl.rcParams["axes.unicode_minus"]=False

kinds="=1","2-3","4-5","5-7","8-10", "10+"

colors=["#F96900","#F1EA0C","#90F10C","#0CF1CB","#C00CF1","#F10C7E"]

soldNums=[0.326,0.380,0.154,0.07,0.043,0.027]

plt.pie(soldNums,
        labels=kinds,
        autopct="%3.1f%%",
        startangle=60,
        colors=colors)
plt.title("User Interest Distribution In SV")

plt.show()
plt.savefig('pie.png')
