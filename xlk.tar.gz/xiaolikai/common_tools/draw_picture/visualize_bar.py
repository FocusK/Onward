# -*- coding: utf-8 -*-
"""
    File: visualize_bar.py
    Author: Xiao Likai
    Date: 2022-09-21 20:33
    Desc: given data, this coding will draw bar
"""
import os
import matplotlib.pyplot as plt
import numpy as np

def drawing(y_data, title, x_lable, y_lable, x_data=None):
    """
        x_data: if not provided, x_data will be [1,2,...,y_data.size()]
        y_data: essential, like [2,6,9,1]
    """
    if x_data is None:
        x_data = [i for i in range(len(y_data))]
    for idx in range(len(x_data)):
        plt.bar(x_data[idx], y_data[idx])
    for x, y in zip(x_data, y_data):
        plt.text(x, y+0.1, "%d" % y, ha = 'center')

    plt.title(title)
    plt.xlabel(x_lable)
    plt.ylabel(y_label)
    plt.show()
    plt.savefig("%s.png" % title)

if __name__ == "__main__":
    y_data = [0, 19478618, 43312479, 53796383, 5900985]
    x_data = ["<1min", "1-3min", "3-10min", "10-30min", "30min+"]
    title = "vod_play_seconds_distribution"
    x_label = "play seconds(min)"
    y_label = "nums"
    drawing(y_data, title, x_label, y_label, x_data)