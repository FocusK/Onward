"""Global Utilities Functions
"""
import numpy as np
import os
import sys
import json
import time
import collections
import math

def is_hadoop_path(path, hadoop_bin, fs_name, fs_ugi):
    if path.startswith("hdfs") or path.startswith("afs"):
        return True
    elif hadoop_bin or fs_name or fs_ugi:
        return True
    else:
        return False

def smart_list_files(path, hadoop_bin=None, fs_name=None, fs_ugi=None):
    file_list = []
    if is_hadoop_path(path, hadoop_bin, fs_name, fs_ugi):
        if hdfs_dir_exists(path, hadoop_bin, fs_name, fs_ugi):
            for filename in hdfs_ls(path, 
                    hadoop_bin=hadoop_bin, 
                    fs_name=fs_name, fs_ugi=fs_ugi):
                file_list.append(filename)
        elif hdfs_exists(path, hadoop_bin, fs_name, fs_ugi):
            file_list.append(path)
        else:
            raise ValueError("%s is not existed!" % path)
    else:
        if os.path.isdir(path):
            files = os.listdir(path)
            for filename in files:
                filename = os.path.join(path, filename)
                file_list.append(filename)
        elif os.path.exists(path):
            file_list.append(path)
        else:
            raise ValueError("%s is not existed!" % path)

    return file_list

def smart_open_file(file_list, hadoop_bin=None, fs_name=None, fs_ugi=None):
    if not isinstance(file_list, list):
        file_list = [file_list]
    if is_hadoop_path(file_list[0], hadoop_bin, fs_name, fs_ugi):
        for filename in file_list:
            for line in hdfs_file_open(filename, 
                                    hadoop_bin=hadoop_bin, 
                                    fs_name=fs_name, 
                                    fs_ugi=fs_ugi):
                yield line
    else:
        for filename in file_list:
            with open(filename) as f:
                for line in f:
                    yield line

def hdfs_ls(path, hadoop_bin, fs_name, fs_ugi):
    """ hdfs_ls """
    cmd = hadoop_bin + " fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -ls " + path
    cmd += " | grep part | awk '{print $8}'"
    filelist = os.popen(cmd).read().split()
    return filelist


def hdfs_exists(path, hadoop_bin, fs_name, fs_ugi):
    """ hdfs_exists """
    cmd = hadoop_bin + " fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -test -e " + path + " 2>/dev/null ; echo $?"
    ret = int(os.popen(cmd).read().strip())
    if ret == 0:
        return True
    return False

def hdfs_dir_exists(path, hadoop_bin, fs_name, fs_ugi):
    """ hdfs_exists """
    cmd = hadoop_bin + " fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -test -d " + path + " 2>/dev/null ; echo $?"
    ret = int(os.popen(cmd).read().strip())
    if ret == 0:
        return True
    return False

def hdfs_replace(src, dest, fs_name, fs_ugi):
    """ hdfs_replace """
    tmp = dest + "_" + str(int(time.time()))
    cmd = "hadoop fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -mv " + dest + " " + tmp + " && "

    cmd += " hadoop fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -put " + src + " " + dest + " && "

    cmd += " hadoop fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -rmr " + tmp
    ret = os.system(cmd)
    return ret

def hdfs_mv(src, dest, fs_name, fs_ugi):
    """ hdfs_replace """
    if hdfs_exists(dest):
        hdfs_rm(dest)
    cmd = "hadoop fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -mv " + src + " " + dest

    ret = os.system(cmd)
    return ret

def hdfs_rm(path, fs_name, fs_ugi):
    cmd = "hadoop fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -rmr " + path

    ret = os.system(cmd)
    return ret

def hdfs_append(filename, dest, fs_name, fs_ugi):
    """ hdfs_append """
    cmd = "hadoop fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -appendToFile " + filename + " " + dest
    ret = os.system(cmd)
    return ret


def hdfs_cat(filename, fs_name, fs_ugi):
    """ hdfs_cat """
    cmd = "hadoop fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -cat " + filename + " 2>hdfs.err"
    p = os.popen(cmd)
    return p.read().strip()


def hdfs_file_open(filename, hadoop_bin, fs_name, fs_ugi):
    """ hdfs_file_open """
    file_type = filename.split(".")[-1]
    if file_type == "gz":
        return hdfs_gz_file_open(filename, hadoop_bin, fs_name, fs_ugi)
    else:
        cmd = hadoop_bin + " fs -D fs.default.name=" + fs_name
        cmd += " -D hadoop.job.ugi=" + fs_ugi
        cmd += " -cat " + filename + " 2>hdfs.err"
        p = os.popen(cmd)
        return p

def hdfs_gz_file_open(filename, hadoop_bin, fs_name, fs_ugi):
    """ hdfs_file_open """
    cmd = hadoop_bin + " fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -text " + filename + " 2>hdfs.err"
    p = os.popen(cmd)
    return p


def hdfs_download(src, dest, fs_name, fs_ugi):
    """ hdfs_download """
    cmd = "hadoop fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -get " + src + " " + dest
    ret = os.system(cmd)
    return ret


def hdfs_upload(src, dest, fs_name, fs_ugi):
    """ hdfs_upload """
    cmd = "hadoop fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -put " + src + " " + dest
    ret = os.system(cmd)
    return ret


def hdfs_mkdir(path, fs_name, fs_ugi):
    """ hdfs_mkdir """
    # mkdir
    cmd = "hadoop fs -D fs.default.name=" + fs_name
    cmd += " -D hadoop.job.ugi=" + fs_ugi
    cmd += " -mkdir " + path
    ret = os.system(cmd)
    return ret
