#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
File: config_load.py
Author: xiaolikai
Date: 2022/08/09 15:07:30
Desc: 加载配置文件
"""

import os
import warnings
import yaml

cur_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(cur_dir)
# 默认的配置文件路径
default_conf_dir = os.path.join(root_dir, 'conf')


def load_yaml(yaml_path, fail_error=True):
    if os.path.isfile(yaml_path):
        with open(yaml_path) as f:
            config_dict = yaml.safe_load(f)
            if config_dict is None:
                config_dict = {}
    elif fail_error:
        raise FileNotFoundError(yaml_path)
    else:
        _log_s = f"conf 文件不存在: {yaml_path}"
        warnings.warn(_log_s)
        config_dict = {}
    return config_dict


def load_conf(conf_name, conf_dir=None):
    if not conf_dir:
        conf_dir = default_conf_dir
    config_yaml = os.path.join(conf_dir, conf_name)
    return load_yaml(config_yaml, fail_error=False)


def load_model_config(category, mode, model_name, conf_dir=None):
    return load_conf(f'{category}/{mode}/{model_name}.yaml', conf_dir=conf_dir)


def load_sv_db(conf_dir=None):
    return load_conf('sv_db.yaml', conf_dir=conf_dir)