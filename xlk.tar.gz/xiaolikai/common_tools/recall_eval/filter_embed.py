#-*- coding: utf-8 -*-
import os
import sys
import six
import yaml
import glob
import tqdm
import shutil
import random
import logging
import datetime
import warnings
from multiprocessing import Pool,Manager
from easydict import EasyDict as edict

import hdfs_util

def load_target_nid(filename, config):
    """
    format: ntype \t nid  or  nid\n
    """
    nid_list = []
    file_list = hdfs_util.smart_list_files(filename, 
                                    config.hadoop_bin,
                                    config.fs_name,
                                    config.fs_ugi)

    for line in hdfs_util.smart_open_file(file_list,
                                    config.hadoop_bin,
                                    config.fs_name,
                                    config.fs_ugi):
        fields = line.strip().split("\t")
        if len(fields) == 2:
            nid_list.append(fields[1])
        else:
            nid_list.append(fields[0])

    return nid_list

def filter_embedding(config, target_nid_list, embed_file_list, output_file, worker_index):
    """
    Args:
        target_nid_list: list of target node id
        embed_file_list(list of string): format: nid \t vec
    """

    target_nid_set = set(target_nid_list)

    nid2vec = {}
    with open(output_file, "w") as fout:
        iterator = hdfs_util.smart_open_file(embed_file_list, 
                                  config.hadoop_bin,
                                  config.fs_name,
                                  config.fs_ugi)
        for line in tqdm.tqdm(iterator, position=worker_index, leave=False):
            fields = line.strip().split("\t")
            node_id = fields[0]
            if node_id in target_nid_set:
                fout.write("%s\t%s\n" % (node_id, fields[1]))


def multi_process_filter_embedding(config, nid_path, mode):
    """
    Args:
        mode: user or item
    """
    target_nid_list = load_target_nid(nid_path, config)
    print("total %s target_nid of %s" % (len(target_nid_list), mode))

    output_path = os.path.join(config.work_dir, "%s_embed" % mode)
    if os.path.exists(output_path):
        shutil.rmtree(output_path)
    os.makedirs(output_path)

    file_list = hdfs_util.smart_list_files(config.embed_path, 
            config.hadoop_bin, 
            config.fs_name, 
            config.fs_ugi)
    print("total embedding files: %s" % len(file_list))

    num_process = min(config.num_process, len(file_list))

    splited_file_list = [[] for _ in range(num_process)]
    for index, f in enumerate(file_list):
        part = index % num_process
        splited_file_list[part].append(f)

    pool = Pool(num_process)
    for p in range(num_process):
        output_file = os.path.join(output_path, "part-%05d" % p)
        fs = splited_file_list[p]
        pool.apply_async(filter_embedding,
                (config, target_nid_list, fs, output_file, p))

    pool.close()
    pool.join()


if __name__=="__main__":

    with open(sys.argv[1]) as f:
        config = edict(yaml.load(f, Loader=yaml.FullLoader))

    print("filter item embedding")
    multi_process_filter_embedding(config, config.item_nid_path, mode="item")
    print("filter user embedding")
    multi_process_filter_embedding(config, config.user_nid_path, mode="user")

