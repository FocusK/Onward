#-*- coding: utf-8 -*-
import os
import sys
import json
import time
import math
import tqdm
import yaml
import pickle as pkl
import numpy as np
import pandas as pd
import warnings
from annoy import AnnoyIndex
from collections import Counter, defaultdict
from multiprocessing import Pool, Manager
from easydict import EasyDict as edict

from util import AnnTree, load_user_history_clk, load_embedding

def recall_items_batch(nodeID2recalls, nodeID_list, recall_num, worker_index):
    for node_id in tqdm.tqdm(nodeID_list, position=worker_index, desc="recalling items", leave=False):
        recall_list = annIndex.get_nns_by_nodeID(node_id, recall_num)
        nodeID2recalls[node_id] = [r for r in recall_list if r != node_id]
    return nodeID2recalls

def recall_items(annIndex, nodeID_list, num_process=10, recall_num=10):
    manager = Manager()
    nodeID2recalls = manager.dict()

    splited_nodeID_list =[[] for _ in range(num_process)]
    for index, nid in enumerate(nodeID_list):
        part = index % num_process
        splited_nodeID_list[part].append(nid)

    pool = Pool(num_process)
    for i in range(num_process):
        node_list = splited_nodeID_list[i]
        pool.apply_async(recall_items_batch,
                (nodeID2recalls, node_list, recall_num, i))
    pool.close()
    pool.join()
    my_nodeID2recalls = {}
    my_nodeID2recalls.update(nodeID2recalls)
    return my_nodeID2recalls

def icf_eval_worker(nodeID_list, history_num, worker_index):
    rec_and_clk_cnt = 0
    total_recall_cnt = 0
    total_clk_cnt = 0
    for target_node_id in tqdm.tqdm(nodeID_list, position=worker_index, desc="icf", leave=False):
        his_clk_items = user2clk_items[target_node_id]
        clk_items_for_recall = his_clk_items[:history_num]
        clk_items_for_valid = his_clk_items[history_num:]

        rec_items = []
        for item in clk_items_for_recall:
            try:
                rec_items.extend(nodeID2recalls[item])
            except:
                continue

        rec_items = set(rec_items)
        clk_items_for_valid = set(clk_items_for_valid)
        rec_and_clk_cnt += len(rec_items & clk_items_for_valid)
        total_recall_cnt += len(rec_items)
        total_clk_cnt += len(clk_items_for_valid)

    return {"total_recall_cnt": total_recall_cnt,
            "total_clk_cnt": total_clk_cnt,
            "rec_and_clk_cnt": rec_and_clk_cnt}

if __name__=="__main__":
    with open(sys.argv[1]) as f:
        config = edict(yaml.load(f, Loader=yaml.FullLoader))

    print("loading user history click")
    user2clk_items = load_user_history_clk(config, config.user_clk_path)
    target_nodeID_list = list(user2clk_items.keys())

    #============================= ICF =========================================#

    item_embed_path = os.path.join(config.work_dir, "item_embed")
    item2vec = load_embedding(item_embed_path)
    print("total %s items have been loaded" % len(item2vec))

    print("building ann tree")
    annIndex = AnnTree(item2vec)

    print("recalling items")
    item_id_list = list(item2vec.keys())
    nodeID2recalls = recall_items(annIndex, item_id_list, recall_num=config.recall_num)

    print("\nicf evaluation")
    rec_and_clk_cnt = 0
    total_recall_cnt = 0
    total_clk_cnt = 0

    splited_nodeID_list = [[] for _ in range(config.num_process)]
    for index, nid in enumerate(target_nodeID_list):
        part = index % config.num_process
        splited_nodeID_list[part].append(nid)

    results = []
    pool = Pool(config.num_process)
    for i in range(config.num_process):
        res = pool.apply_async(icf_eval_worker, 
            (splited_nodeID_list[i], config.history_num, i))
        results.append(res)
    pool.close()
    pool.join()
    for res in results:
        res = res.get()
        total_recall_cnt += res["total_recall_cnt"]
        total_clk_cnt += res["total_clk_cnt"]
        rec_and_clk_cnt += res["rec_and_clk_cnt"]

    P = float(rec_and_clk_cnt) / (total_recall_cnt + 1e-5)
    R = float(rec_and_clk_cnt) / (total_clk_cnt + 1e-5)
    f1 = 2 * P * R / (P + R + 1e-5)

    res = "\n%s | P: %.4f | R: %.4f | f1: %.4f" % ("icf", P, R, f1)
    print(res)


