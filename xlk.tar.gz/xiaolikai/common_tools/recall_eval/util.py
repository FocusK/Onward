#-*- coding: utf-8 -*-
import os
import importlib, sys
importlib.reload(sys)
sys.path.append(os.path.abspath(__file__).rsplit('/', 2)[0])
import json
import time
import math
import tqdm
import yaml
import pickle as pkl
import numpy as np
import pandas as pd
import warnings
from annoy import AnnoyIndex
from collections import Counter, defaultdict
from multiprocessing import Pool, Manager
from easydict import EasyDict as edict

from hdfs_tool.hdfs_util import smart_list_files, smart_open_file

def build_ann_tree(nodeID2vec, vec_dim):
    """
    Args:
        nodeID2vec(dict): {"node_id": vec}
        vec_dim(int): dimension of vec
    """

    annIndex = AnnoyIndex(vec_dim, "angular")  # Length of item vector that will be indexed
    idx2nodeID = {}
    nodeID2idx = {}
    for idx, (node_id, vec) in tqdm.tqdm(enumerate(nodeID2vec.items())):
        annIndex.add_item(idx, vec)
        idx2nodeID[idx] = node_id
        nodeID2idx[node_id] = idx

    annIndex.build(50)

    return annIndex, nodeID2idx, idx2nodeID


class AnnTree(object):
    def __init__(self, nodeID2vec):
        nids = list(nodeID2vec.keys())
        vec_dim = len(nodeID2vec[nids[0]])
        print("vec_dim", vec_dim)
        ann, n2i, i2n = build_ann_tree(nodeID2vec, vec_dim)
        self.annIndex = ann
        self.nodeID2idx = n2i
        self.idx2nodeID = i2n

    def get_nns_by_nodeID(self, node_id, recall_num=10):
        if node_id not in self.nodeID2idx:
            warnings.warn("%s is not in AnnTree.nodeID2idx" % node_id)
            return []
        idx = self.nodeID2idx[node_id]
        recall_list = self.annIndex.get_nns_by_item(idx, recall_num)
        recall_res = [self.idx2nodeID[r] for r in recall_list]
        return recall_res

    def get_nns_by_query(self, query, n, search_k=-1, include_distances=False):
        recall_list = self.annIndex.get_nns_by_vector(query, n, search_k, include_distances)
        recall_res = [self.idx2nodeID[r] for r in recall_list]
        return recall_res

def load_user_history_clk(config, file_or_dir):
    """
    format: user item1 item2
    """
    user2clk_items = defaultdict(list)
    file_list = smart_list_files(file_or_dir, 
                                config.hadoop_bin,
                                config.fs_name,
                                config.fs_ugi)

    for line in smart_open_file(file_list,
                                config.hadoop_bin,
                                config.fs_name,
                                config.fs_ugi):
        fields = line.strip().split()
        user, clk_items = fields[0], fields[1:]
        for i in fields[1:]:
            user2clk_items[user].append(i)

    return user2clk_items


def load_embedding(file_or_dir, hadoop_bin=None, fs_name=None, fs_ugi=None):
    nid2vec = {}
    file_list = smart_list_files(file_or_dir, 
                                hadoop_bin=hadoop_bin,
                                fs_name=fs_name,
                                fs_ugi=fs_ugi)
    for line in smart_open_file(file_list,
                                hadoop_bin,
                                fs_name,
                                fs_ugi):
        fields = line.strip().split("\t")
        embed = [float(i) for i in fields[1].split(" ")]
        nid2vec[fields[0]] = embed

    return nid2vec
