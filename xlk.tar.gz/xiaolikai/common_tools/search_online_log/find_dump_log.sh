#!/bin/bash

# find dump sample according logid
source ~/.bashrc
BASEDIR=$(cd `dirname $0`; pwd)

curDate=`date +"%Y%m%d"`
dst_day=$1
if [ ! -n "$1" ];then
    dst_day=$(date -d "last day" +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)

# 创建当日log文件夹
dst_log_path="${BASEDIR}/log_sample_build/${dst_day}"
if [ ! -d $dst_log_path  ];then
  mkdir -p $dst_log_path
fi

sv_user_feedback="/user/dumi/duer/dumi_bot_rec/xiaolikai/sv_feature_depository/user_feedback_detail/event_day=${dst_day}"
sv_sample_dump=/app/dt/minos/201082096/70072283/${dst_day}/*/*

output_sample=/user/dumi/duer/dumi_bot_rec/xiaolikai/temp/event_day=${dst_day}

function sample_build() {

hpxlk streaming \
    -D mapred.job.name=duer_sv_rec_build_sample_${dst_day}_by_xiaolikai \
    -D mapred.map.tasks=1500 \
    -D mapred.map.priority=1000 \
    -D mapred.reduce.tasks=100 \
    -D mapred.job.reduce.capacity=300 \
    -input $sv_sample_dump \
    -output $output_sample \
    -file ${BASEDIR}/sv_fslog_proc_mapper \
    -mapper "sv_fslog_proc_mapper" \
    -reducer "cat"
}

sample_build > "${dst_log_path}/sv_rec_build_sample_${dst_day}.log" 2>&1

