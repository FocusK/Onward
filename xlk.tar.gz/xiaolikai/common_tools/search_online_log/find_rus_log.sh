#!/bin/bash

# @file find_rus_log.sh
# @author: xiaolikai

function find_rus_log {
    if [ $# -ne 3 ] && [ $# -ne 4 ] ; then
        echo "Invalid input. arg1 keyword, arg2 log_type(notice or wf or stat), arg3 log_time(now or specified date-hour), (opt)arg4 machine_room."
        echo "eg1:sh find_rus_log.sh c3c6a3a37-a674-4737-9ca7-53438da78abf_DCS-10-216-91-148-19644-0818114058-8068610_0#1_0 rpc time hd"
        echo "eg2:sh find_rus_log.sh 714d08f8a4fb49559745b268648c04e0_2 stat now"
        exit
    fi
    declare -A RsShortVideoBNS=(
        ["hb"]="group.opera-online-DuRus-all-hb.dumi.all"
        ["hd"]="group.opera-online-DuRus-all-hd.dumi.all"
        ['hn']="group.opera-online-DuRus-all-hn.dumi.all"
        ['sh']="group.opera-online-DuRus-all-sh.dumi.all"
    ) 
    TEMPFILE=$(mktemp $$.XXXXXXXXXXXX) || exit 1
    trap 'rm -rf ${TEMPFILE}' exit

    for singleBNS in ${!RsShortVideoBNS[@]}
        do
            if [ $# -eq 4 ] && [ $4 != $singleBNS ] ; then
            continue
            fi 
            get_instance_by_service -e -D ${RsShortVideoBNS[$singleBNS]} >> ${TEMPFILE} 
        done  

    while read line; do
        host=$(echo $line | awk '{print $2}' | awk -F '.AIG' '{print $1}')
        log_path=$(echo $line | awk '{print $3}')"/log/"
        echo $host
        echo $log_path

        if [ $3 == 'now' ] ; then
            time=''
        else
            time='.'$3
        fi

        if [ $2 == 'request' ] ; then
            file_name='request.log'
        elif [ $2 == 'rpc' ] ; then
            file_name='rpc.log'
        else
            file_name='rpc.log.wf'
        fi
        echo 'Searching '$host':'${log_path}${file_name}${time}':'

        ssh --matrix -n -o "StrictHostKeyChecking no" $host "grep "$1" "${log_path}${file_name}${time}
        echo -e "\n"
    done < ${TEMPFILE}
}

find_sv_log