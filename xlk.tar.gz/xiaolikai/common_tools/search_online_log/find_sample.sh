#!/bin/bash

source ~/.bashrc
BASEDIR=$(cd `dirname $0`; pwd)

curDate=`date +"%Y%m%d"`

cd $BASEDIR
qexlk -f find_sample.sql --hivevar curDate=${curDate} > "raw_sample.log" 2>&1