udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
set wing.intermediate.reduce.tasks=100;
set mapred.job.name = 'duer_strategy_sv_raw_dump_sample_${hivevar:curDate}_by_xiaolikai';
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
SET dce.shuffle.enable=false;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;
add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;

drop table if exists sv_raw_sample;

create external table if not exists sv_raw_sample
(
    logid string, 
    tag string,
    raw_sample string
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/temp";

alter table sv_raw_sample add partition(event_day='20220831')
location 'afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/temp/event_day=20220831';

select 
    *
from sv_raw_sample
where event_day=20220831
    and logid in ("00208d3d-13f7-4057-9c71-0082bc7ba032_DCS-10-37-83-96-2065-0831162009-590954_6#1_0",
                "0077f475-a8a5-4c88-a5dc-bfe2d6aaed66_DCS-10-153-229-17-2025-0831183520-1219345_5#1_0",
                "007f8a36-a551-4056-b2ac-2c2bba7a76b3_DCS-10-37-84-95-2015-0831154410-1445100_7#1_0",
                "009eb416-2d86-459c-a49b-b1999b464dc4_DCS-10-37-65-203-2020-0831205955-4865007_0#1_0",
                "00f8ff87-e85d-41c6-b27d-2d9ebe72734d_DCS-10-37-84-95-2015-0831181634-1894003_18#1_0",
                "013e46d1-1ce0-44a6-b49b-1f3af145c815_DCS-10-37-107-168-2043-0831130238-470022_0#1_0",
                "0146615c-ff00-4fb4-827e-99e52715794a_DCS-10-36-241-144-2019-0831201323-5305043_0#2_0",
                "0149cbed-bf05-4cd9-9ed1-646b8fce12fe_DCS-10-38-209-204-2033-0831133722-1611402_8#1_0",
                "014ea731-8ae4-4088-a5c0-7e5dd12e48ec_DCS-10-162-12-34-2040-0831131722-1791182_0#2_0",
                "018f2996-0fed-4b5f-a329-857e386da0a4_DCS-10-163-18-140-2002-0831123857-17116581_10#1_0",
                "0196ee3c-53e0-4453-b6b5-be85ab64c183_DCS-10-163-201-159-2027-0831210940-18306661_9#1_0",
                "01c3e117-c4cb-405e-8513-57da0ebb703d_DCS-10-39-211-149-2038-0831171341-9562504_8#1_0",
                "023219e8-5ecb-4807-a97e-a777c355fea7_DCS-10-199-86-41-2008-0831090103-9755840_0#2_0",
                "0285308b-01a5-491e-a605-19a5bbef04cd_DCS-10-102-107-33-2038-0831185942-14452036_0#2_0",
                "029c7ca6-6994-4214-b7dd-3fc9a43938f7_DCS-10-182-98-150-2032-0831122744-687732_6#1_0",
                "02cf0c65-3cb4-4d20-8e69-ce31b9f36082_DCS-10-162-64-155-8629-0831192444-18046348_0#2_0",
                "00e1bf1a-8971-46c6-b759-24b6959932ff_DCS-10-162-179-12-2020-0831221012-18507048_0#1_0",
                "00a2d684-28b9-48d5-a860-70018c44ab72_DCS-10-153-76-21-21954-0831210029-14326656_0#1_0"
            );



-- 查询指定logid的反馈数据
-- select 
--     *
-- from sv_user_feedback_detail
-- where event_day=20220831
--     and logid in ("00208d3d-13f7-4057-9c71-0082bc7ba032_DCS-10-37-83-96-2065-0831162009-590954_6#1_0",
--                 "0077f475-a8a5-4c88-a5dc-bfe2d6aaed66_DCS-10-153-229-17-2025-0831183520-1219345_5#1_0",
--                 "007f8a36-a551-4056-b2ac-2c2bba7a76b3_DCS-10-37-84-95-2015-0831154410-1445100_7#1_0",
--                 "009eb416-2d86-459c-a49b-b1999b464dc4_DCS-10-37-65-203-2020-0831205955-4865007_0#1_0",
--                 "00f8ff87-e85d-41c6-b27d-2d9ebe72734d_DCS-10-37-84-95-2015-0831181634-1894003_18#1_0",
--                 "013e46d1-1ce0-44a6-b49b-1f3af145c815_DCS-10-37-107-168-2043-0831130238-470022_0#1_0",
--                 "0146615c-ff00-4fb4-827e-99e52715794a_DCS-10-36-241-144-2019-0831201323-5305043_0#2_0",
--                 "0149cbed-bf05-4cd9-9ed1-646b8fce12fe_DCS-10-38-209-204-2033-0831133722-1611402_8#1_0",
--                 "014ea731-8ae4-4088-a5c0-7e5dd12e48ec_DCS-10-162-12-34-2040-0831131722-1791182_0#2_0",
--                 "018f2996-0fed-4b5f-a329-857e386da0a4_DCS-10-163-18-140-2002-0831123857-17116581_10#1_0",
--                 "0196ee3c-53e0-4453-b6b5-be85ab64c183_DCS-10-163-201-159-2027-0831210940-18306661_9#1_0",
--                 "01c3e117-c4cb-405e-8513-57da0ebb703d_DCS-10-39-211-149-2038-0831171341-9562504_8#1_0",
--                 "023219e8-5ecb-4807-a97e-a777c355fea7_DCS-10-199-86-41-2008-0831090103-9755840_0#2_0",
--                 "0285308b-01a5-491e-a605-19a5bbef04cd_DCS-10-102-107-33-2038-0831185942-14452036_0#2_0",
--                 "029c7ca6-6994-4214-b7dd-3fc9a43938f7_DCS-10-182-98-150-2032-0831122744-687732_6#1_0",
--                 "02cf0c65-3cb4-4d20-8e69-ce31b9f36082_DCS-10-162-64-155-8629-0831192444-18046348_0#2_0",
--                 "00e1bf1a-8971-46c6-b759-24b6959932ff_DCS-10-162-179-12-2020-0831221012-18507048_0#1_0",
--                 "00a2d684-28b9-48d5-a860-70018c44ab72_DCS-10-153-76-21-21954-0831210029-14326656_0#1_0"
--             );