#!/bin/bash

# @file find_sv_online_log.sh
# @author: xiaolikai

function find_sv_log {
    if [ $# -ne 3 ] && [ $# -ne 4 ] ; then
        echo "Invalid input. arg1 keyword, arg2 log_type(notice or wf or stat), arg3 log_time(now or specified date-hour), (opt)arg4 machine_room."
        echo "eg1:sh find_sv_log.sh c3c6a3a37-a674-4737-9ca7-53438da78abf_DCS-10-216-91-148-19644-0818114058-8068610_0#1_0 sample time sv_hd"
        echo "eg2:sh search_vod_online_log.sh 714d08f8a4fb49559745b268648c04e0_2 stat now"
        exit
    fi
    declare -A RsShortVideoBNS=(
        ["sv_hb"]="group.opera-online-RsShortVideo-all-hb.dumi.all"
        ["sv_hd"]="group.opera-online-RsShortVideo-all-hd.dumi.all"
        ['sv_hn']="group.opera-online-RsShortVideo-all-hn.dumi.all"
        ['sv_sh']="group.opera-online-RsShortVideo-all-sh.dumi.all"
    ) 
    TEMPFILE=$(mktemp $$.XXXXXXXXXXXX) || exit 1
    trap 'rm -rf ${TEMPFILE}' exit

    for singleBNS in ${!RsShortVideoBNS[@]}
        do
            if [ $# -eq 4 ] && [ $4 != $singleBNS ] ; then
            continue
            fi 
            get_instance_by_service -e -D ${RsShortVideoBNS[$singleBNS]} >> ${TEMPFILE} 
        done  

    while read line; do
        host=$(echo $line | awk '{print $2}' | awk -F '.AIG' '{print $1}')
        log_path=$(echo $line | awk '{print $3}')"/log/"
        echo $host
        echo $log_path

        if [ $3 == 'now' ] ; then
            time=''
        else
            time='.'$3
        fi

        if [ $2 == 'notice' ] ; then
            file_name='recommend.log.notice'
        elif [ $2 == 'wf' ] ; then
            file_name='recommend.log.wf'
        else
            file_name='recommend.log.param'
        fi
        echo 'Searching '$host':'${log_path}${file_name}${time}':'

        ssh --matrix -n -o "StrictHostKeyChecking no" $host "grep "$1" "${log_path}${file_name}${time}
        echo -e "\n"
    done < ${TEMPFILE}
}
