#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
File: visualize.py
Author: xiaolikai
Date: 2022/08/09 14:05:30
Desc: 连接mysql
    https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/pKzJfZczuc/OT2ZirkLH-/R4-yO32sZXxdVT?source=102
"""

"""
    CREATE TABLE `author_follow_user_record` (
      `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增主键',
      `userid` varchar(64) NOT NULL DEFAULT '' COMMENT '用户id',
      `cuid` varchar(32) NOT NULL DEFAULT '' COMMENT '设备id',
      `app_id` varchar(32) NOT NULL DEFAULT '' COMMENT '作者id',
      `author_name` varchar(32) NOT NULL COMMENT '作者名称',
      `follow_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '关注状态',
      `add_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
      `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
      `extra_info` varchar(1024) NOT NULL DEFAULT '' COMMENT '额外信息字段json串描述',
      PRIMARY KEY (`id`),
      UNIQUE KEY `userid_cuid` (`userid`,`cuid`,`app_id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=150616645 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8 COMMENT='短视用户作者关注表'

    -------
    20211117
        总数目：1.5亿，153163571
        部分数据：['id', 'userid', 'cuid', 'app_id', 'author_name', 'follow_status', 'add_time', 'update_time', 'extra_info']
                [(1, '43694039', '6S19233378A0892F', '1605480645077637', '', 0, 1576830519, 1576830549, ''),
                 (2, '43694039', '6S19233378A0892F', '1637301286380160', '', 0, 1576835233, 1576835257, ''),
                 (3, '43694039', '6S19233378A0892F', '1602571504515790', '', 0, 1576840818, 1576840831, ''),
                 (4, '52884009', '2F19150ABDC69EFC', '1606949447187834', '', 0, 1576854614, 1576892912, ''),
                 (5, '52884009', '8K1945EE1384E20D', '1615355993059204', '', 0, 1576854823, 1576864105, ''),
                 (6, '52884009', '2F19150ABDC69EFC', '1615355993059204', '', 0, 1576854825, 1576864107, ''),
                 (7, '52884009', '8K1945EE1384E20D', '1637301286380160', '', 0, 1576855033, 1576863264, ''),
                 (8, '52884009', '2F19150ABDC69EFC', '1604868439788697', '', 0, 1576855033, 1576861582, ''),
                 (9, '52884009', '8K1945EE1384E20D', '1640722987022702', '', 0, 1576855243, 1576855275, ''),
                 (10, '52884009', '8K1945EE1384E20D', '1586997514544738', '', 0, 1576855454, 1576863895, '')]
"""

from sqlalchemy import Column, UniqueConstraint
from sqlalchemy.dialects.mysql import VARCHAR, TINYINT, BIGINT, INTEGER
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class UserFollowUploaderRecord(Base):
    """
        创建sql表，用于记录每个用户关注的账号信息
    """
    __tablename__ = 'user_follow_uploader_record'

    id = Column(BIGINT(unsigned=True), default=None, index=True, unique=True, nullable=False, primary_key=True,
                comment="自增主键")
    userid = Column(VARCHAR(64), default='', nullable=False, comment="用户id")
    cuid = Column(VARCHAR(32), default='', nullable=False, comment="设备id")
    app_id = Column(VARCHAR(32), default='', nullable=False, comment="作者id")
    author_name = Column(VARCHAR(32), default='', nullable=False, comment="作者名称")
    follow_status = Column(TINYINT(1), default=1, nullable=False, comment="关注状态")
    add_time = Column(INTEGER(unsigned=True), default=0, nullable=False, comment="添加时间")
    update_time = Column(INTEGER(unsigned=True), default=0, nullable=False, comment="更新时间")
    extra_info = Column(VARCHAR(1024), default='', nullable=False, comment="额外信息字段json串描述")
    #
    UniqueConstraint(userid, cuid, app_id)