#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
File: visualize.py
Author: xiaolikai
Date: 2022/07/29 16:50:30
Desc: 根据模型在train/infer阶段dump下的数据，计算auc
"""

import os
import numpy as np

log_file = open("dump.data", "r")
flag = "auc_0"
auc = []  #记录所有的auc

for line in log_file:
    if "auc_0" in line:
        pos = line.find("):") + 2
        auc.append(float(line[pos: ]))

print(len(auc))
print(sum(auc)/len(auc))
