#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
File: visualize.py
Author: xiaolikai
Date: 2022/07/29 16:26:30
Desc: 根据模型train/infer输出在日志中的信息，计算auc
"""

import os
import numpy as np

log_file = open("infer64.txt", "r")
flag = "global AUC="
auc = []  #记录所有的auc

for line in log_file:
    if flag in line:
        pos = line.find(flag) + 11
        auc.append(float(line[pos: pos + 8]))

print(auc)
print(sum(auc)/len(auc))
