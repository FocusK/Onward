udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_device_uv_pv_ana_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';


select
    t2.group_id,
    t1.event_day,
    count(t1.cuid) as check_dod,
    sum(device_dod) as dod,
    sum(device_voice_touch_dad) as dad,
    sum(device_touch_dpv) + sum(device_voice_dpv) as dpv
    -- sum(device_voice_dpv) as voice_pv,
    -- sum(device_touch_dpv) as touch_pv
from
(
    select
        event_day,
        appid,
        cuid,
        userid,
        device_age,
        is_ib as ib,
        online_hours,
        is_dod as device_dod,
        is_dad as device_voice_dad,
        is_wad as device_voice_wad,
        is_mad as device_voice_mad,
        is_touch_dad as device_touch_dad,
        if(is_touch_dad+is_dad > 0,1,0) as device_voice_touch_dad,
        if(is_touch_dad=1 and is_dad = 0,1,0) as device_only_touch_dad,
        dpv as device_voice_dpv,
        touch_dpv as device_touch_dpv,
        dpv+touch_dpv as device_voice_touch_dpv,
        if(is_dad_1d_later=1 and is_dad=1,1,0) as 1d_lc,
        if(is_dad_7d_later=1 and is_dad=1,1,0) as 7d_lc,
        if(is_dad_30d_later=1 and is_dad=1,1,0) as 30d_lc
    from
        udw_ns.default.duer_rollup_device_xiaodu_brand
    where
        event_day between '20230716' and '20230723'
        and device_type in ("show")
        and is_first_party=1
        and is_ib=1
        and appid NOT IN ('dmD740A443D80F2C31',
                       'dmD8C310FAEF8775AA',
                       'dm2F9DC0CB5C6CE7C8',
                       'dmADFA69A88E01E9D9',
                       'dm69B6CB42B9748B49',
                       'dmB31AAADFA923DC08',
                       'dm7E7A83DCCC94C1AD',
                       'dm1B816FB3F5A52A1D',
                       'dm3D8AD89151B020BF')
) t1
inner join (
    select
        /*+mapjoin(app)*/
        ug.event_day,
        ug.group_id,
        ug.appid,
        ug.cuid
    from
    (
        select
            event_day, dumi_sid as group_id, appid, cuid
        from
            udw_ns.default.duer_dim_cuid_sid
        where
            event_day between '20230716' and '20230723'
            and dumi_sid in  (6094)
            and appid NOT IN ('dmD740A443D80F2C31',
                       'dmD8C310FAEF8775AA',
                       'dm2F9DC0CB5C6CE7C8',
                       'dmADFA69A88E01E9D9',
                       'dm69B6CB42B9748B49',
                       'dmB31AAADFA923DC08',
                       'dm7E7A83DCCC94C1AD',
                       'dm1B816FB3F5A52A1D',
                       'dm3D8AD89151B020BF')
    ) ug
    inner join
    (
        select appid
        from udw_ns.default.duer_dim_app
        where event_day='20230717'
        and is_first_party=1
        and is_xiaodu_brand=1
        and device_type in ("show")
    ) app
    on ug.appid=app.appid
) t2
on t1.event_day = t2.event_day and t1.cuid = t2.cuid and t1.appid = t2.appid
group by t2.group_id, t1.event_day
order by t2.group_id, t1.event_day;





-- select
--     t2.group_id,
--     t1.event_day,
--     sum(ib) as ib,
--     sum(online_hours) as online_hours,
--     sum(device_dod) as dod,
--     sum(device_voice_dad) as voice_uv,
--     sum(device_voice_dpv) as voice_pv,
--     sum(device_touch_dad) as touch_uv,
--     sum(device_touch_dpv) as touch_pv,
--     sum(device_voice_touch_dad) as voice_touch_uv,
--     sum(device_voice_touch_dpv) as voice_touch_pv,
--     sum(device_only_touch_dad) as only_touch_uv,
--     sum(1d_lc) as 1d_lc,
--     sum(7d_lc) as 7d_lc,
--     sum(30d_lc) as 30d_lc
-- from
-- (
--     select
--         event_day,
--         appid,
--         cuid,
--         userid,
--         device_age,
--         is_ib as ib,
--         online_hours,
--         is_dod as device_dod,
--         is_dad as device_voice_dad,
--         is_wad as device_voice_wad,
--         is_mad as device_voice_mad,
--         is_touch_dad as device_touch_dad,
--         if(is_touch_dad+is_dad > 0,1,0) as device_voice_touch_dad,
--         if(is_touch_dad=1 and is_dad = 0,1,0) as device_only_touch_dad,
--         dpv as device_voice_dpv,
--         touch_dpv as device_touch_dpv,
--         dpv+touch_dpv as device_voice_touch_dpv,
--         if(is_dad_1d_later=1 and is_dad=1,1,0) as 1d_lc,
--         if(is_dad_7d_later=1 and is_dad=1,1,0) as 7d_lc,
--         if(is_dad_30d_later=1 and is_dad=1,1,0) as 30d_lc
--     from
--         udw_ns.default.duer_rollup_device_xiaodu_brand
--     where
--         event_day between '20230705' and '20230709'
--         and device_type in ("show")
--         and is_first_party=1
--         and is_ib=1
--         and appid NOT IN ('dmD740A443D80F2C31',
--                        'dmD8C310FAEF8775AA',
--                        'dm2F9DC0CB5C6CE7C8',
--                        'dmADFA69A88E01E9D9',
--                        'dm69B6CB42B9748B49',
--                        'dmB31AAADFA923DC08',
--                        'dm7E7A83DCCC94C1AD',
--                        'dm1B816FB3F5A52A1D',
--                        'dm3D8AD89151B020BF')
-- ) t1
-- inner join (
--     select
--         /*+mapjoin(app)*/
--         ug.group_id,
--         ug.appid,
--         ug.cuid
--     from
--     (
--         select
--             distinct dumi_sid as group_id, appid, cuid
--         from
--             udw_ns.default.duer_dim_cuid_sid
--         where
--             event_day between '20230706' and '20230709'
--             and dumi_sid in  (6094, 6095)
--             and appid NOT IN ('dmD740A443D80F2C31',
--                        'dmD8C310FAEF8775AA',
--                        'dm2F9DC0CB5C6CE7C8',
--                        'dmADFA69A88E01E9D9',
--                        'dm69B6CB42B9748B49',
--                        'dmB31AAADFA923DC08',
--                        'dm7E7A83DCCC94C1AD',
--                        'dm1B816FB3F5A52A1D',
--                        'dm3D8AD89151B020BF')
--     ) ug
--     inner join
--     (
--         select appid
--         from udw_ns.default.duer_dim_app
--         where event_day='20230713'
--         and is_first_party=1
--         and is_xiaodu_brand=1
--         and device_type in ("show")
--     ) app
--     on ug.appid=app.appid
-- ) t2
-- on t1.cuid = t2.cuid and t1.appid = t2.appid
-- group by t2.group_id,t1.event_day
-- order by t2.group_id,t1.event_day;