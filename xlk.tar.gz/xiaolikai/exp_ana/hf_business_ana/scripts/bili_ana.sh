#!/bin/bash
source ~/.bashrc

#### common header ####
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
sqls=${workPath}/sqls
logs=${workPath}/logs

#### 日期范围 ####
dst_day=$1
if [ ! -n "$1" ];then
    dst_day=$(date -d "last day" +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)
start_day=$(date -d "-15 days $dst_day" +%Y%m%d)

#### 生成当天数据 ####
log="${logs}/bili_ctr_data_${dst_day}.log"

cd ${sqls}
qexlk -f bili_ctr.sql --hivevar currentDate=${curDate} startDate=$start_day endDate=$dst_day > ${log} 2>&1
