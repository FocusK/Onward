udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
sessiondb = DATABASE 'session:/';
use namespace udw_ns;

SET mapred.job.map.capacity=500;
SET mapred.job.reduce.capacity=500;
SET mapred.reduce.tasks=100;
SET mapred.job.priority=NORMAL;
SET mapred.job.name=duer_rus_bili_ctr_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;

ADD jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';


SELECT
  t3.event_day,
  t3.dumi_sid,
  t3.show_pv,
  t3.show_uv,
  t3.click_pv,
  t3.click_uv,
  t3.click_uv / t3.show_uv * 100 as `uv_ctr`,
  t3.click_pv / t3.show_pv * 100 as `pv_ctr`
FROM(
  SELECT 
    t1.event_day,
    t1.dumi_sid,
    t1.show_pv,
    t1.show_uv,
    t2.click_pv,
    t2.click_uv
  FROM
    (
      SELECT 
        t.event_day,
        v.dumi_sid,
        count(1) AS show_pv,
        count(DISTINCT t.cuid) AS show_uv
    FROM
      (
        SELECT 
          event_day,
          cuid
        FROM 
          udw_ns.default.duer_ods_device_clicklog_detail
        WHERE 
          event_day>="${hivevar:startDate}" AND event_day<="${hivevar:endDate}"
          AND type = '481'
          AND get_json_object(content, '$.event_page') LIKE 'homecard_card_%'
          AND split(split(get_json_object(unbase64(get_json_object(content, '$.token')), '$.bot_token'), '\\?')[0], '\/')[1] = 'short_video'
          AND split(split(get_json_object(unbase64(get_json_object(content, '$.token')), '$.bot_token'), '\\?')[0], '\/')[2] rlike '^bili'
      ) t
    INNER JOIN
      (
        SELECT DISTINCT 
          cuid,
          dumi_sid
        FROM 
          udw_ns.default.duer_dim_cuid_sid
        WHERE 
          event_day>="${hivevar:startDate}" AND event_day<="${hivevar:endDate}"
          AND dumi_sid IN ('6094', '6095')
          AND appid NOT IN (
            'dm413F699FD2A5D12C',
            'dm2C59A35C402824A7',
            'dm2F9DC0CB5C6CE7C8',
            'dm7E7A83DCCC94C1AD',
            'dmADFA69A88E01E9D9',
            'dm69B6CB42B9748B49',
            'dmB31AAADFA923DC08',
            'dmD740A443D80F2C31',
            'dmD8C310FAEF8775AA',
            'dm3D8AD89151B020BF',
            'dm1B816FB3F5A52A1D',
            'dm82F08D274CCF2466'
          )
      ) v 
    ON 
      t.cuid = v.cuid
    GROUP BY 
      t.event_day,
      v.dumi_sid) t1
  LEFT OUTER JOIN
    (
      SELECT 
        t.event_day,
        v.dumi_sid,
        count(1) AS click_pv,
        count(DISTINCT t.cuid) AS click_uv
    FROM
      (
        SELECT 
          event_day,
          cuid,
          split(get_json_object(extra_params, '$.referral.bot_token'), '\\?')[0] AS card_full_id
        FROM 
          udw_ns.default.duer_idw_action
        WHERE 
          event_day>="${hivevar:startDate}" AND event_day<="${hivevar:endDate}"
          AND device_type = 'show'
          AND action_type = 'touch'
          AND action_sub_type = 'link_clicked'
          AND get_json_object(extra_params, '$.parsedUrl.params.oss_channel') = 'homecard'
          AND split(split(get_json_object(extra_params, '$.referral.bot_token'), '\\?')[0], '\/')[1] = 'short_video'
          AND split(split(get_json_object(extra_params, '$.referral.bot_token'), '\\?')[0], '\/')[2] rlike '^bili'
      ) t
    INNER JOIN
      (
        SELECT DISTINCT 
          cuid,
          dumi_sid
        FROM 
          udw_ns.default.duer_dim_cuid_sid
        WHERE 
          event_day>="${hivevar:startDate}" AND event_day<="${hivevar:endDate}"
          AND dumi_sid IN ('6094', '6095')
          AND appid NOT IN (
            'dm413F699FD2A5D12C',
            'dm2C59A35C402824A7',
            'dm2F9DC0CB5C6CE7C8',
            'dm7E7A83DCCC94C1AD',
            'dmADFA69A88E01E9D9',
            'dm69B6CB42B9748B49',
            'dmB31AAADFA923DC08',
            'dmD740A443D80F2C31',
            'dmD8C310FAEF8775AA',
            'dm3D8AD89151B020BF',
            'dm1B816FB3F5A52A1D',
            'dm82F08D274CCF2466'
          )
      ) v 
    ON 
      t.cuid = v.cuid
  GROUP BY t.event_day, v.dumi_sid
  ) t2 
  ON t1.event_day = t2.event_day
  AND t1.dumi_sid = t2.dumi_sid
)t3
order by t3.dumi_sid,t3.event_day;