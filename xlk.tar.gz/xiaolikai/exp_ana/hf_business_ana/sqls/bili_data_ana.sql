udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
sessiondb = DATABASE 'session:/';
use namespace udw_ns;

SET mapred.job.map.capacity=500;
SET mapred.job.reduce.capacity=500;
SET mapred.reduce.tasks=100;
SET mapred.job.priority=NORMAL;
SET mapred.job.name=duer_rus_bili_ana_new_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;

ADD jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';

ADD FILE ./trans_cardid2source.py;
ADD FILE ./utils.py;

SELECT
    t3.event_day,
    count(t3.cuid) as pv,
    count(distinct t3.cuid) as uv
FROM (
    SELECT
        t2.event_day,
        t2.source_from,
        t2.cuid
    FROM (
        SELECT TRANSFORM(t1.*)
        USING 'python trans_cardid2source.py'
        AS (event_day, cuid, dumi_sid, channel, categery, source_from)
        FROM 
        (  
            SELECT
                event_day,
                cuid,
                split(get_json_object(unbase64(get_json_object(event_payload,'$.token')),'$.bot_token'),'\\?')[0] as card,
                dumi_sid
                FROM default.duer_idw_event
            WHERE event_day>="${hivevar:startDate}" AND event_day<="${hivevar:endDate}"
            AND event_name = 'LinkClicked'
            AND get_json_object(event_payload,'$.url') like '%oss_channel=homecard%'
            AND get_json_object(event_payload,'$.initiator.type') = 'USER_CLICK'
            AND get_json_object(unbase64(get_json_object(event_payload,'$.token')),'$.bot_id') = 'ai.dueros.bot.homecard_v2'
            --语音点击
            UNION ALL
            SELECT
                event_day,
                cuid,
                split(get_json_object(unbase64(get_json_object(json_array_find(client_context, '$.header.name', 'ViewState'),'$.payload.token')),'$.bot_token'),'\\?')[0] as card,
                dumi_sid
                FROM default.duer_idw_event
            WHERE event_day>="${hivevar:startDate}" AND event_day<="${hivevar:endDate}"
            AND query_type = 0
            AND event_name = 'ListenStarted'
            AND get_json_object(nlu, '$.domain') = 'uicontrol'
            AND get_json_object(nlu, '$.intent') = 'uicontrol'
            AND get_json_object(unbase64(get_json_object(json_array_find(client_context, '$.header.name', 'ViewState'),'$.payload.token')),'$.bot_id') = 'ai.dueros.bot.homecard_v2'
        ) t1
    ) t2 
    where t2.source_from = "SV_BILIBILI"
    AND t2.channel in ('rus', 'bot')
    
) t3
GROUP BY t3.event_day
ORDER BY t3.event_day;



