#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
from utils import DataUtil

if __name__ == "__main__":

    for event_day, cuid, cardid, dumi_sid_concat in DataUtil.readInputFileWithCheck(sys.stdin, 4):
        if len(cardid.split('/')) != 3: 
            continue
        channel = cardid.split('/')[0]
        categery = cardid.split('/')[1]
        resource_id = cardid.split('/')[2]
        source_from = "IGNORE"
        if resource_id.startswith("iqiyi_mobile_") and categery == "long_video":
            source_from = "VD_IQIYI"
        elif resource_id.startswith("mg_mobile_") and categery == "long_video":
            source_from = "VD_MG"
        elif resource_id.startswith("youku_mobile_") and categery == "long_video":
            source_from = "VD_YOUKU"
        elif resource_id.startswith("bilibili_") and categery == "short_video":
            source_from = "SV_BILIBILI"
        elif resource_id.startswith("bilibili_mobile_") and categery == "long_video":
            source_from = "VD_BILIBILI"
        elif resource_id.startswith("douyin_") and categery == "short_video":
            source_from = "SV_DOUYIN"

        dumi_sid_list = dumi_sid_concat.split("_")
        # 如果包含小流量，则按照小流量展开成多个小流量数据
        # 如果不包含小流量，则仅仅包含一个全流量记录
        for dumi_sid in dumi_sid_list:
            if dumi_sid == "":
                dumi_sid = "full"
            elif dumi_sid == "\N":
                dumi_sid = "UNK_SID"
            

            print('\t'.join(map(str, [event_day, cuid, dumi_sid, channel, categery, source_from])))
