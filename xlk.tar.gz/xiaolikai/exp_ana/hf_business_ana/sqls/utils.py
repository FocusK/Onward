# coding=utf-8
import time
import math
import os
import datetime
import random
import sys
import json
import codecs

class IndexUtil(object):
    
    def __init__(self, index_map_name):

        self.feature_index_map = {}
        with codecs.open(index_map_name) as index_f:
            for feature_slot, feature_name, _, feature_index in DataUtil.readInputFileWithCheck(index_f, 4):
                self.feature_index_map[feature_name] = str(feature_slot).strip() + ':' + str(feature_index).strip()

    def get_feature_index(self, slot_name, slot_value, encode_map, weight = 1.0):

        slot_name_value = ""
        if slot_value == 'null' or len(slot_value) == 0:
            slot_name_value = slot_name + '_NULL'
        else:
            slot_name_value = slot_name + '_' + slot_value
        
        slot_and_index = self.feature_index_map.get(slot_name_value, None)
        if slot_and_index:
            encode_map[slot_and_index] = weight
        return encode_map
    
    def get_dense_feature_index(self, slot_name, encode_map, weight):
        slot_and_index = self.feature_index_map.get(slot_name, None)
        if slot_and_index:
            encode_map[slot_and_index] = weight
        return encode_map


class DataUtil(object):
    def __init__(self):
        return

    @staticmethod
    def readInput(file):
        for line in file:
            fields = line.strip("\r\n")
            yield fields

    @staticmethod
    def readInputFileSep(file, sep=""):
        for line in file:
            fields = line.strip("\r\n").split(sep)
            yield fields

    @staticmethod
    def readInputFile(file):
        fieldSep = "\t"
        lineSep = "\r\n"
        for line in file:
            fields = line.strip(lineSep).split(fieldSep)
            yield fields

    @staticmethod
    def readInputFileWithCheck(file, num):
        fieldSep = "\t"
        lineSep = "\r\n"
        for line in file:
            fields = line.strip(lineSep).split(fieldSep)
            if len(fields) != num:
                continue
            yield fields


class TimeUtil(object):
    def __init__(self):
        return

    @staticmethod
    def t_now():
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))

    # @staticmethod
    # def transTimeStrToStamp(timeStr, formatStr):
    #     formatStr='%Y-%m-%d %H:%M:%S'
    #     return int(time.mktime(time.strptime(timeStr, formatStr)))

    @staticmethod
    def todayYMDStr():
        return datetime.date.today().strftime("%Y%m%d")

    @staticmethod
    def yesterdayYMDStr():
        today = datetime.date.today()
        yesterday = (today - datetime.timedelta(days=1)).strftime("%Y%m%d")
        return yesterday
    
    @staticmethod
    def getCareDateBeforeDate(cur_time_str, gap_day, formatStr="%Y%m%d"):
        cur_time = datetime.datetime.strptime(cur_time_str, formatStr)
        care_day = (cur_time - datetime.timedelta(days=gap_day)).strftime(formatStr)
        return care_day

    @staticmethod
    def transStampToDTime(time_stamp):
        return datetime.datetime.fromtimestamp(int(time_stamp))
    
    @staticmethod
    def transStampToTimeStr(time_stamp, formatStr="%Y%m%d"):
        time_array = time.localtime(int(time_stamp))
        return time.strftime(formatStr, time_array)

    @staticmethod
    def nowDateTime():
        return datetime.datetime.now()

    @staticmethod
    def timeDiffDay(time1, time2):
        return (time1 - time2).days

    @staticmethod
    def transDtimeToTstamp(dtime):
        return int(time.mktime(dtime.timetuple()))

    @staticmethod
    def transTimeStrToStamp(time_str, formatStr="%Y%m%d"):
        return int(time.mktime(time.strptime(time_str, formatStr)))

    @staticmethod
    def transTimeStrToTime(time_str, formatStr="%Y%m%d"):
        return datetime.datetime.strptime(time_str, formatStr)

    @staticmethod
    def unify_date_format(dt_str, fmt):
        """
        输入为各种日期格式的字符串：yyyymmdd, yyyy-mm-dd, yyyy-mm-dd hh:MM:ss
        输出为参数fmt指定的日期格式
        例如：unify_date_format('2019-12-30', '%Y%m%d')
        """
        try:
            dt_str = dt_str.strip()
            if len(dt_str) == len("yyyymmdd"):
                dt_str = datetime.datetime.strptime(dt_str, "%Y%m%d").strftime(fmt)
            elif len(dt_str) == len("yyyy-mm-dd"):
                dt_str = datetime.datetime.strptime(dt_str, "%Y-%m-%d").strftime(fmt)
            elif len(dt_str) >= len("yyyy-mm-dd hh:MM:ss"):
                dt_str = dt_str[: len("yyyy-mm-dd hh:MM:ss")]
                dt_str = datetime.datetime.strptime(
                    dt_str, "%Y-%m-%d %H:%M:%S"
                ).strftime(fmt)
            else:
                return None
            return dt_str
        except Exception as e:
            print(e)
            return None


class PathUtil(object):
    def __init__(self, base_hadoop):
        self.hdfs = base_hadoop
        return

    def mkdirOnHdfs(self, path):
        if self.isHdfsExist(path):
            print("%s exist", path)
            return False
        else:
            cmd = self.hdfs + " dfs -mkdir " + path
            cmd += ' if [ "$?" -eq 0 ]; then echo ok; else echo fail; fi'
            rp = os.popen(cmd)
            response = rp.read().strip()
            rp.close()
            if response == "ok":
                print("path mkdir successed")
                return True
            else:
                print("path mkdir failed")
                return False

    def isHdfsExist(self, path):
        cmd = self.hdfs + " dfs -test -e " + path + "\n"
        cmd += 'if [ "$?" -eq 0 ]; then echo ok; else echo fail; fi'
        rp = os.popen(cmd)
        response = rp.read().strip()
        rp.close()
        if response == "ok":
            return True
        else:
            return False


class CalUtil(object):
    def __init__(self):
        return

    @staticmethod
    def decay_func(num):
        return 1 / math.pow(1.6, math.log(int(num) + 1, 8))

    @staticmethod
    def log_decay(num):
        return math.log10(float(num))

    @staticmethod
    def pow_2_5_decay(num):
        return math.pow(num, 1.0 / 2.2)

    @staticmethod
    def pow_decay(num):
        return math.pow(0.97, num)


class MathUitl(object):
    def __init__(self):
        pass

    @staticmethod
    def wilson_score(u, n, z=1.96):  # u:click  n:show  z:parameter

        u, n = float(u), float(n)
        n = n + 0.0001
        u = min(u, n * 0.99)
        z = z
        score = 0.0

        p = (u) / n
        try:
            score = (
                p
                + z * z / (2 * n)
                - z / (2 * n) * math.sqrt(4 * n * (1 - p) * p + z * z)
            ) / (1 + z * z / n)
        except Exception:
            LogUtil.log((u, n))
        return score

    @staticmethod
    def wilson_modify(p, n, z=1.96):  # p: 好评率，n: 通过某个值去修正，如样本量等

        score = 0.0
        p = float(p)
        try:
            score = (
                p
                + z * z / (2 * n)
                - z / (2 * n) * math.sqrt(4 * n * (1 - p) * p + z * z)
            ) / (1 + z * z / n)
        except Exception:
            LogUtil.log((p, n))

        return score


class LogUtil(object):
    def __init__(self):
        pass

    @staticmethod
    def log(msg, typ="INFO"):
        print("[%s]\t[%s]\t%s" % (TimeUtil.t_now(), typ, str(msg)))
        sys.stdout.flush()
        return


class DirUtil(object):
    def __init__(self):
        return

    @staticmethod
    def find_all_file(base):
        for root, _, fs in os.walk(base):
            for f in fs:
                fullname = os.path.join(root, f)
                yield fullname
    
    @staticmethod
    def check_file_exist(file_path):
        try:
            if os.path.isfile(file_path):
                return True
            else:
                LogUtil.log("error in %s, please check"%(file_path))
                return False
        except:
            return False



class MusicTools(object):
    def __init__(self):
        return

    @staticmethod
    def get_appid_set():
        appid_set = set()
        # spearker
        appid_set.add("dmC983500B0350C3AC")
        appid_set.add("dm6191A02F6E33CEF5")
        appid_set.add("dm697C6FAC8496A8F6")
        appid_set.add("dmC934369F7158BBE4")
        appid_set.add("dm418F72A6DBF3667A")
        appid_set.add("dmCED4855B8449A354")
        appid_set.add("dm3F66BA3157AFD5D1")
        appid_set.add("dm6F4C1FE8D6418302")
        appid_set.add("dmAE481649FA26A90C")
        appid_set.add("dm58083E5C5F01B5B2")
        appid_set.add("dm6E2BBE5784A024C6")
        appid_set.add("dmDE07C450FB961B72")
        appid_set.add("dm49F48EC114DC4CF3")
        appid_set.add("dm2DC65862316E928B")
        appid_set.add("dmAB6299C9325AB02E")
        appid_set.add("dm82A220FA8FD12ED6")
        appid_set.add("dmA1D4BA0CB0A19BED")
        appid_set.add("dm20C33BB8106E11BA")
        appid_set.add("dm48BB0F88EA95AB70")
        appid_set.add("dmB79A182C1292DD44")
        appid_set.add("dm17016374F4EBF852")
        appid_set.add("dm93BD1EADC358D8BB")
        appid_set.add("dmE43B489A53FCA4C3")
        appid_set.add("dm0875C6A49D76C2AB")
        appid_set.add("dm528571E56463808C")
        appid_set.add("dm009547DA9C0AC9AD")
        appid_set.add("dm74285F4C33E1F0FD")
        appid_set.add("dm6B0E2F0EB119859B")
        appid_set.add("dm9A51A83F53B356B2")
        appid_set.add("dmF12415D0F85323CB")
        appid_set.add("dmF791F123F9012547")
        appid_set.add("dm175EA4C583DCD253")
        appid_set.add("dm28A782CBFB84EBF0")

        appid_set.add("dmDC7C388CAE1EF843")
        appid_set.add("dm57CE54274DBC961B")
        appid_set.add("dm24994249754B0E21")
        appid_set.add("dm2617D9290B5EE728")
        appid_set.add("dmB6A9270EC01C552E")
        appid_set.add("dmE33D6D48A0E0E3EF")
        appid_set.add("dm98E73155C22E60AF")
        appid_set.add("dm6E310B749E4D80D8")
        appid_set.add("dmE3A1062B0A0035B5")
        appid_set.add("dm979DF997AFEA3455")
        appid_set.add("dmAC6F4F8A2CCEBEC6")
        appid_set.add("dm5A0246CCBDF3DE50")
        appid_set.add("dmD4E55228A95E42E1")
        appid_set.add("dmA537FA4D59ACDF7C")  # X8
        appid_set.add("dm0E66BDF305125292")
        appid_set.add("dm12DBB98B4CABFC08")
        appid_set.add("dmF4DB86392284AA0D")
        appid_set.add("dm2E947E22868EDDFB")
        appid_set.add("dm55030D40C1E10BF2")
        appid_set.add("dmA371C7B24DD87352")
        appid_set.add("dm48FA49B253649FF1")
        appid_set.add("dm54E553BFD65C0C6C")

        return appid_set

    @staticmethod
    def get_song_retrieve_type(song_info):
        elems = song_info.split("@")
        if len(elems) < 9:
            return None
        else:
            return elems[8]

    @staticmethod
    def is_post_song(slot):
        try:
            slot_dict = json.loads(slot)
            if not isinstance(slot_dict, dict):
                return False
            if slot_dict.get("song") != None:
                if slot_dict.get("song").get("value") != None:
                    return True
                else:
                    return False
            else:
                return False
        except:
            return False

    @staticmethod
    def is_different_day(query_time, song_info):
        """
        判断query_time和歌曲的开始播放时间是否为同一天
        如果一个query的时间和歌曲开始播放时间不是同一天，则entity_rank字段错误
        """
        query_dt = TimeUtil.unify_date_format(query_time, "%Y%m%d")
        elems = song_info.split("@")
        if len(elems) >= 3:
            start_dt = TimeUtil.unify_date_format(elems[2], "%Y%m%d")
            if query_dt == start_dt:
                return False
            else:
                return True
        else:
            return True
