#!/bin/bash
source ~/.bashrc

#### common header ####
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
sqls=${workPath}/sqls
logs=${workPath}/logs

#### 日期范围 ####
dst_day=$1
if [ ! -n "$1" ];then
    dst_day=$(date -d "last day" +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)

#### 生成当天数据 ####
log="${logs}/${dst_day}_exp_ana.log"

cd ${sqls}
qexlk -f exp_ana.sql --hivevar currentDate=${curDate} endDate=$dst_day > ${log} 2>&1
