# -*- coding: utf-8 -*-
import sys

if __name__ == "__main__":
    for line in sys.stdin:
        message = line.strip('\n').split('\t')
        if len(message) != 4:
            continue
        event_day = message[0]
        cuid = message[1]
        dumi_sid_concat = message[2]
        card = message[3]
        cards = card.split('/')
        if len(cards) != 3:
            continue
        channel = cards[0]
        categery = cards[1]

        dumi_sid_list = dumi_sid_concat.split("_")
        # 如果包含小流量，则按照小流量展开成多个小流量数据
        # 如果不包含小流量，则仅仅包含一个全流量记录
        for dumi_sid in dumi_sid_list:
            if dumi_sid == "":
                dumi_sid = "full"
            elif dumi_sid == "\N":
                dumi_sid = "UNK_SID"

            print('\t'.join(map(str, [event_day, cuid, dumi_sid, channel, categery])))