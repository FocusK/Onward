udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.priority=NORMAL;
SET mapred.job.name=duer_strategy_hf_uv_pv_category_ana_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;
add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';

add file ./trans_cardid.py;

create external table if not exists hf_category_uv_pv_data
(
    exp_data string,
    dumi_sid string,
    category string,
    pv int,
    uv int
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/hf_exp_ana/hf_category_uv_pv_data";

insert overwrite table hf_category_uv_pv_data partition (event_day='${hivevar:endDate}')
select 
    t3.event_day,
    t3.dumi_sid,
    t3.categery,
    count(t3.cuid) as pv,
    count(distinct t3.cuid) as uv
from 
(
    select
        t2.event_day,
        t2.cuid,
        t2.dumi_sid,
        t2.categery
    from 
    (
        select transform(t1.event_day, t1.cuid, t1.dumi_sid, t1.card)
        using 'python trans_cardid.py'
        as (event_day, cuid, dumi_sid, channel, categery)
        from 
        (  
            select
                event_day,
                cuid,
                dumi_sid,
                split(get_json_object(unbase64(get_json_object(event_payload,'$.token')),'$.bot_token'),'\\?')[0] as card
                from udw_ns.default.duer_idw_event
            where event_day>="${hivevar:startDate}" and event_day<="${hivevar:endDate}"
            and event_name = 'LinkClicked'
            and get_json_object(event_payload,'$.url') like '%oss_channel=homecard%'
            and get_json_object(event_payload,'$.initiator.type') = 'USER_CLICK'
            and get_json_object(unbase64(get_json_object(event_payload,'$.token')),'$.bot_id') = 'ai.dueros.bot.homecard_v2'
            --语音点击
            union all
            select
                event_day,
                cuid,
                dumi_sid,
                split(get_json_object(unbase64(get_json_object(json_array_find(client_context, '$.header.name', 'ViewState'),'$.payload.token')),'$.bot_token'),'\\?')[0] as card
                from udw_ns.default.duer_idw_event
            where event_day>="${hivevar:startDate}" and event_day<="${hivevar:endDate}"
            and query_type = 0
            and event_name = 'ListenStarted'
            and get_json_object(nlu, '$.domain') = 'uicontrol'
            and get_json_object(nlu, '$.intent') = 'uicontrol'
            and get_json_object(unbase64(get_json_object(json_array_find(client_context, '$.header.name', 'ViewState'),'$.payload.token')),'$.bot_id') = 'ai.dueros.bot.homecard_v2'
        ) t1
    ) t2 
    where t2.dumi_sid in ("6094", "6095")
    and t2.categery in ("audio", "long_video", "music", "short_video")
) t3
group by t3.event_day, t3.dumi_sid, t3.categery
order by t3.event_day, t3.dumi_sid, t3.categery;