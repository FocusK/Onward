udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.priority=NORMAL;
SET mapred.job.name=duer_strategy_channel_cate_puv_ana_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;

SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';

add file ./trans_cardid.py;

create external table if not exists hf_channel_cate_uv_pv_data
(
    exp_data string,
    dumi_sid string,
    channel string,
    category string,
    pv int,
    uv int
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi_strategy_online/rus/feature_depository/hf_exp_ana/hf_channel_cate_uv_pv_data";


-- DIN
select
    *
from
(
    select
        ta.exp_data,
        ta.category,
        ta.channel,
        ta.dumi_sid as base_sid,
        ta.pv as base_pv,
        ta.uv as base_uv,
        tb.dumi_sid as exp_sid,
        tb.pv as exp_pv,
        tb.uv as exp_uv,
        (tb.pv - ta.pv) / ta.pv * 100 as pv_rate,
        (tb.uv - ta.uv) / ta.uv * 100 as uv_rate
    from(
        select *
        from hf_channel_cate_uv_pv_data
        where event_day=${hivevar:endDate}
            and dumi_sid in ("5722", "5808", "5809")
    )ta
    left outer join(
        select *
        from hf_channel_cate_uv_pv_data
        where event_day=${hivevar:endDate}
            and dumi_sid in ("5723", "5725")
    )tb
    on ta.exp_data = tb.exp_data and ta.category = tb.category and ta.channel = tb.channel
)t3
order by t3.base_sid, t3.exp_sid, t3.category, t3.exp_data;