udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_hf_sv_overall_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION UDFUnbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';
create TEMPORARY FUNCTION row_number_by_sort as 'org.apache.hadoop.hive.ql.udf.UDFRowNumberByPreSort';

select
  t1.event_day,
  count(1) as show_uv,
  sum(t1.show_pv) as show_pv,
  count(t3.cuid) as click_uv,
  sum(coalesce(click_pv, 0)) as click_pv
from
  (
    select
      event_day,
      cuid,
      count(1) as show_pv
    from
      udw_ns.default.duer_ods_device_clicklog_detail
    where
      event_day >= "${hivevar:start_day}" and event_day <= "${hivevar:end_day}"
      and type = '481'
      and split(split(get_json_object(UDFUnbase64(get_json_object(content, '$.token')), '$.bot_token'), '\\?')[0], '\/')[1] = 'short_video'
    group by 
      event_day,
      cuid
  ) t1
  inner join (
    select
      event_day,
      cuid
    from
      udw_ns.default.duer_dim_cuid_sid
    where
      event_day >= "${hivevar:start_day}" and event_day <= "${hivevar:end_day}"
      and appid not in (
        'dmD740A443D80F2C31',
        'dmD8C310FAEF8775AA',
        'dm2F9DC0CB5C6CE7C8',
        'dmADFA69A88E01E9D9',
        'dm69B6CB42B9748B49',
        'dmB31AAADFA923DC08',
        'dm7E7A83DCCC94C1AD',
        'dm1B816FB3F5A52A1D',
        'dm3D8AD89151B020BF'
      )
  ) t2 on t1.cuid = t2.cuid
  and t1.event_day = t2.event_day
  left outer join (
    select
      event_day,
      cuid,
      count(1) as click_pv
    from
      udw_ns.default.duer_idw_action
    where
      event_day >= "${hivevar:start_day}" and event_day <= "${hivevar:end_day}"
      and device_type = 'show'
      and action_type = 'touch'
      and action_sub_type = 'link_clicked'
      and split(split(get_json_object(extra_params, '$.referral.bot_token'), '\\?')[0], '\/')[1] = 'short_video'
    group by 
      event_day,
      cuid
  ) t3 on t1.cuid = t3.cuid
  and t1.event_day = t3.event_day
group by t1.event_day
order by t1.event_day;