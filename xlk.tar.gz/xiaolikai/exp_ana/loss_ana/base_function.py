"""
    Author: Xiao Likai
    File: base_function.py
    Data: 2023-02-07 14:29
"""
import os
import sys

def mean_val(input):
    """
        Arg: input is a list, each value in this list is a float
        return: mean value of this list
    """
    if len(input) == 0:
        return 0.0
    return sum(input) / len(input)

def var_val(input):
    """
        Arg: input is a list, each value in this list is a float
        return: mean value of this list
    """
