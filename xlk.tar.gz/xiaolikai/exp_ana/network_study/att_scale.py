from scipy.special import softmax
import numpy as np


def test_gradient(dim, time_steps=50, scale=1.0):
    """
      模仿attention运算
    """
    q = np.random.randn(dim)
    key = np.random.randn(time_steps, dim)
    x = np.sum(q * key, axis=1) / scale
    y = softmax(x)
    
    grad = np.diag(y) - np.outer(y, y)
    print(y)
    print(np.diag(y).shape)

    return np.max(np.abs(grad))

NUMBER_OF_EXP = 5

print([test_gradient(100) for _ in range(NUMBER_OF_EXP)])
print([test_gradient(1000) for _ in range(NUMBER_OF_EXP)])


print([test_gradient(100, scale=np.sqrt(100)) for _ in range(NUMBER_OF_EXP)])
print([test_gradient(1000, scale=np.sqrt(1000)) for _ in range(NUMBER_OF_EXP)])
