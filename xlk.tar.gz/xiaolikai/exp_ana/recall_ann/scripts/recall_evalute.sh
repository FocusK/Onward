#!bin/bash
source ~/.bashrc

######## common header ########
cd `dirname $0`/..;
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
dataPath="/home/work/xiaolikai/baidu/personal-code/xiaolikai/Homefeed/recall/graph_i2i/data";
logPath=${workPath}/logs;
sqlPath=${workPath}/sqls;

if [ ! -d $logPath ];then
    mkdir $logPath
fi
######## 确定日期 #######
dst_day=$1
if [ ! -n "$1" ];then
    dst_day=$(date -d "last day" +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)
start_day=$(date -d "-6 days $dst_day" +%Y%m%d)
next_day=$(date -d "+1 days $dst_day" +%Y%m%d)
logs1=$logPath/lightgcn_$dst_day.log
{
    # hadoop_path="/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/shortvideo/recall_rate_ana/raw_ann_dict/gcn/event_day=$dst_day"
    # data_path="/home/work/xiaolikai/baidu/personal-code/xiaolikai/Homefeed/recall/graph_i2i/data/ann.dict"
    # hk -rmr $hadoop_path
    # hk -mkdir $hadoop_path
    # hk -put $data_path $hadoop_path

    ####### 执行任务 #######
    cd $sqlPath
    qexlk -f recall_rate.sql --hivevar currentDate=$curDate dst_day=$dst_day start_day=$start_day next_day=$next_day
} > $logs1 2>&1
