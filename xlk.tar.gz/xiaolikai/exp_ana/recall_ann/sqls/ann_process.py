# -*- coding: utf-8 -*-

"""
File: ann_process.py
Author: xiaolikai
Date: 2022/09/29 17:20:30
Desc: 处理ann dict,返回seed_resource、recall_resource、distance
"""
import os
import sys
import json

def main():
    """
        处理ann dict,返回seed_resource、recall_resource、distance
    """
    for line in sys.stdin:
        mess = line.strip('\n').split('\t')
        if len(mess) != 2:
            continue
        seed_resource = mess[0]
        ann_js = json.loads(str(mess[1]), strict=False)
        for id_dis in ann_js["resource_ids"]:
            recall_resource = id_dis.split(':')[0]
            print(seed_resource + '\t' + recall_resource)

if __name__ == '__main__':
    main()