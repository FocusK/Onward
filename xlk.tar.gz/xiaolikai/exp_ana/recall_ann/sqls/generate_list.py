# -*- coding: utf-8 -*-

"""
File: generate_list.py
Author: xiaolikai
Date: 2022/09/30 11:28:30
Desc: 根据uid, 聚合成list
"""
import os
import sys
import json
from operator import itemgetter
from itertools import groupby

def parse_stdin(stdin):
    """
        从sql中接受标准输入
    """
    for line in stdin:
        message = line.strip().split('\t')
        if len(message) != 2:
            continue
        yield message


def parse_input():
    """
     从本地文件中接受数据，用于验证本脚本的正确性
    """
    with open('./test2.data', 'r') as fr:
        for line in fr:
            line = line.strip('\n').split('\t')
            if len(line) != 2:
                continue
            yield line

def main():
    """
        根据uid, 聚合成list
    """
    for uid, session in groupby(parse_stdin(sys.stdin), itemgetter(0)):
        output = ""
        for mess in session:
            output += mess[1]
            output += ' '
        print(uid + '\t' + output.strip(' '))

if __name__ == '__main__':
    main()