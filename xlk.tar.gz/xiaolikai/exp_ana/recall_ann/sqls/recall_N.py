# -*- coding: utf-8 -*-

"""
File: recall_N.py
Author: xiaolikai
Date: 2022/09/30 11:22:30
Desc: 根据ann结果计算召回率
"""
import os
import sys
import json

def main():
    """
        计算召回率
    """
    for line in sys.stdin:
        mess = line.strip('\n').split('\t')
        if len(mess) != 3:
            continue
        uid = mess[0]
        y_pred = mess[1].split(' ')
        y_true = mess[2].split(' ')
        recall_num = len(set(y_pred) & set(y_true))
        recall_rate = recall_num * 1.0 / len(y_true)
        print(uid + '\t' + str(len(y_true)) + '\t' + str(recall_num) + '\t' + str(recall_rate))
            
if __name__ == '__main__':
    main()