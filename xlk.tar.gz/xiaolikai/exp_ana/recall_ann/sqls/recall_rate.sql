udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_ann_recall_rate_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';
create TEMPORARY FUNCTION row_number_by_sort as 'org.apache.hadoop.hive.ql.udf.UDFRowNumberByPreSort';

add file ./ann_process.py;
add file ./recall_N.py;
add file ./generate_list.py;

-- 原始的ann结果
-- drop table if exists raw_ann_dict;
-- create external table if not exists raw_ann_dict
-- (
--     seed string,  -- key
--     top_k string  -- 召回结果
-- ) partitioned BY (event_day string)
-- row format delimited fields terminated by '\t'
-- location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/shortvideo/recall_rate_ana/raw_ann_dict/gcn";

-- alter table raw_ann_dict add partition(event_day='${hivevar:dst_day}')
-- location 'afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/shortvideo/recall_rate_ana/raw_ann_dict/gcn/event_day=${hivevar:dst_day}';

-- drop table if exists ann_data;
-- create external table if not exists ann_data
-- (
--     seed_resource string,  -- key
--     recall_resource string  -- 召回结果
-- ) partitioned BY (event_day string)
-- row format delimited fields terminated by '\t'
-- location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/shortvideo/recall_rate_ana/ann_dict/gcn";

-- insert overwrite table ann_data partition (event_day="${hivevar:dst_day}")
-- select
--     transform(seed, top_k)
-- using 'python ann_process.py'
-- as (seed_resource, recall_resource)
-- from raw_ann_dict
-- where event_day="${hivevar:dst_day}";

create external table if not exists recall_rate_table
(
    userid string,
    his_resource_nums int,
    recall_nums int,
    recall_rate float
) partitioned BY (event_day string)
row format delimited fields terminated by '\t'
location "afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/recall/shortvideo/recall_rate_ana/recall_rate/gcn";

insert overwrite table recall_rate_table partition (event_day="${hivevar:dst_day}")
select
    transform(origin.*)
using 'python recall_N.py'
as (user, his_nums, recall_nums, u_recall_rate)
from(
    select 
        tf.userid, tf.y_pred, tf.y_true
    from(
        select
            user_recall_table.userid as userid, user_recall_table.y_pred as y_pred, user_new_his.y_true as y_true
        from(
            -- 计算出每个用户的召回资源
            select
                transform(te.*)
            using 'python generate_list.py'
            as (userid, y_pred)
            from (
                select
                    tc.userid, tc.recall_resource
                from(
                    select
                        distinct user_history.userid as userid, ann_table.recall_resource as recall_resource
                    from(   -- 选取用户最近50个历史行为作为种子
                        select
                            tb.userid, tb.his_resource
                        from(
                            select
                                ta.userid, ta.his_resource, ta.start_time,
                                row_number_by_sort(userid) rank
                            from(
                                select
                                    distinct userid, concat("SV_", resource_id) as his_resource, start_time
                                from udw_ns.default.duer_idw_bot_detail
                                where event_day>="${hivevar:start_day}" and event_day>="${hivevar:dst_day}"
                                    and source_type = "ai.dueros.bot.short_video"
                                    and logid_trigger <> "" and resource_id <> ""
                                    and resource_id not like "%[a-zA-Z]%"
                                    and start_time <> "" and play_num <> ""
                                    and play_seconds <> "" and cast(play_seconds as int) >= 60
                                distribute by userid
                                order by userid, start_time desc
                            )ta
                        )tb
                        where tb.rank <= 50
                    )user_history
                    inner join (
                        select
                            seed_resource, recall_resource
                        from ann_data
                        where event_day="${hivevar:dst_day}"
                    ) ann_table
                    on user_history.his_resource = ann_table.seed_resource
                )tc
                distribute by userid
                sort by userid
            )te
        )user_recall_table
        inner join (  --    获取用户下一天的点击历史作为label
            select
                transform(td.*)
            using 'python generate_list.py'
            as (userid, y_true)
            from(
                select
                    distinct userid, concat("SV_", resource_id) as true_resource
                from udw_ns.default.duer_idw_bot_detail
                where event_day="${hivevar:next_day}"
                    and source_type = "ai.dueros.bot.short_video"
                    and logid_trigger <> "" and resource_id <> ""
                    and resource_id not like "%[a-zA-Z]%"
                    and start_time <> "" and play_num <> ""
                    and play_seconds <> "" and cast(play_seconds as int) >= 60
                distribute by userid
                sort by userid
            )td
        )user_new_his
        on user_recall_table.userid = user_new_his.userid
    )tf
    distribute by tf.userid
    order by tf.userid
)origin;

-- 计算平均的召回率 以及 加权后的召回率
-- select
--     avg(recall_rate) as avg_recall_rate,
--     sum(recall_nums)  as weighted_recall_rate
-- from recall_rate_table
-- where event_day="${hivevar:dst_day}";

-- select
--     avg(recall_rate) as avg_recall_rate,
--     sum(recall_nums) / sum(his_resource_nums) as weighted_recall_rate
-- from recall_rate_table
-- where event_day="${hivevar:dst_day}";

