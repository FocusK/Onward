udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.priority=NORMAL;
SET mapred.job.name=duer_strategy_pictorial_uv_pv_rate_cal_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;

SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;
add CACHEARCHIVE afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/tools/python3.tar.gz;


-- 屏保实验
select
    t3.*
from
(
    select
        t1.exp_date as exp_date,
        t1.dumi_sid as base_sid,
        t1.pv as base_pv,
        t1.uv as base_uv,
        t2.dumi_sid as exp_sid,
        t2.pv as exp_pv,
        t2.uv as exp_uv,
        (t2.pv - t1.pv) / t1.pv * 100 as pv_rate,
        (t2.uv - t1.uv) / t1.uv * 100 as uv_rate
    from(  -- 对照组id
        select *
        from pictorial_click_uv_pv_data
        where event_day = ${hivevar:endDate}
            and dumi_sid in ("5798")
    )t1
    left outer join( -- 实验组sid
        select *
        from pictorial_click_uv_pv_data
        where event_day = ${hivevar:endDate}
            and dumi_sid in ("5797")
    )t2
    on t1.exp_date = t2.exp_date
)t3
order by t3.base_sid, t3.exp_sid, t3.exp_date;

-- 展示
select
    t3.*
from
(
    select
        t1.exp_date as exp_date,
        t1.dumi_sid as base_sid,
        t1.pv as base_pv,
        t1.uv as base_uv,
        t2.dumi_sid as exp_sid,
        t2.pv as exp_pv,
        t2.uv as exp_uv,
        (t2.pv - t1.pv) / t1.pv * 100 as pv_rate,
        (t2.uv - t1.uv) / t1.uv * 100 as uv_rate
    from(  -- 对照组id
        select *
        from pictorial_show_uv_pv_data
        where event_day = ${hivevar:endDate}
            and dumi_sid in ("5798")
    )t1
    left outer join( -- 实验组sid
        select *
        from pictorial_show_uv_pv_data
        where event_day = ${hivevar:endDate}
            and dumi_sid in ("5797")
    )t2
    on t1.exp_date = t2.exp_date
)t3
order by t3.base_sid, t3.exp_sid, t3.exp_date;