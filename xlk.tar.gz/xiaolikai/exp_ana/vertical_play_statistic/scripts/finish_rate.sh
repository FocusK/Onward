#!/bin/bash
source ~/.bashrc

cd `dirname $0`/..
BasePath=`pwd`
LOGS=$BasePath/logs
SCRIPTS=$BasePath/scripts
SQLS=$BasePath/sqls

cur_day=`date +"%Y%m%d"`
dst_day=$1
if [ ! -n '$1' ];then
    dst_day=$(date -d 'last day' +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)
start_day=$(date -d "-5 days $dst_day" +%Y%m%d)

cd $SQLS
log=$LOGS/$cur_day.log
qexlk -f finish_rate.sql --hivevar currentDate=$cur_day  start_day=$start_day  dst_day=$dst_day > $log 2>&1
