udw_ns = DATABASE 'udw://szwg-ecomon-hdfs.dmop.baidu.com:54310/app/ns/udw/release/app/ud/tables?config=event-meta';
use namespace duer_ns;
use default;

set mapred.job.priority=NORMAL;
SET mapred.job.map.capacity=300;
SET mapred.job.reduce.capacity=300;
SET mapred.reduce.tasks=100;
SET mapred.job.name=duer_strategy_music_feedback_statistic_${hivevar:currentDate}_by_xiaolikai;
SET dce.shuffle.enable=false;
SET user_write_ugi:afs://pegasus.afs.baidu.com:9902=dumi_bot_rec,dumi_bot_rec_hello;
set hive.exec.scratchdir=afs://pegasus.afs.baidu.com:9902/user/dumi/duer/dumi_bot_rec/xiaolikai/qescratch;

add jar afs://pegasus.afs.baidu.com:9902/user/dumi_data_platform/lib/udf-1.0-SNAPSHOT.jar;
CREATE TEMPORARY FUNCTION unbase64 as 'com.baidu.dueros.hive.udf.UDFUnbase64';
CREATE TEMPORARY FUNCTION json_array_find as 'com.baidu.dueros.hive.udf.UDFJsonArrayFind';

-- -- 统计全局下各垂类的完播率
select
    event_day,
    source_type,
    total_show_nums,
    finish_nums,
    finish_nums*1.0/total_show_nums as finish_rate
from(
    select
        event_day,
        source_type,
        count(1) as total_show_nums,
        sum(case when is_finished="1" then 1 else 0 end) as finish_nums
    from udw_ns.default.duer_idw_bot_detail
    where event_day >= "${hivevar:start_day}" and event_day <= "${hivevar:dst_day}"
        and source_type in ("ai.dueros.bot.short_video", "audio_music", "ai.dueros.bot.video_on_demand")
        and logid_trigger <>''
        and userid <> '' and userid is not null
        and resource_id <> '' and resource_id is not null
        and cast(play_seconds as int) != 0 and play_seconds is not null
        and is_finished <> '' and is_finished is not null
        group by event_day, source_type
)ta
order by event_day, source_type;



-- 统计HF下各垂类的点击率  滑动率
select
    event_day,
    source_type,
    totle_count,
    click_cnt,
    click_cnt*1.0/totle_count as click_rate,
    slide_cnt,
    slide_cnt*1.0/totle_count as slide_rate,
    dislike_cnt,
    dislike_cnt*1.0/totle_count as dislike_rate
from(
    select
        event_day,
        source_type,
        count(1) as totle_count,
        sum(case when (action="hf_voice_click" or action="hf_hand_click") then 1 else 0 end) as click_cnt,
        sum(case when (action="hf_left_slide" or action="hf_right_slide") then 1 else 0 end) as slide_cnt,
        sum(case when (action="hf_dislike_click") then 1 else 0 end) as dislike_cnt
    from (
        select 
            event_day,
            split(hf_token, '/')[1] as source_type,
            action
        from duer_ns.homefeed_user_show_feedback_data_1d
        where event_day >= "${hivevar:start_day}" and event_day <= "${hivevar:dst_day}"
            and split(hf_token, '/')[1] in ("long_video", "music", "short_video")
    )ta
    group by event_day, source_type
)tb
order by event_day, source_type;
