#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
File: visualize.py
Author: xiaolikai
Date: 2022/07/26 19:02:30
Desc: visualizing the value of exp result, 
"""
import os
import sys
import matplotlib.pyplot as plt

import PIL.Image as Image

base_sids = []  # 记录所有的对照组sid
exp_sids = []   # 记录所有的实验组sid
base_data = {}  # 记录对照组的pv uv
exp_data = {}   # 记录实验组的pv uv
dates = []  # 记录所有的日期

def visual(file_path, img_path):
    """
        加载小流量实验的结果数据，进行可视化
    """
    exp_file = open(file_path, 'r')
    for line in exp_file:
        date, sid, pv, uv = line.split('\t')
        if date[4:] not in dates:
            dates.append(date[4:])
        # 实验组数组 
        if sid in exp_sids: 
            if sid not in exp_data:
                exp_data[sid] = {'pv':[pv], 'uv':[uv]}
            else:
                exp_data[sid]['pv'].append(pv)
                exp_data[sid]['uv'].append(uv)
        #  对照组数据
        else:
            if sid not in base_data:
                base_data[sid] = {'pv':[pv], 'uv':[uv]}
            else:
                base_data[sid]['pv'].append(pv)
                base_data[sid]['uv'].append(uv)
    
    # 根据数据绘图
    
    for exp_sid in exp_sids:
        plt.xticks(rotation=90)
        plt.title("pv analyze exp-%s" % exp_sid)
        plt.xlabel('Date', fontsize=10)
        plt.ylabel('PV', fontsize=10)
        plt.tick_params(labelsize=8) 
        pv = [int(ele) for ele in exp_data[exp_sid]['pv']]
        plt.plot(dates, pv, label = 'exp_%s' % exp_sid)
        for base_sid in base_sids:
            pv = [int(ele) for ele in base_data[base_sid]['pv']]
            plt.plot(dates, pv, label = 'base_%s' % base_sid)
            plt.legend()
        imgName = img_path + '/pv_' + exp_sid + ".png"
        plt.savefig(imgName)
        plt.close()
    # uv
    for exp_sid in exp_sids:
        plt.xticks(rotation=90)
        plt.title("uv analyze exp-%s" % exp_sid)
        plt.xlabel('$Date$')
        plt.ylabel('UV')
        pv = [int(ele) for ele in exp_data[exp_sid]['uv']]
        plt.plot(dates, pv, label = 'exp_%s' % exp_sid)
        for base_sid in base_sids:
            pv = [int(ele) for ele in base_data[base_sid]['uv']]
            plt.plot(dates, pv, label = 'base_%s' % base_sid)
            plt.legend()
        
        imgName = img_path + '/uv_' + exp_sid + ".png"
        plt.savefig(imgName)
        plt.close()
    

def resize_by_width(infile, image_size):
    """按照宽度进行所需比例缩放"""
    im = Image.open(infile)
    (x, y) = im.size
    lv = round(x / image_size, 2) + 0.01
    x_s = int(x // lv)
    y_s = int(y // lv)
    # print("x_s", x_s, y_s)
    out = im.resize((x_s, y_s), Image.ANTIALIAS)
    return out


def get_new_img_xy(infile, image_size):
    """返回一个图片的宽、高像素"""
    im = Image.open(infile)
    (x, y) = im.size
    lv = round(x / image_size, 2) + 0.01
    x_s = x // lv
    y_s = y // lv
    # print("x_s", x_s, y_s)
    # out = im.resize((x_s, y_s), Image.ANTIALIAS)
    return x_s, y_s


def image_compose(image_colnum, image_size, image_rownum, image_names, image_save_path, x_new, y_new):
    """
        定义图像拼接函数
    """
    to_image = Image.new('RGB', (image_colnum * x_new, image_rownum * y_new))  # 创建一个新图
    # 循环遍历，把每张图片按顺序粘贴到对应位置上
    total_num = 0
    for y in range(1, image_rownum + 1):
        for x in range(1, image_colnum + 1):
            from_image = resize_by_width(image_names[image_colnum * (y - 1) + x - 1], image_size)
            # from_image = Image.open(image_names[image_colnum * (y - 1) + x - 1]).resize((image_size,image_size ), Image.ANTIALIAS)
            to_image.paste(from_image, ((x - 1) * x_new, (y - 1) * y_new))
            total_num += 1
            if total_num == len(image_names):
                break
    return to_image.save(image_save_path)  # 保存新图


def get_image_list_fullpath(dir_path):
    """
        获取目录下的所有图片
    """
    file_name_list = os.listdir(dir_path)
    if "combine.png" in file_name_list:
        file_name_list.remove("combine.png")
    image_fullpath_list = []
    for file_name_one in file_name_list:
        file_one_path = os.path.join(dir_path, file_name_one)
        if os.path.isfile(file_one_path):
            image_fullpath_list.append(file_one_path)
        else:
            img_path_list = get_image_list_fullpath(file_one_path)
            image_fullpath_list.extend(img_path_list)
    image_fullpath_list.sort()
    return image_fullpath_list


def merge_images(image_dir_path, image_size, image_colnum):
    """
        获取图片集地址下的所有图片名称
        image_dir_path: 图片所在文件夹路径
        image_size: 最终拼接得到的图像的分辨率
        image_colnum: 一行拼接image_clonum张图片
    """
    image_fullpath_list = get_image_list_fullpath(image_dir_path)
    print("image_fullpath_list", len(image_fullpath_list), image_fullpath_list)

    image_save_path = image_dir_path + "/combine.png"  # 图片转换后的地址
    image_rownum_yu = len(image_fullpath_list) % image_colnum
    if image_rownum_yu == 0:
        image_rownum = len(image_fullpath_list) // image_colnum
    else:
        image_rownum = len(image_fullpath_list) // image_colnum + 1

    x_list = []
    y_list = []
    for img_file in image_fullpath_list:
        img_x, img_y = get_new_img_xy(img_file, image_size)
        x_list.append(img_x)
        y_list.append(img_y)

    x_new = int(x_list[len(x_list) // 5 * 4])
    y_new = int(y_list[len(y_list) // 5 * 4])
    print(" x_new, y_new", x_new, y_new)
    image_compose(image_colnum, image_size, image_rownum, image_fullpath_list, image_save_path, x_new, y_new)



if __name__ == "__main__":
    # file_path = sys.argv[1] # 小流量实验数据文件
    # base_sid = sys.argv[2]  # 对照组sid string形式
    # exp_sid = sys.argv[3]   # 实验组sid string形式
    # img_path = sys.argv[4]  # 图片保存路径
    file_path = 'screen.txt' # 小流量实验数据文件
    base_sid = '5798'  # 对照组sid string形式
    exp_sid = "5797"   # 实验组sid string形式
    img_path = "/home/work/xiaolikai/baidu/personal-code/xiaolikai/exp_ana/visualize/din"  # 图片保存路径
    base_sids = base_sid.split('_')
    exp_sids = exp_sid.split('_')
    # 将数据可视化
    visual(file_path, img_path)
    # 拼接图像
    merge_images(img_path, image_size = 1050, image_colnum = 2)