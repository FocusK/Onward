#!/bin/bash
source ~/.bashrc

#### common header ####
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
logs=${workPath}/logs
imgFile=${workPath}/imgs_cate

rm -rf ${logs}
if [ ! -d ${logs} ]; then
    mkdir -p ${logs}
fi

#### 日期范围 ####
dst_day=$1
if [ ! -n "$1" ];then
    dst_day=$(date -d "last day" +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)

log="${logs}/vis_cate_${dst_day}.log"

{
    cd $workPath
    ### 创建目录用于保存折线图 ###
    rm -rf ${imgFile}
    if [ ! -d ${imgFile} ]; then
        mkdir -p ${imgFile}
    fi
    ### 下载当天的实验结果 ###
    BASE_PATH="/user/dumi/duer/dumi_bot_rec/xiaolikai/hf_exp_ana/hf_category_uv_pv_data"
    hadoop_path="$BASE_PATH/event_day=$dst_day"
    local_path="exp_category.data"
    rm $local_path
    hk -getmerge $hadoop_path $local_path

    ### 进行数据分析 ###
    base_sid="4963_4964_4967"
    exp_sid="4968_4969"
    python3 visualize_category.py $local_path $base_sid $exp_sid $imgFile
    # rm -rf logs/
    rm .exp*
} > ${log} 2>&1

