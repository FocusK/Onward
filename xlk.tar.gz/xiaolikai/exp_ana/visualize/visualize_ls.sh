#!/bin/bash
source ~/.bashrc

#### common header ####
workPath=`pwd`;
curDate=`date +"%Y%m%d"`;
logs=${workPath}/logs
imgFile=${workPath}/imgs

#### 日期范围 ####
dst_day=$1
if [ ! -n "$1" ];then
    dst_day=$(date -d "last day" +%Y%m%d)
fi
dst_day=$(date -d "$dst_day" +%Y%m%d)

log="${logs}/${dst_day}.log"

{
    cd $workPath
    ### 创建目录用于保存折线图 ###
    if [ ! -d ${imgFile} ]; then
        mkdir -p ${imgFile}
    fi
    ### 下载当天的实验结果 ###
    BASE_PATH="/user/dumi/duer/dumi_bot_rec/xiaolikai/hf_exp_ana/hf_uv_pv_data"
    hadoop_path="$BASE_PATH/event_day=$dst_day"
    local_path="exp_data.data"
    rm $local_path
    hk -getmerge $hadoop_path $local_path

    ### 进行数据分析 ###
    base_sid="5015"
    exp_sid="5016"
    python3 visualize.py $local_path $base_sid $exp_sid $imgFile
    rm -rf logs/
    # rm .exp_data*
}

