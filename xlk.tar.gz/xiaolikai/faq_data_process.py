# -*- coding: utf-8 -*-

import os
import json
import numpy as np

def data_process(file_path, save_file_path):
    """
    :param file_path: 待处理文件路径
    :param save_file_path: 处理后保存的文件路径 .jsonl格式
    """
    with open(save_file_path, 'w') as f_out:
        with open(file_path, "r", encoding="gb2312") as file:
            for line in file:
                mess = line.strip().split('\t')
                if len(mess) != 4:
                    continue
                else:
                    json_data = {
                        "tasks": [
                            "FAQ"
                        ],
                        "instruction": "",
                        "need_input": False,
                        "input": [

                        ],
                        "output": [
                        ]
                    }
                    prompt = mess[0]
                    query = mess[1]
                    context = mess[2]
                    output = mess[3]
                    instruction = prompt.replace("query", query).replace("context", context)
                    json_data["instruction"] = instruction
                    json_data["output"].append(output)
                    js_str = json.dumps(json_data, ensure_ascii=False)
                    f_out.write(js_str)
                    f_out.write('\n')
                    
if __name__ == "__main__":
    with open("faq_test.jsonl", 'r') as f:
        for line in f:
            data = json.loads(line)
            print(type(data))
            break

    # file_path = "/home/work/xiaolikai/baidu/personal-code/xiaolikai/llm-faq-data-20230615.txt"
    # save_file_path = "/home/work/xiaolikai/baidu/personal-code/xiaolikai/faq_20230615.jsonl"
    # data_process(file_path, save_file_path)
    		
