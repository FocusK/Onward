# -*- coding: utf-8 -*-
########################################
#
# 测试集群中各个文件夹的大小占用  python2执行
# python2 afs_user_quota.py --cluster=pegasus --ugi=dumi_bot_rec --dir_regex=^/user/dumi/duer/dumi_bot_rec --dir_level=7
# python2 afs_user_quota.py --cluster=pegasus --ugi=dumi_strategy_online --dir_regex=^/user/dumi_strategy_online/rus --dir_level=7
#
########################################
"""this script is used to query user directory quota"""
import os
import json
# import urllib
import urllib2
import sys
import time
import argparse
# bigsql restful api
list_partition_url = ('http://10.11.10.6:8803'
                      '/v1/project/afs/datastore/afs/table/user_dir_quota/partition?listPartition')
submit_job_url = 'http://10.11.10.6:8803/v1/project/afs/job'
query_job_url = 'http://10.11.10.6:8803/v1/project/afs/job/{}'
stream_result_url = ('http://10.11.10.6:8803'
                     '/v1/project/afs/query/{}/streamResult')
# bigsql restful api header
header_dict = {
    "Content-Type": "application/json",
    "x-bbs-user-id": "afs_dir_quota"
}
# bigsql restful post data
partition_filter = {"filter": {"cluster": ""}}
query_data = {
    "jobConf": {
        "jobType": "QUERY",
        "queryJob": {
            "query": "",
            "createDispositionStrategy": "CREATE_IF_NEEDED",
            "writeDispositionStrategy": "WRITE_APPEND",
            "allowLargeResults": True,
            "jobPriority": "INTERACTIVE",
            "useQueryCache": True,
            "flattenResults": True
        }
    },
    "dryRun": False
}
# bigsql sql
query_sql = ("select ugi, dir, phy, logic, inode from afs.user_dir_quota "
             "where cluster='{cluster}' and ckpt_time='{ckpt_time}'")
dir_level_condition = " and dir rlike '^\/[^\/]*(\/[^\/]*){{0,{level}}}$'"
dir_regex_condition = " and dir rlike '{regex}'"
ugi_condition = " and ugi='{ugi}'"
def list_partition():
    """list partition"""
    partition_filter["filter"]["cluster"] = cluster
    req = urllib2.Request(url=list_partition_url, data=json.dumps(partition_filter),
                          headers=header_dict)
    res = urllib2.urlopen(req)
    res = res.read()
    result = json.loads(res)
    if result["partitionInfo"] is not None and len(result["partitionInfo"]) > 0:
        partition_list = result["partitionInfo"][0]["partitionValues"]
        global ckpt_time
        for partition in partition_list:
            if partition.split("/")[1] > ckpt_time:
                ckpt_time = partition.split("/")[1]

def submit_query_job():
    """submit query job"""
    sql = query_sql.format(cluster=cluster, ckpt_time=ckpt_time, ugi=ugi)
    if dir_level < 15:
        sql = sql + dir_level_condition.format(level=dir_level - 1)
    if dir_regex:
        sql = sql + dir_regex_condition.format(regex=dir_regex)
    if ugi:
        sql = sql + ugi_condition.format(ugi=ugi)
    print(sql)
    query_data["jobConf"]["queryJob"]["query"] = sql
    req = urllib2.Request(url=submit_job_url, data=json.dumps(query_data),
                          headers=header_dict)
    res = urllib2.urlopen(req)
    res = res.read()
    result = json.loads(res)
    if result["jobId"]:
        global job_id
        job_id = result["jobId"]

def check_job_status():
    """check job status"""
    for num in range(1, 120):
        time.sleep(5)  # 10 min
        req = urllib2.Request(url=query_job_url.format(job_id), headers=header_dict)
        res = urllib2.urlopen(req)
        res = res.read()
        result = json.loads(res)
        print("check job_id:{}, status:{}".format(job_id, result["status"])) 
        if result["status"]:
            if 'SUCCESS' == result["status"]:
                if result["totalRowCount"] > 1000000:
                    print ("Fail to download user quota output is too big:{}, "
                           "try to add --dir_level or --dir_regex")\
                           .format(result["totalRowCount"])
                    return False
                else:
                    return True
            if 'FAILED' == result["status"] or 'KILLED' == result["status"] \
                    or 'TIMEOUT' == result["status"]:

                return False

def save_query_result():
    """save result to file"""
    req = urllib2.Request(url=stream_result_url.format(job_id), headers=header_dict)
    res = urllib2.urlopen(req)
    content = res.read()
    result = json.loads(content)
    row_count = result["totalRowCount"]
    print("Success to fetch result num: {}".format(row_count)) 
    global out_file
    if os.path.exists(out_file):
        os.remove(out_file)
    if not out_file:
        out_file = str(ugi or "null") + "_" + cluster + "." + ckpt_time
    file_output = open(out_file, "aw")
    if not file_output:
        print("Fail to open file in current directory: {}".format(out_file)) 
    # file_output.writelines("======checkpoint timestamp:" + ckpt_time + "======\n")
    # file_output.writelines("ugi, dir, physical, logical, inode_num\n")
    data_str = result["data"]
    data_list = json.loads(data_str)
    for data in data_list:
        file_output.writelines("%(ugi)s,%(dir)s,%(phy)d,%(logic)d,%(inode)d\n" % data)
    file_output.close()

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='afs directory quota')
    parser.add_argument('--cluster', type=str, default=None, required=True,
                        help='required, cluster name')
    parser.add_argument('--ugi', type=str, default=None,
                        help='required, ugi')
    parser.add_argument('--dir_level', type=int, default=7,
                        help='optional, default=15, the level of directory hierarchy')
    parser.add_argument('--dir_regex', type=str, default=None,
                        help='optional, support regex on directory')
    parser.add_argument('--out_file', type=str, default="afs_quota.txt",
                        help='optional, default=$uig_$cluster.$timestamp, '
                             'result will save to this path')
    args = parser.parse_args()
    cluster = args.cluster
    ugi = args.ugi
    dir_level = args.dir_level
    dir_regex = args.dir_regex
    out_file = args.out_file
    ckpt_time = None
    job_id = None
    if ugi is None and dir_regex is None:
        print("ugi and dir_regex can not be None, must set one of them") 
        sys.exit(-1)
    # 1. get the latest checkpoint of this cluster to fetch latest data
    list_partition()
    if not ckpt_time:
        print("Fail to get cluster data, cluster:{}, ugi:{}".format(cluster, ugi)) 
        sys.exit(-1)
    print("Success to get latest checkpoint, cluster: {}, checkpoint: {}".format(cluster, ckpt_time)) 
    # 2. submit a query job
    submit_query_job()
    if not job_id:
        print("Fail to submit query job, cluster:{}, ugi:{}".format(cluster, ugi)) 
        sys.exit(-1)
    print("Success to submit query job, job_id: {}".format(job_id)) 
    # 3. wait job finish
    if not check_job_status():
        print("Query job failed, cluster:{}, ugi:{}, job_id:{}".format(cluster, ugi, job_id)) 
        sys.exit(-1)
    print("Success to finish query job, job_id: {}".format(job_id)) 
    # 4. fetch job result and save to out_file
    print("Start to download result") 
    save_query_result()
    print("Success to save result to {}".format(out_file))

# python2 afs_user_quota.py --cluster=pegasus --ugi=dumi_bot_rec --dir_regex=^/user/dumi/duer/dumi_bot_rec --dir_level=7
# python2 afs_user_quota.py --cluster=pegasus --ugi=dumi_strategy_online --dir_regex=^/user/dumi_strategy_online/rus --dir_level=7