# -*- coding: utf-8 -*-
import os

dataPath = 'afs_quota.txt'
disk = []
with open(dataPath, 'r') as lines:
    for line in lines:
        mess = line.split(',')
        mess[2] = int(mess[2])
        disk.append(mess)
disk.sort(key=lambda ele: ele[2], reverse=True)
for line in disk[:50]:
    print(line[1], '\t', line[2])