#!/bin/bash 
source ~/.bashrc


###### 获取当前时间戳 ######
current=`date "+%Y-%m-%d %H:%M:%S"`
timeStamp=`date -d "$current" +%s`
dst_day=$(date -d "last day" +%Y%m%d) 

###### 路径相关 ######
base_path="/home/disk3/rs_online_jobs/workspace/predictor_mis/predictor_model_mis_push_homefeed"
log_path="$base_path/logs/$dst_day.log"
conf_path="$base_path/home_feed_model/home_feed_model.conf"
{
    ###### 时间戳替换 ######
    old_ts=`grep 'timestamp' $conf_path | tail -1 | awk -F ':' '{print $2}'`
    echo $timeStamp
    echo $old_ts
    sed -i "s/${old_ts}/ $timeStamp/g" $conf_path
    echo "modify timestamp"
} > $log_path 2>&1
